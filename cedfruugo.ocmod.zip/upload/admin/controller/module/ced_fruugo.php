<?php

class ControllerModuleCedFruugo extends Controller
{
	private $error = array();

	public function index(){

		$this->load->language('module/ced_fruugo');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()){
			$this->model_setting_setting->editSetting('ced_fruugo', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit']      = $this->language->get('text_edit');
		$data['text_enabled']   = $this->language->get('text_enabled');
		$data['text_disabled']  = $this->language->get('text_disabled');

		$data['entry_code']     = $this->language->get('entry_code');
		$data['entry_status']   = $this->language->get('entry_status');

		$data['help_code']      = $this->language->get('help_code');

		$data['button_save']    = $this->language->get('button_save');
		$data['button_cancel']  = $this->language->get('button_cancel');

		// Tabs
        $data['tab_general']      = $this->language->get('tab_general');
        $data['tab_fruugo_product'] = $this->language->get('tab_fruugo_product');
        $data['tab_fruugo_order']  = $this->language->get('tab_fruugo_order');
        $data['tab_fruugo_cron']   = $this->language->get('tab_fruugo_cron');

		$data['api_url']             = $this->language->get('api_url');
		$data['ced_fruugo_api_url']  = $this->language->get('ced_fruugo_api_url');

		$data['feed_url']            = $this->language->get('feed_url');
		$data['ced_fruugo_feed_url'] = $this->language->get('ced_fruugo_feed_url');
		$data['ced_fruugo_feed_url_link'] = $this->url->link('module/ced_fruugo/getFeedFile', 'token=' . $this->session->data['token'], 'SSL');

		$data['cron_secure_key']            = $this->language->get('cron_secure_key');
        $data['ced_fruugo_cron_secure_key_order'] = $this->language->get('ced_fruugo_cron_secure_key_order');
        $data['ced_fruugo_cron_secure_key_order_time'] = $this->language->get('ced_fruugo_cron_secure_key_order_time');
        $data['ced_fruugo_cron_secure_key_product'] = $this->language->get('ced_fruugo_cron_secure_key_product');
        $data['ced_fruugo_cron_secure_key_product_time'] = $this->language->get('ced_fruugo_cron_secure_key_product_time');
        $data['ced_fruugo_cron_secure_key_product_add'] = $this->language->get('ced_fruugo_cron_secure_key_product_add');
        $data['ced_fruugo_cron_secure_key_product_add_time'] = $this->language->get('ced_fruugo_cron_secure_key_product_add_time');
        $data['ced_fruugo_cron_secure_key_feed_update'] = $this->language->get('ced_fruugo_cron_secure_key_feed_update');
        $data['ced_fruugo_cron_secure_key_feed_update_time'] = $this->language->get('ced_fruugo_cron_secure_key_feed_update_time');

		$data['username']   = $this->language->get('username');
		$data['password']   = $this->language->get('password');

		$data['customer_email']   = $this->language->get('customer_email');
		$data['customer_id']   = $this->language->get('customer_id');
		$data['customer_group_id'] = $this->language->get('customer_group_id');
		$data['is_manufacturer'] = $this->language->get('is_manufacturer');

		$data['order_status'] = $this->language->get('order_status');
		$data['order_status_importing'] = $this->language->get('order_status_importing');
		$data['order_accepted'] = $this->language->get('order_accepted');
		$data['order_after_rejected'] = $this->language->get('order_after_rejected');
		$data['order_rejected'] = $this->language->get('order_rejected');
		$data['order_after_accepted'] = $this->language->get('order_after_accepted');
		$data['order_shipped'] = $this->language->get('order_shipped');
		$data['order_after_shipped'] = $this->language->get('order_after_shipped');
		$data['order_carrier'] = $this->language->get('order_carrier');
		$data['order_carrier_importing'] = $this->language->get('order_carrier_importing');
		$data['order_payment'] = $this->language->get('order_payment');
		$data['order_payment_importing'] = $this->language->get('order_payment_importing');

		$data['store_language'] = $this->language->get('store_language');

		$data['price_variant_type'] = $this->language->get('price_variant_type');
		$data['price_variant_amount'] = $this->language->get('price_variant_amount');
		$data['price_type'] = $this->language->get('price_type');

		$data['disabled_product_upload'] = $this->language->get('disabled_product_upload');

		$data['map_category'] = $this->language->get('map_category');
        
        $data['help_category'] = $this->language->get('help_category');
		$data['auto_accept_reject'] = $this->language->get('auto_accept_reject');
		$data['auto_sync_inventory'] = $this->language->get('auto_sync_inventory');
		$data['update_price'] = $this->language->get('update_price');
		$data['update_inventory'] = $this->language->get('update_inventory');
		$data['update_product_data'] = $this->language->get('update_product_data');
		$data['debug'] = $this->language->get('debug');

		$data['entry_country'] = $this->language->get('entry_country');
		$data['entry_language'] = $this->language->get('entry_language');
		$data['entry_currency'] = $this->language->get('entry_currency');

		$data['token'] = $this->session->data['token'];

		if(isset($this->error['warning'])){
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if(isset($this->error['code'])){
			$data['error_code'] = $this->error['code'];
		} else {
			$data['error_code'] = '';
		}

		if(isset($this->error['pass'])){
			$data['error_pass'] = $this->error['pass'];
		} else {
			$data['error_pass'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_module'),
			'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('module/ced_fruugo', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['action'] = $this->url->link('module/ced_fruugo', 'token=' . $this->session->data['token'], 'SSL');

		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		$this->load->model('ced_fruugo/map_category');

		$data['countries'] = $this->model_ced_fruugo_map_category->getCountry();

		$data['currencies'] = $this->model_ced_fruugo_map_category->getCurrency();

		$data['fruugoLanguage'] = $this->model_ced_fruugo_map_category->getFruugoLanguage();

		if (isset($this->request->post['ced_fruugo_status'])) {
			$data['ced_fruugo_status'] = $this->request->post['ced_fruugo_status'];
		} else {
			$data['ced_fruugo_status'] = $this->config->get('ced_fruugo_status');
		}

		if (isset($this->request->post['ced_fruugo_username'])) {
			$data['ced_fruugo_username'] = $this->request->post['ced_fruugo_username'];
		} else {
			$data['ced_fruugo_username'] = $this->config->get('ced_fruugo_username');
		}

		if (isset($this->request->post['ced_fruugo_password'])) {
			$data['ced_fruugo_password'] = $this->request->post['ced_fruugo_password'];
		} else {
			$data['ced_fruugo_password'] = $this->config->get('ced_fruugo_password');
		}

		if (isset($this->request->post['ced_fruugo_customer_email'])) {
			$data['ced_fruugo_customer_email'] = $this->request->post['ced_fruugo_customer_email'];
		} else {
			$data['ced_fruugo_customer_email'] = $this->config->get('ced_fruugo_customer_email');
		}

		if (isset($this->request->post['ced_fruugo_customer_id'])) {
			$data['ced_fruugo_customer_id'] = $this->request->post['ced_fruugo_customer_id'];
		} else {
			$data['ced_fruugo_customer_id'] = $this->config->get('ced_fruugo_customer_id');
		}

		// Customer Group
        $this->load->model('ced_fruugo/product');

        $data['customer_groups'] = $this->model_ced_fruugo_product->getCustomerGroup();

        if (isset($this->request->post['ced_fruugo_customer_group_id'])) {
            $data['ced_fruugo_customer_group_id'] = $this->request->post['ced_fruugo_customer_group_id'];
        } else {
            $data['ced_fruugo_customer_group_id'] = $this->config->get('ced_fruugo_customer_group_id');
        }

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (isset($this->request->post['ced_fruugo_order_status'])) {
			$data['ced_fruugo_order_status'] = $this->request->post['ced_fruugo_order_status'];
		} else {
			$data['ced_fruugo_order_status'] = $this->config->get('ced_fruugo_order_status');
		}

		if (isset($this->request->post['ced_fruugo_order_accepted'])) {
			$data['ced_fruugo_order_accepted'] = $this->request->post['ced_fruugo_order_accepted'];
		} else {
			$data['ced_fruugo_order_accepted'] = $this->config->get('ced_fruugo_order_accepted');
		}

		if (isset($this->request->post['ced_fruugo_order_rejected'])) {
			$data['ced_fruugo_order_rejected'] = $this->request->post['ced_fruugo_order_rejected'];
		} else {
			$data['ced_fruugo_order_rejected'] = $this->config->get('ced_fruugo_order_rejected');
		}

		$this->load->model('ced_fruugo/map_category');

		$data['order_ship'] = $this->model_ced_fruugo_map_category->getExtensions('shipping');

		if (isset($this->request->post['ced_fruugo_order_shipped'])) {
			$data['ced_fruugo_order_shipped'] = $this->request->post['ced_fruugo_order_shipped'];
		} else {
			$data['ced_fruugo_order_shipped'] = $this->config->get('ced_fruugo_order_shipped');
		}

		$data['order_carriers'] = $this->model_ced_fruugo_map_category->getExtensions('shipping');

		if (isset($this->request->post['ced_fruugo_order_carrier'])) {
			$data['ced_fruugo_order_carrier'] = $this->request->post['ced_fruugo_order_carrier'];
		} else {
			$data['ced_fruugo_order_carrier'] = $this->config->get('ced_fruugo_order_carrier');
		}

		$data['order_pay'] = $this->model_ced_fruugo_map_category->getExtensions('payment');

		if (isset($this->request->post['ced_fruugo_order_payment'])) {
			$data['ced_fruugo_order_payment'] = $this->request->post['ced_fruugo_order_payment'];
		} else {
			$data['ced_fruugo_order_payment'] = $this->config->get('ced_fruugo_order_payment');
		}

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->post['ced_fruugo_store_language'])) {
			$data['ced_fruugo_store_language'] = $this->request->post['ced_fruugo_store_language'];
		} else {
			$data['ced_fruugo_store_language'] = $this->config->get('ced_fruugo_store_language');
		}

		if (isset($this->request->post['ced_fruugo_price_variant_type'])) {
			$data['ced_fruugo_price_variant_type'] = $this->request->post['ced_fruugo_price_variant_type'];
		} else {
			$data['ced_fruugo_price_variant_type'] = $this->config->get('ced_fruugo_price_variant_type');
		}

		if (isset($this->request->post['ced_fruugo_price_variant_amount'])) {
			$data['ced_fruugo_price_variant_amount'] = $this->request->post['ced_fruugo_price_variant_amount'];
		} else {
			$data['ced_fruugo_price_variant_amount'] = $this->config->get('ced_fruugo_price_variant_amount');
		}

		if (isset($this->request->post['ced_fruugo_price_type'])) {
			$data['ced_fruugo_price_type'] = $this->request->post['ced_fruugo_price_type'];
		} else {
			$data['ced_fruugo_price_type'] = $this->config->get('ced_fruugo_price_type');
		}

		if (isset($this->request->post['ced_fruugo_disabled_product_upload'])) {
			$data['ced_fruugo_disabled_product_upload'] = $this->request->post['ced_fruugo_disabled_product_upload'];
		} else {
			$data['ced_fruugo_disabled_product_upload'] = $this->config->get('ced_fruugo_disabled_product_upload');
		}

		$this->load->model('ced_fruugo/map_category');

		//$data['map_categories'] = $this->model_ced_fruugo_map_category->getCategories();

		if (isset($this->request->post['ced_fruugo_map_category'])) {
			$data['ced_fruugo_map_category'] = $this->request->post['ced_fruugo_map_category'];
		} else {
			$data['ced_fruugo_map_category'] = $this->config->get('ced_fruugo_map_category');
		}

		if (isset($this->request->post['ced_fruugo_auto_accept_reject'])) {
			$data['ced_fruugo_auto_accept_reject'] = $this->request->post['ced_fruugo_auto_accept_reject'];
		} else {
			$data['ced_fruugo_auto_accept_reject'] = $this->config->get('ced_fruugo_auto_accept_reject');
		}

		if (isset($this->request->post['ced_fruugo_auto_sync_inventory'])) {
			$data['ced_fruugo_auto_sync_inventory'] = $this->request->post['ced_fruugo_auto_sync_inventory'];
		} else {
			$data['ced_fruugo_auto_sync_inventory'] = $this->config->get('ced_fruugo_auto_sync_inventory');
		}

		if (isset($this->request->post['ced_fruugo_update_price'])) {
			$data['ced_fruugo_update_price'] = $this->request->post['ced_fruugo_update_price'];
		} else {
			$data['ced_fruugo_update_price'] = $this->config->get('ced_fruugo_update_price');
		}

		if (isset($this->request->post['ced_fruugo_update_inventory'])) {
			$data['ced_fruugo_update_inventory'] = $this->request->post['ced_fruugo_update_inventory'];
		} else {
			$data['ced_fruugo_update_inventory'] = $this->config->get('ced_fruugo_update_inventory');
		}

		if (isset($this->request->post['ced_fruugo_update_product_data'])) {
			$data['ced_fruugo_update_product_data'] = $this->request->post['ced_fruugo_update_product_data'];
		} else {
			$data['ced_fruugo_update_product_data'] = $this->config->get('ced_fruugo_update_product_data');
		}

		if (isset($this->request->post['ced_fruugo_debug'])) {
			$data['ced_fruugo_debug'] = $this->request->post['ced_fruugo_debug'];
		} else {
			$data['ced_fruugo_debug'] = $this->config->get('ced_fruugo_debug');
		}

		if (isset($this->request->post['ced_fruugo_country'])) {
			$data['ced_fruugo_country'] = $this->request->post['ced_fruugo_country'];
		} else {
			$data['ced_fruugo_country'] = $this->config->get('ced_fruugo_country');
		}

		if (isset($this->request->post['ced_fruugo_language'])) {
			$data['ced_fruugo_language'] = $this->request->post['ced_fruugo_language'];
		} else {
			$data['ced_fruugo_language'] = $this->config->get('ced_fruugo_language');
		}

		if (isset($this->request->post['ced_fruugo_currency'])) {
			$data['ced_fruugo_currency'] = $this->request->post['ced_fruugo_currency'];
		} else {
			$data['ced_fruugo_currency'] = $this->config->get('ced_fruugo_currency');
		}

		if (isset($this->request->post['ced_fruugo_is_manufacturer'])) {
            $data['ced_fruugo_is_manufacturer'] = $this->request->post['ced_fruugo_is_manufacturer'];
        } else {
            $data['ced_fruugo_is_manufacturer'] = $this->config->get('ced_fruugo_is_manufacturer');
        }

		// $this->load->model('user/user_group');

		// $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/' . $this->request->get['extension']);

		// echo 'module/' . $this->request->get['extension']; die();

		$data['header']  = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/ced_fruugo.tpl', $data));

	}

	public function getFeedFile()
	{
	    $filename = DIR_IMAGE . 'cedfruugo/product_upload/product_feed.csv';

	    if(file_exists($filename)){
	    	header('Content-Description: File Transfer');
		    header('Content-Type: application/force-download');
		    header("Content-Disposition: attachment; filename=\"" . basename($filename) . "\";");
		    header('Content-Transfer-Encoding: binary');
		    header('Expires: 0');
		    header('Cache-Control: must-revalidate');
		    header('Pragma: public');
		    header('Content-Length: ' . filesize($filename));
		    // ob_clean();
		    // flush();
		    readfile($filename);
		    exit;
	    } else {
	    	return 'File Not Exists!';
	    }
	}

    public function autocomplete() {
		$json = array();

		if (isset($this->request->get['ced_fruugo_map_category'])) {
			$this->load->model('ced_fruugo/category');

			$filter_data = array(
				'filter_name' => $this->request->get['ced_fruugo_map_category'],
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_ced_fruugo_category->getCedfruugoCategory($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'category_id'    => $result['category_id'],
					'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}
	}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	protected function validate(){
		if(!$this->user->hasPermission('modify', 'module/ced_fruugo')){
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if(!$this->request->post['ced_fruugo_username']){
			$this->error['code'] = $this->language->get('error_code');
		}

		if(!$this->request->post['ced_fruugo_password']){
			$this->error['pass'] = $this->language->get('error_pass');
		}
		
		return !$this->error;
	}

	public function install(){

		$this->load->model('module/cedfruugo_category');

		$this->model_module_cedfruugo_category->install();

		$this->load->model('ced_fruugo/category');

		 $this->load->model('ced_fruugo/map_category');

		$cat_result = $this->model_ced_fruugo_map_category->getCategories();

		$currency_result = $this->model_ced_fruugo_map_category->getCountry();
		
		if(!$cat_result || !$currency_result){

		   $this->model_module_cedfruugo_category->install();
	    }

		$this->load->model('user/user_group');

		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/ced_fruugo');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/ced_fruugo');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_fruugo/category');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_fruugo/category');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_fruugo/map_category');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_fruugo/map_category');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_fruugo/order');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_fruugo/order');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_fruugo/order_error');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_fruugo/order_error');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_fruugo/product');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_fruugo/product');

		$shop_email =  $this->config->get('config_email');
        $shop_url = HTTPS_CATALOG;
        //  $this->config->get('HTTPS_CATALOG');
        $require_data =  array('domain'=>$shop_url, 'email'=>$shop_email, 'framework'=>'Opencart');
        $cedcommerce_url = 'http://admin.apps.cedcommerce.com/magento-fruugo-info/create?'.http_build_query($require_data);

        $ch = curl_init($cedcommerce_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);

        // Check if any error occurred
        if (curl_errno($ch)) {
        	$this->load->library('cedfruugo');
		    $cedfruugo = Cedfruugo::getInstance($this->registry);
            // $cedfruugo = new CedfruugoHelper;
            $cedfruugo->log(
                METHOD,
                'Warning',
                'Install Message curl error',
                curl_errno($ch)
            );
        }

        // Close handle
        curl_close($ch);

        $this->load->model('extension/event');

		$this->model_extension_event->addEvent('ced_fruugo', 'post.admin.product.add', 'ced_fruugo/product/addNewProductsToVariants');
		
		$this->model_extension_event->addEvent('ced_fruugo', 'post.admin.product.edit', 'ced_fruugo/product/updateFruugoProduct');
	}

	public function uninstall(){
        
        // $this->load->model('module/cedfruugo_category');

		$this->load->model('ced_fruugo/category');

		$this->load->model('user/user_group');

		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'module/ced_fruugo');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'module/ced_fruugo');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_fruugo/category');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_fruugo/category');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_fruugo/map_category');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_fruugo/map_category');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_fruugo/order');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_fruugo/order');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_fruugo/order_error');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_fruugo/order_error');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_fruugo/product');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_fruugo/product');

        $this->load->model('extension/event');

		$this->model_extension_event->deleteEvent('ced_fruugo');
	}
}

?>