<?php

class ControllerCedFruugoMapCategory extends Controller
{
	private $error = array();
	
	public function index() {
	
		$this->load->language('ced_fruugo/map_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_fruugo/map_category');

		$this->getList();
	}

	public function add() {

		$this->load->language('ced_fruugo/map_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_fruugo/map_category');
		// echo '<pre>'; print_r($this->request->post); die();
       
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
	
			$this->model_ced_fruugo_map_category->addCategoryMapping($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function edit() {

		$this->load->language('ced_fruugo/map_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_fruugo/map_category');
  
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_ced_fruugo_map_category->editCategoryMapping($this->request->get['id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function delete() {

		$this->load->language('ced_fruugo/map_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_fruugo/map_category');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $category_id) {
				$this->model_ced_fruugo_map_category->deleteCategoryMapping($category_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getList();
	}

	protected function getList() {

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'FruugoCategory';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_ced_fruugo'),
			'href' => $this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);
		
		$data['add'] = $this->url->link('ced_fruugo/map_category/add', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$data['delete'] = $this->url->link('ced_fruugo/map_category/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');

		$data['categories'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$this->load->model('ced_fruugo/map_category');

		$category_total = $this->model_ced_fruugo_map_category->getTotalMappingDetails($filter_data);

		$results = $this->model_ced_fruugo_map_category->getMappingDetails($filter_data);


		foreach ($results as $result) {

           $cat = json_decode($result['category'], true);
	       $store_category ='';
	       $store_result = '';

	       if($cat){
	           foreach($cat as $store_id){
		           	if($store_id != ''){
		           	  $store_category = $this->model_ced_fruugo_map_category->getStoreCategory($store_id);
		           	  $store_result .= $store_category . ',';

		            }
	            }  
            }
            
			$data['categories'][] = array(
				'id'              => $result['id'],
				'FruugoCategory'  => $result['FruugoCategory'],
				'category'        => rtrim($store_result, ','),
				'edit'            => $this->url->link('ced_fruugo/map_category/edit', 'token=' . $this->session->data['token'] . '&id=' . $result['id'] . $url, 'SSL'),
				'delete'      => $this->url->link('ced_fruugo/map_category/delete', 'token=' . $this->session->data['token'] . '&id=' . $result['id'] . $url, 'SSL')
			); 
		} 

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');

		$data['column_name'] = $this->language->get('column_name');
		$data['column_mapped_categories'] = $this->language->get('column_mapped_categories');
	
		$data['column_action'] = $this->language->get('column_action');

		$data['button_add'] = $this->language->get('button_add');
		$data['button_edit'] = $this->language->get('button_edit');
		$data['button_delete'] = $this->language->get('button_delete');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'] . '&sort=name' . $url, 'SSL');
		$data['sort_mapped_categories'] = $this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'] . '&sort=mapped_categories' . $url, 'SSL');

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $category_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($category_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($category_total - $this->config->get('config_limit_admin'))) ? $category_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $category_total, ceil($category_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_fruugo/map_category_list.tpl', $data));
	}

	protected function getForm() {

		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['text_form'] = !isset($this->request->get['id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['text_none'] = $this->language->get('text_none');
		$data['text_default'] = $this->language->get('text_default');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['text_option'] = $this->language->get('text_option');
		$data['text_attribute_variants'] = $this->language->get('text_attribute_variants');
		$data['text_system_default'] = $this->language->get('text_system_default');

		$data['entry_category'] = $this->language->get('entry_category');
		$data['entry_stock_category'] = $this->language->get('entry_stock_category');
		$data['entry_manufacturer'] = $this->language->get('entry_manufacturer');
		$data['entry_store'] = $this->language->get('entry_store');
		$data['entry_language'] = $this->language->get('entry_language');

		$data['help_filter'] = $this->language->get('help_filter');
		$data['help_keyword'] = $this->language->get('help_keyword');
		$data['help_top'] = $this->language->get('help_top');
		$data['help_column'] = $this->language->get('help_column');
		$data['help_category'] = $this->language->get('help_category');
		$data['help_manufacturer'] = $this->language->get('help_manufacturer');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$data['tab_map_category'] = $this->language->get('tab_map_category');
		$data['tab_attribute'] = $this->language->get('tab_attribute');
		$data['tab_default'] = $this->language->get('tab_default');
		$data['tab_variant_attribute'] = $this->language->get('tab_variant_attribute');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		} 

		if (isset($this->error['code'])) {
			$data['error_code'] = $this->error['code'];
		} else {
			$data['error_code'] = '';
		} 
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_fruugo/category', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);
		
		if (!isset($this->request->get['id'])) {
			$data['action'] = $this->url->link('ced_fruugo/map_category/add', 'token=' . $this->session->data['token'] . $url, 'SSL');
		} else {
			$data['action'] = $this->url->link('ced_fruugo/map_category/edit', 'token=' . $this->session->data['token'] . '&id=' . $this->request->get['id'] . $url, 'SSL');
		}

		$data['cancel'] = $this->url->link('ced_fruugo/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL');

		if (isset($this->request->get['id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$mapping_details = $this->model_ced_fruugo_map_category->getMappingDetailsByID($this->request->get['id']);
			// echo '<pre>'; print_r($mapping_details); die();

			$catagories = json_decode($mapping_details['category'], true);
			$manufacturers = json_decode($mapping_details['manufacturer'], true);
			$OpencartStore = json_decode($mapping_details['product_store'], true);
			$attribute_array = json_decode($mapping_details['attribute'], true);
	        $variant_array   = json_decode($mapping_details['variant_attribute'], true);
		    $default_array   = json_decode($mapping_details['default_attribute'], true);
		    if(!is_array($catagories) || empty($catagories))
		    {
		    	$catagories = array();
		    }
		    if(!is_array($manufacturers) || empty($manufacturers))
		    {
		    	$manufacturers = array();
		    }
		    if(!is_array($OpencartStore) || empty($OpencartStore))
		    {
		    	$OpencartStore = array();
		    }
		    if(!is_array($attribute_array) || empty($attribute_array))
		    {
		    	$attribute_array = array();
		    }
		    if(!is_array($variant_array) || empty($variant_array))
		    {
		    	$variant_array = array();
		    }
		    if(!is_array($default_array) || empty($default_array))
		    {
		    	$default_array = array();
		    }

		}

		$data['token'] = $this->session->data['token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		$this->load->model('ced_fruugo/map_category');

		$data['catagories'] = $this->model_ced_fruugo_map_category->getCategories();

		$data['systemDefault'] = $this->model_ced_fruugo_map_category->getSystemDefault();
         
		// Fruugo categories
		$mapped_fruugo_category_id = $this->config->get('ced_fruugo_map_category');
		if(!empty($mapped_fruugo_category_id)){
			$sql = $this->db->query("SELECT name FROM `". DB_PREFIX ."cedfruugo_category` WHERE category_id = '". $mapped_fruugo_category_id ."' ");
		    $mapped_fruugo_category = $sql->row;
		}
		
		if (isset($this->request->post['FruugoCategory'])) {
			$data['FruugoCategory'] = $this->request->post['FruugoCategory'];
		} elseif(isset($mapped_fruugo_category) && !empty($mapped_fruugo_category['name'])){
           $data['FruugoCategory'] = $mapped_fruugo_category['name'];
		} elseif (!empty($mapping_details)) {
			$data['FruugoCategory'] = $mapping_details['FruugoCategory'];
		} else {
			$data['FruugoCategory'] = '';
		}

	    // Stock Categories
		$this->load->model('catalog/category');

		if (isset($this->request->post['product_category'])) {
			$categories = $this->request->post['product_category'];
		} elseif (!empty($catagories)) {
			$categories = $catagories;
		} else {
			$categories = array();
		}

		$data['product_categories'] = array();

		foreach ($categories as $category_id) {
			$category_info = $this->model_catalog_category->getCategory($category_id);

			if ($category_info) {
				$data['product_categories'][] = array(
					'category_id' => $category_info['category_id'],
					'name' => ($category_info['path']) ? $category_info['path'] . ' &gt; ' . $category_info['name'] : $category_info['name']
				);
			}
		}

		// Manufacturer
		$this->load->model('catalog/manufacturer');

		if (isset($this->request->post['manufacturer_id'])) {
			$manufacturers = $this->request->post['manufacturer_id'];
		} elseif (!empty($manufacturers)) {
			$manufacturers = $manufacturers;
		} else {
			$manufacturers = array();
		}

		$data['manufacturers'] = array();

		foreach ($manufacturers as $manufacturer) {
			$manufacturer_info = $this->model_catalog_manufacturer->getManufacturer($manufacturer);

			if ($manufacturer_info) {
				$data['manufacturers'][] = array(
					'manufacturer_id' => $manufacturer_info['manufacturer_id'],
					'name' => $manufacturer_info['name']
				);
			}
		}

		$this->load->model('setting/store');

		$data['stores'] = $this->model_setting_store->getStores();

		if (isset($this->request->post['product_store'])) {
			$data['product_store'] = $this->request->post['product_store'];
		} elseif (isset($this->request->get['product_id'])) {
			$data['product_store'] = $this->model_catalog_product->getProductStores($this->request->get['product_id']);
		} else {
			$data['product_store'] = array(0);
		}

		// Store Language
		$this->load->model('localisation/language');
		$mapped_fruugo_language = $this->config->get('ced_fruugo_language');
		
		if(isset($this->request->post['storeLanguage'])) {
			$data['storeLanguage'] = $this->request->post['storeLanguage'];
		} elseif(isset($mapped_fruugo_language) && !empty($mapped_fruugo_language)){
           $data['storeLanguage'] = $mapped_fruugo_language;
		} elseif (!empty($mapping_details)) {
			$data['storeLanguage'] = $mapping_details['storeLanguage'];
		} else {
			$data['storeLanguage'] = '';
		}

		// Attributes
		$this->load->model('catalog/attribute');

		$data['stock_attributes'] = $this->model_catalog_attribute->getAttributes();

		// Options
		$this->load->model('catalog/option');

		$options = $this->model_catalog_option->getOptions();

		foreach($options as $option){

		    $type = '';

			if ($option['type'] == 'select' || $option['type'] == 'radio' || $option['type'] == 'checkbox' || $option['type'] == 'image') {
				$type = $this->language->get('text_choose');
				$json[] = array(
					'option_id'    => $option['option_id'],
					'name'         => strip_tags(html_entity_decode($option['name'], ENT_QUOTES, 'UTF-8')),
					'category'     => $type,
					'type'         => $option['type'],
		        );
			}			
		}
 
		$data['options'] = $json;

		// Validation Array
		$data['validation_array'] = $this->validationArray();
		$validation_array = $data['validation_array'];
		$validation_keys = array_keys($validation_array);
        
        // Attributes
		foreach ($validation_keys as $key => $value) {

			if(in_array($value ,array('SkuId', 'ProductId','Category','StockStatus','Country','Currency','Language', 'Imageurl1', 'Imageurl2', 'Imageurl3', 'Imageurl4', 'Imageurl5', 'AttributeSize', 'AttributeColor', 'Attribute1', 'Attribute2', 'Attribute3', 'Attribute4', 'Attribute5', 'Attribute6', 'Attribute7', 'Attribute8', 'Attribute9', 'Attribute10', 'Country', 'Currency', 'Language',))){
				continue;
			} else {

				if (isset($this->request->post['attribute'][$value])) {
				$data['mapped_attribute'][$value] = $this->request->post['attribute'][$value];
				} elseif (!empty($attribute_array) && isset($attribute_array[$value]) ) {
					$data['mapped_attribute'][$value] = $attribute_array[$value];
				} else {
					$data['mapped_attribute'][$value] = '';
				}
		    }

		}

		// Default Attributes
		foreach ($validation_keys as $key => $value) {

		    if(!in_array($value ,array('Brand','VATRate','Manufacturer','LeadTime','PackageWeight'))){
		    	continue;
		    } else {

		    	if (isset($this->request->post['default_attribute'][$value])) {
			    $data['default_attribute'][$value] = $this->request->post['default_attribute'][$value];
			    } elseif (!empty($default_array) && isset($default_array[$value]) ) {
				$data['default_attribute'][$value] = $default_array[$value];
			    } else {
				$data['default_attribute'][$value] = '';
			    }

		    }

		}

		// Variant Attributes
		$data['variant_attributes'] = $this->variantAttributes();
		$variant_attributes = $data['variant_attributes'];
		$variant_keys = array_keys($variant_attributes);

		foreach ($variant_keys as $key => $value) {

			if (isset($this->request->post['variant_attribute'][$value])) {
			$data['variant_attribute'][$value] = $this->request->post['variant_attribute'][$value];
			}
			   elseif (!empty($variant_array) && isset($variant_array[$value]) ) {
				$data['variant_attribute'][$value] = $variant_array[$value];
				// echo $mapping_details['variant_attribute'][$key]; die();
			} else {
				$data['variant_attribute'][$value] = '';
			}

		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
    //echo '<pre>'; print_r($data); die();
		$this->response->setOutput($this->load->view('ced_fruugo/map_category_form.tpl', $data));
	}

	public function validationArray(){

		return array(
            'ProductId' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'Your own product identifier code that you recognise when it is provided on order information.
								The same ProductId should be used to group together Skus where they are available with multiple options (Colours, Sizes etc.).'
            ),
            'SkuId' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'If the product has multiple options, the SkuId uniquely identifies and separates each option. If a product doesn’t have multiple options the SkuId can be the same as the ProductId.
								Each ProductId & SkuId combination must be unique and not repeated for any other Product(s).'
            ),
            'EAN' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 14,
                'description' => 'The unique GTIN for the product. GTIN stands for Global Trade Item Number - a globally unique number used to identify trade items, products, or services. GTIN is the umbrella term that refers to the entire family of data structures - UPC, EAN, UCC - 8, 12, 13 & 14 digits.
								If you are the manufacturer of the product you can mark the product to be an exception to the requirement rule by using EXCEP in the EAN field.'
            ),
            'Brand' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'The brand name of the product.
'
            ),
            'Category' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 250,
                'description' => 'The category name where the product is located on your own website or the category you wish the product to be classified in on Fruugo.
								The category value must be accurate enough to identify the nature of the product, and if relevant to the type of product it should include gender.'
            ),
            'Imageurl1' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 2150,
                'description' => 'The link to your primary image for a product which will be displayed. A minimum size of 400px x 400px (or larger). The image should be provided on a white background.
								Images will only be updated if the file name is changed, we do not check to see if your file is newer than your last scheduled import.
								Placeholder or images using watermarks are not permitted.'
            ),
            'StockStatus' => array(
                'type' => 'select',
                'is_required' => true ,
                'length' => 12,
                'values' => array(
                    'INSTOCK' => 'INSTOCK',
                    'OUTOFSTOCK' => 'OUTOFSTOCK',
                    'NOTAVAILABLE' => 'NOTAVAILABLE',
                ),
                'description' => 'The stock status of a product which indicates whether it’s available for purchase. The value of the field must be either:</br>
								INSTOCK – If you have the product currently in stock.</br>
								OUTOFSTOCK – The product is currently out of stock but may return.</br>
								NOTAVAILABLE – The product is permanently out of stock and needs to be removed.'
            ),
            'StockQuantity' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 5,
                'description' => 'The quantity of an item you have available to sell. If stock levels are not held a default number is recommended, such as 100 for in stock items and 0 for out of stock items.
								Negative values or decimal places are not supported.'
            ),
            'Title' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 150,
                'description' => 'A concise title for your product in title case (not block capitals) which identifies the nature of the product.
								It should include any brand, model or part number which is widely used to identify the product.
								It should not include any reference to price; shipping; stock; special offers; or promotional text.
								It should not include any reference to size or colour when part of a grouped product.'
            ),
            'Description' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 5000,
                'description' => 'A detailed explanation of the product and its features. Use sentence case.
								Do not include any URLs; Email Addresses; Telephone Numbers; Prices; Shipping information, or references to activity not on our site.'
            ),
            'NormalPriceWithoutVAT' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 7,
                'description' => "	
									The normal / list price of the product excluding VAT. Must be a numeric value with a decimal separator and not include any currency symbol. For example 4.12. If included, 'NormalPriceWithVAT' must not be included."
            ),
            'NormalPriceWithVAT' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 7,
                'description' => "The normal / list price of the product including VAT. Must be a numeric value with a decimal separator and not include any currency symbol. For example 4.12. If included, 'NormalPriceWithoutVAT' must not be included."
            ),
            'VATRate' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 4,
                'description' => 'The numeric value of the correct VAT rate of the product in your VAT registered country (EU only).
								Do not include % or any other symbols. For example: 20. To be listed as 0 for non-EU based retailers where VAT is not applicable.'
            ),
            'Imageurl2' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "Used to provide additional image URLs for the product. Each URL should be in a separate field with up to 5 images being supported. The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl3' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "Used to provide additional image URLs for the product. Each URL should be in a separate field with up to 5 images being supported. The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl4' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "Used to provide additional image URLs for the product. Each URL should be in a separate field with up to 5 images being supported. The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl5' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "Used to provide additional image URLs for the product. Each URL should be in a separate field with up to 5 images being supported. The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'AttributeSize' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The specific size option of the SKU, which where a product is available in several size choices will present the size option to the retailer. Note: The field becomes mandatory if you have products which are available in multiple sizes.
								We recommend including the size for all products, however the field should not include generic terms such as one size or o/s.'
            ),
            'AttributeColor' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The specific colour option of the SKU, which where a product is available in several colours choices will present the colour option to the retailer. Note: The field becomes mandatory if you have products which are available in multiple colours.
								We recommend including the colour for all products, however the field should not include generic terms such as multi-coloured, mixed or one colour.'
            ),

            'DiscountPriceWithoutVAT' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 6,
                'description' => "The discount / sale price of the product excluding VAT. Must be a numeric value with a decimal separator and not include any currency symbol. For example 4.12.
								Must only be used if you use 'NormalPriceWithoutVAT' for your normal list price. If included 'DiscountPriceWithVAT' must not be included."
            ),
            'DiscountPriceWithVAT' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 6,
                'description' => "The discount / sale price of the product excluding VAT. Must be a numeric value with a decimal separator and not include any currency symbol. For example 4.12.
								Must only be used if you use 'NormalPriceWithVAT' for your normal list price. If included 'DiscountPriceWithoutVAT' must not be included."
            ),
            'ISBN' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 13,
                'description' => 'The unique ISBN for the product. ISBN stands for International Standard Book Number - the globally unique number used to identify publications. The data structure should be either the 10 or 13 digit number (13 preferred). Note: The field becomes mandatory for all books.'
            ),
            'Manufacturer' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 50,
                'description' => 'The name of the manufacturer of the product.'
            ),
            'RestockDate' => array(
                'type' => 'date',
                'is_required' => false ,
                'length' => 9,
                'description' => "The date when a product which is currently marked as OUTOFSTOCK in 'StockStatus' will be back in stock and available for order.
								The date must be provided in one of the following UNIX timestamp formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; DDMM-YY; DD-MM-YYYY; YY-MM-DD; YYYY-MM-DD."
            ),
            'LeadTime' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 2,
                'description' => "The 'LeadTime' has two separate purposes depending on the 'StockStatus' of the product.
							If the product is INSTOCK, the 'LeadTime' indicates the approximiate number of days delay from order to the item being dispatched from the warehouse. Note: Only to be used if the time exceeds 24 hours as 1 day is the default product value.
							If the is OUTOFSTOCK, the 'LeadTime' indicates the approximiate number of days until the product is back in stock and can be dispatched from the warehouse. Note: The product will remain on the site as 'INSTOCK' with the number of days showing as to when it is available."
            ),
            'PackageWeight' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 5,
                'description' => 'The shipping weight of the product provided in grams with no decimal places or unit of measurement. For example, 190.	Note: The field becomes mandatory if your shipping rules are calculated based on the total order weight - please see Shipping > Weight Based Shipping. If you are utilising quantity based shipping all products must have a default value of 1000 - please see Shipping > Quantity Based Shipping.'
            ),
            'Attribute1' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute2' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute3' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute4' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute5' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute6' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute7' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute8' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute9' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute10' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Country' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 150,
                'case' => 'upper',
                'values' => $this->model_ced_fruugo_map_category->getCountry(),
                //'onClick' => 'getFruugoLanguageCurrency(this)',
                'description' => '	
									Two digit ISO code (Upper Case) is used to limit a product to listed countries if they have a different restriction to your default account settings. It is an “include” list and for multiple countries should be separated by spaces. For example: IE FR DE. The country codes must be those supported on Fruugo (as listed in Fruugo Countries > Countries; Languages & Currency codes).
									Note: The field should be left blank if the product does not have a country restriction that differs from your default account settings.'
            ),
            'Currency' => array(
                'type' => 'select',
                'length' => 3,
                'is_required' => false ,
                'values' => $this->model_ced_fruugo_map_category->getCurrency(),
                'case' => 'upper',
                'description' => 'Three letter ISO code (Upper Case) of the currency of the price fields of the feed, such as NormalPriceWithoutVAT. The currency must be one of those supported on Fruugo (as listed in Fruugo Countries > Countries; Languages; & Currency codes).
								We strongly recommend always using the native currency of your registered country. Note: The field becomes mandatory if the language used is not the native language of your registered country.'
            ),
            'Language' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 2,
                'case' => 'lower',
                'values' => $this->model_ced_fruugo_map_category->getFruugoLanguage(),
                'description' => "Two digit ISO code (lower case) of the language of the text fields of the feed, such as Title, Description, AttributeColor etc. The language must be one of those supported on Fruugo (as listed in Fruugo Countries > Countries; Languages; & Currency codes).
								The text within the feed should all be in one language. Note: The field becomes mandatory if the language used is not the native language of your registered country."
            ),
            'DiscountPriceStartDate' => array(
                'type' => 'date',
                'is_required' => false ,
                'length' => 11,
                'description' => "The start date for your discount price to begin being displayed, if it is a timelimited promotion, and you have populated either 'DiscountPriceWithoutVAT' or 'DiscountPriceWithVAT'.
								The date must be provided in one of the following UNIX timestamp formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; DDMM-YY; DD-MM-YYYY; YY-MM-DD; YYYY-MM-DD."
            ),
            'DiscountPriceEndDate' => array(
                'type' => 'date',
                'is_required' => false ,
                'length' => 11 ,
                'description' => "The end date for your discount price to stop being displayed, if it is a timelimited promotion, and you have populated either 'DiscountPriceWithoutVAT' or 'DiscountPriceWithVAT'.
                                The date must be provided in one of the following UNIX timestamp formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; DDMM-YY; DD-MM-YYYY; YY-MM-DD; YYYY-MM-DD."
            ),
        );
	}

	public function variantAttributes()
    {
        return array(
            'AttributeSize' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The specific size option of the SKU, which where a product is available in several size choices will present the size option to the retailer. Note: The field becomes mandatory if you have products which are available in multiple sizes.
								We recommend including the size for all products, however the field should not include generic terms such as one size or o/s.'
            ),
            'AttributeColor' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The specific colour option of the SKU, which where a product is available in several colours choices will present the colour option to the retailer. Note: The field becomes mandatory if you have products which are available in multiple colours.
								We recommend including the colour for all products, however the field should not include generic terms such as multi-coloured, mixed or one colour.'
            ),
            'Attribute1' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute2' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute3' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute4' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute5' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute6' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute7' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute8' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute9' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute10' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
								They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            )
        );
    }

    	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'ced_fruugo/map_category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (utf8_strlen($this->request->post['FruugoCategory']) < 3) {
			$this->error['name'] = $this->language->get('error_name');
		}

		if ($this->request->post['category']) {
			if(utf8_strlen($this->request->post['product_category']) < 3){
				$this->error['code'] = $this->language->get('error_code');
			}
			
		}
			
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'ced_fruugo/map_category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

     public function autocomplete() {
		$json = array();

		if (isset($this->request->get['FruugoCategory'])) {
			$this->load->model('ced_fruugo/category');

			$filter_data = array(
				'filter_name' => $this->request->get['FruugoCategory'],
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_ced_fruugo_category->getCedfruugoCategory($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'category_id'    => $result['category_id'],
					'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					// 'map_categories' => $result['map_categories']
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
    
}

?>