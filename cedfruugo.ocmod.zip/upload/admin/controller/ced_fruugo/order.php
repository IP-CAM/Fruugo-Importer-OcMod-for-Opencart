<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */ 
 
class ControllerCedFruugoOrder extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('ced_fruugo/order');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('ced_fruugo/order');
		$this->getList();
	}
	public function fetchOrder() {

		$this->load->library('cedfruugo');
		$this->load->language('ced_fruugo/order');
		$this->load->model('ced_fruugo/order');
		$cedfruugo = Cedfruugo::getInstance($this->registry); 
        $createdStartDate = date('Y-m-d',strtotime("-1 days"));
        $order = array('from' => $createdStartDate);
		$response = $cedfruugo->fetchOrders($order, 'orders/download');
		if(isset($response['success']) && $response['success']) {
			$this->session->data['success'] = $response['message'];
		} else {
			$this->error[] = $response['message'];
		}
		$this->getList();
	}
	
	public function delete() {
		$this->load->language('ced_fruugo/order');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_fruugo/order');

		if (isset($this->request->post['selected']) && $this->validate()) {
			foreach ($this->request->post['selected'] as $order_id) {
				$this->model_ced_fruugo_order->deleteOrder($order_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_order_id'])) {
				$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
			}
	
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}
	
			if (isset($this->request->get['filter_order_status'])) {
				$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
			} 

			if (isset($this->request->get['filter_fruugo_order_status'])) {
				$url .= '&filter_fruugo_order_status=' . $this->request->get['filter_fruugo_order_status'];
			}
	
			if (isset($this->request->get['filter_total'])) {
				$url .= '&filter_total=' . $this->request->get['filter_total'];
			}
	
			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}
	
			if (isset($this->request->get['filter_date_modified'])) {
				$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
			}

			$this->response->redirect($this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . $url, true));
		}

		$this->getList();
	}
	
	protected function getList() {
		
		if (isset($this->request->get['filter_order_id'])) {
			$filter_order_id = $this->request->get['filter_order_id'];
		} else {
			$filter_order_id = null;
		}

		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = null;
		}

		if (isset($this->request->get['filter_order_status'])) {
			$filter_order_status = $this->request->get['filter_order_status'];
		} else {
			$filter_order_status = null;
		} 

		if (isset($this->request->get['filter_fruugo_order_status'])) {
			$filter_fruugo_order_status = $this->request->get['filter_fruugo_order_status'];
		} else {
			$filter_fruugo_order_status = null;
		}

		if (isset($this->request->get['filter_total'])) {
			$filter_total = $this->request->get['filter_total'];
		} else {
			$filter_total = null;
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = null;
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$filter_date_modified = $this->request->get['filter_date_modified'];
		} else {
			$filter_date_modified = null;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'o.order_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		} 

		if (isset($this->request->get['filter_fruugo_order_status'])) {
			$url .= '&filter_fruugo_order_status=' . $this->request->get['filter_fruugo_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_ced_fruugo'),
			'href' => $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . $url, true)
		);

		$data['invoice'] = $this->url->link('ced_fruugo/order/invoice', 'token=' . $this->session->data['token'], true);
		$data['shipping'] = $this->url->link('ced_fruugo/order/shipping', 'token=' . $this->session->data['token'], true);
		$data['fetchOrder'] = $this->url->link('ced_fruugo/order/fetchOrder', 'token=' . $this->session->data['token'], true);
		$data['delete'] = $this->url->link('ced_fruugo/order/delete', 'token=' . $this->session->data['token'], true);
		$data['acceptOrder'] = $this->url->link('ced_fruugo/order/acceptOrder', 'token=' . $this->session->data['token'], true);

		$data['orders'] = array();

		$filter_data = array(
			'filter_order_id'      => $filter_order_id,
			'filter_customer'	   => $filter_customer,
			'filter_order_status'  => $filter_order_status,
			'filter_fruugo_order_status' => $filter_fruugo_order_status,
			'filter_total'         => $filter_total,
			'filter_date_added'    => $filter_date_added,
			'filter_date_modified' => $filter_date_modified,
			'sort'                 => $sort,
			'order'                => $order,
			'start'                => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                => $this->config->get('config_limit_admin')
		);

		$order_total = $this->model_ced_fruugo_order->getTotalOrders($filter_data);

		$results = $this->model_ced_fruugo_order->getOrders($filter_data);
		// echo '<pre>'; print_r($results); die();

		foreach ($results as $result) {
			if($result['currency_value'] == 0)
                $result['currency_value'] = '1';
			$data['orders'][] = array(
				'order_id'      => $result['order_id'],
				'customer'      => $result['customer'],
				'order_status'  => $result['order_status'] ? $result['order_status'] : $this->language->get('text_missing'),
				'total'         => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value']),
				'date_added'    => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'fruugo_order_id' => $result['fruugo_order_id'],
				'fruugo_status' => $result['fruugo_status'],
				'shipping_code' => $result['shipping_code'],
				'view'          => $this->url->link('ced_fruugo/order/info', 'token=' . $this->session->data['token'] . '&order_id=' . $result['order_id'] . $url, true),
				'edit'          => $this->url->link('ced_fruugo/order/edit', 'token=' . $this->session->data['token'] . '&order_id=' . $result['order_id'] . $url, true)
			);
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');
		$data['text_missing'] = $this->language->get('text_missing');
		$data['text_loading'] = $this->language->get('text_loading');

		$data['column_order_id'] = $this->language->get('column_order_id');
		$data['column_customer'] = $this->language->get('column_customer');
		$data['column_status'] = $this->language->get('column_status');
		$data['column_total'] = $this->language->get('column_total');
		$data['column_fruugo_order_id'] = $this->language->get('column_fruugo_order_id');
		$data['column_fruugo_status'] = $this->language->get('column_fruugo_status');
		$data['column_date_added'] = $this->language->get('column_date_added');
		$data['column_date_modified'] = $this->language->get('column_date_modified');
		$data['column_action'] = $this->language->get('column_action');

		$data['entry_order_id'] = $this->language->get('entry_order_id');
		$data['entry_customer'] = $this->language->get('entry_customer');
		$data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['entry_total'] = $this->language->get('entry_total');
		$data['entry_date_added'] = $this->language->get('entry_date_added');
		$data['entry_fruugo_order_status'] = $this->language->get('entry_fruugo_order_status');
		// $data['entry_date_modified'] = $this->language->get('entry_date_modified');

		$data['button_invoice_print'] = $this->language->get('button_invoice_print');
		$data['button_shipping_print'] = $this->language->get('button_shipping_print');
		$data['button_add'] = $this->language->get('button_add');
		$data['button_edit'] = $this->language->get('button_edit');
		$data['button_delete'] = $this->language->get('button_delete');
		$data['button_filter'] = $this->language->get('button_filter');
		$data['button_view'] = $this->language->get('button_view');
		$data['button_ip_add'] = $this->language->get('button_ip_add');

		$data['token'] = $this->session->data['token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		} 

		if (isset($this->request->get['filter_fruugo_order_status'])) {
			$url .= '&filter_fruugo_order_status=' . $this->request->get['filter_fruugo_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_order'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . '&sort=o.order_id' . $url, true);
		$data['sort_customer'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . '&sort=customer' . $url, true);
		$data['sort_status'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . '&sort=order_status' . $url, true);
		$data['sort_total'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . '&sort=o.total' . $url, true);
		$data['sort_fruugo_order'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . '&sort=so.fruugo_order_id' . $url, true);
		$data['sort_fruugo_status'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . '&sort=so.fruugo_status' . $url, true);
		$data['sort_date_added'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . '&sort=o.date_added' . $url, true);
		// $data['sort_date_modified'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . '&sort=o.date_modified' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		} 

		if (isset($this->request->get['filter_fruugo_order_status'])) {
			$url .= '&filter_fruugo_order_status=' . $this->request->get['filter_fruugo_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $order_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));

		$data['filter_order_id'] = $filter_order_id;
		$data['filter_customer'] = $filter_customer;
		$data['filter_order_status'] = $filter_order_status;
		$data['filter_fruugo_order_status'] = $filter_fruugo_order_status;
		$data['filter_total'] = $filter_total;
		$data['filter_date_added'] = $filter_date_added;
		$data['filter_date_modified'] = $filter_date_modified;

		$data['sort'] = $sort;
		$data['order'] = $order;

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_fruugo/order_list.tpl', $data));
	}

	public function info() {
        $this->load->model('ced_fruugo/order');

        if (isset($this->request->get['order_id'])) {
            $order_id = $this->request->get['order_id'];
        } else {
            $order_id = 0;
        }

        $order_info = $this->model_ced_fruugo_order->getOrder($order_id);
         //echo '<pre>'; print_r($order_info); die();

        if ($order_info) {
            $this->load->language('ced_fruugo/order');

            $this->document->setTitle($this->language->get('heading_title'));

            $data['heading_title'] = $this->language->get('heading_title');

            $data['text_order_detail'] = $this->language->get('text_order_detail');
            $data['text_order'] = sprintf($this->language->get('text_order'), $this->request->get['order_id']);
            $data['text_shipping_info'] = $this->language->get('text_shipping_info');
            $data['text_products_info'] = $this->language->get('text_products_info');
            $data['text_ship_whole_order'] = $this->language->get('text_ship_whole_order');

            $data['column_skuId'] = $this->language->get('column_skuId');
            $data['column_skuName'] = $this->language->get('column_skuName');
            $data['column_itemPriceInclVat'] = $this->language->get('column_itemPriceInclVat');
            $data['column_totalNumberOfItems'] = $this->language->get('column_totalNumberOfItems');
            $data['column_pendingItems'] = $this->language->get('column_pendingItems');
            $data['column_confirmedItems'] = $this->language->get('column_confirmedItems');
            $data['column_shippedItems'] = $this->language->get('column_shippedItems');
            $data['column_cancelledItems'] = $this->language->get('column_cancelledItems');
            $data['column_itemsWithException'] = $this->language->get('column_itemsWithException');
            $data['column_action'] = $this->language->get('column_action');

            $data['column_trackingUrl'] = $this->language->get('column_trackingUrl');
            $data['column_trackingCode'] = $this->language->get('column_trackingCode');
            $data['column_messageToCustomer'] = $this->language->get('column_messageToCustomer');
            $data['column_messageToFruugo'] = $this->language->get('column_messageToFruugo');

            $data['entry_customer_id'] = $this->language->get('entry_customer_id');
            $data['entry_orderId'] = $this->language->get('entry_orderId');
            $data['entry_order_date'] = $this->language->get('entry_order_date');
            $data['entry_fruugo_status'] = $this->language->get('entry_fruugo_status');
            $data['entry_language_code'] = $this->language->get('entry_language_code');
            $data['entry_shipping_method'] = $this->language->get('entry_shipping_method');
            $data['entry_shippingCostInclVAT'] = $this->language->get('entry_shippingCostInclVAT');
            $data['entry_shippingCostVAT'] = $this->language->get('entry_shippingCostVAT');

            $data['entry_shipping_firstname'] = $this->language->get('entry_shipping_firstname');
            $data['entry_shipping_lastname'] = $this->language->get('entry_shipping_lastname');
            $data['entry_shipping_address_1'] = $this->language->get('entry_shipping_address_1');
            $data['entry_shipping_city'] = $this->language->get('entry_shipping_city');
            $data['entry_shipping_postcode'] = $this->language->get('entry_shipping_postcode');
            $data['entry_shipping_iso_code_3'] = $this->language->get('entry_shipping_iso_code_3');
            $data['entry_telephone'] = $this->language->get('entry_telephone');

            $data['button_edit'] = $this->language->get('button_edit');
            $data['button_cancel'] = $this->language->get('button_cancel');

            $url = '';

            if (isset($this->request->get['filter_order_id'])) {
                $url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
            }

            if (isset($this->request->get['filter_customer'])) {
                $url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
            }

            if (isset($this->request->get['filter_order_status'])) {
                $url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
            }

            if (isset($this->request->get['filter_fruugo_order_status'])) {
                $url .= '&filter_fruugo_order_status=' . $this->request->get['filter_fruugo_order_status'];
            }

            if (isset($this->request->get['filter_total'])) {
                $url .= '&filter_total=' . $this->request->get['filter_total'];
            }

            if (isset($this->request->get['filter_date_added'])) {
                $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
            }

            if (isset($this->request->get['filter_date_modified'])) {
                $url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
            }

            if (isset($this->request->get['sort'])) {
                $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                $url .= '&order=' . $this->request->get['order'];
            }

            if (isset($this->request->get['page'])) {
                $url .= '&page=' . $this->request->get['page'];
            }

            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . $url, true)
            );

            $data['shipping'] = $this->url->link('ced_fruugo/order/shipping', 'token=' . $this->session->data['token'] . '&order_id=' . (int)$this->request->get['order_id'], true);
            $data['invoice'] = $this->url->link('ced_fruugo/order/invoice', 'token=' . $this->session->data['token'] . '&order_id=' . (int)$this->request->get['order_id'], true);
            $data['edit'] = $this->url->link('ced_fruugo/order/edit', 'token=' . $this->session->data['token'] . '&order_id=' . (int)$this->request->get['order_id'], true);
            $data['cancel'] = $this->url->link('ced_fruugo/order', 'token=' . $this->session->data['token'] . $url, true);

            $data['token'] = $this->session->data['token'];

            $data['order_id'] = $this->request->get['order_id'];
            
            if(!empty($this->config->get('ced_fruugo_customer_id')))
                $data['customer_prefix'] = $this->config->get('ced_fruugo_customer_id');
            else
                $data['customer_prefix'] = '';

            $data['customer_id'] = $order_info['customer_id'];
            $data['OrderId']     = $order_info['OrderId'];
            $data['order_date'] = $order_info['date_added'];
            $data['fruugo_status'] = $order_info['fruugo_status'];
            $data['language_code'] = $order_info['language_code'];
            $data['shipping_method'] = $order_info['shipping_method'];
            $data['shippingCostInclVAT'] = '0';
            $data['shippingCostVAT'] = '0';

            $data['shipping_firstname'] = $order_info['shipping_firstname'];
            $data['shipping_lastname'] = $order_info['shipping_lastname'];
            $data['shipping_address_1'] = $order_info['shipping_address_1'];
            $data['shipping_city'] = $order_info['shipping_city'];
            $data['shipping_postcode'] = $order_info['shipping_postcode'];
            $data['shipping_iso_code_3'] = $order_info['shipping_iso_code_3'];
            $data['telephone'] = $order_info['telephone'];

           //            echo '<pre>'; print_r($order_info['order_data']); die;
            if(isset($order_info['order_data']) && is_array($order_info['order_data']) && !empty($order_info['order_data'])){
                if(!isset($order_info['order_data']['0']))
                {
                    $temp_array = $order_info['order_data'];
                    $order_info['order_data'] = array();
                    $order_info['order_data']['0'] = $temp_array;
                }
                foreach($order_info['order_data'] as $key => $value)
                {
                    $data['productInfo'][] = array(
                        'productId' => $value['o:productId'],
                        'skuId' => $value['o:skuId'],
                        'skuName' => $value['o:skuName'],
                        'itemPriceInclVat' => $value['o:itemPriceInclVat'],
                        'totalNumberOfItems' => $value['o:totalNumberOfItems'],
                        'pendingItems' => $value['o:pendingItems'],
                        'confirmedItems' => $value['o:confirmedItems'],
                        'shippedItems' => $value['o:shippedItems'],
                        'cancelledItems' => $value['o:cancelledItems'],
                        'itemsWithException' => $value['o:itemsWithException'],
                        'fruugoSkuId' => $value['o:fruugoSkuId'],
                        'fruugoProductId' => $value['o:fruugoProductId'],
                        'href' => $this->url->link('catalog/product/edit', '&product_id=' . $value['o:productId'] .  '&token=' . $this->session->data['token'], true)
                    );
                }
            }
            $data['OrderTotal'] = $order_info['total'];
            //echo '<pre>'; print_r($order_info); die;
            $data['shipmentId'] = isset($order_info['shipmentData']['0']) ? $order_info['shipmentData']['0']['o:shipment']['o:shipmentId'] : '';
            $data['shipping_info'] = isset($order_info['shipmentData']) ? $order_info['shipmentData'] : '';
            $data['store_id'] = $order_info['store_id'];
            $data['store_name'] = $order_info['store_name'];

            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');

            $this->response->setOutput($this->load->view('ced_fruugo/order_info.tpl', $data));
        } else {
            return new Action('error/not_found');
        }
    }

	public function acceptOrder() {

        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);

        $this->load->language('ced_fruugo/order');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('ced_fruugo/order');

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {

            if(isset($this->request->post['selected']) && !empty($this->request->post['selected']))
            {
                if(!is_array($this->request->post['selected'])){
                    $temp_array = $this->request->post['selected'];
                    $this->request->post['selected'] = array();
                    $this->request->post['selected']['0'] = $temp_array;
                }

                foreach ($this->request->post['selected'] as $key => $opencart_order_id) {
                    
                    $query = $this->db->query("SELECT fruugo_order_id FROM `". DB_PREFIX ."cedfruugo_order` WHERE opencart_order_id = '".$opencart_order_id."' ");
                    $fruugo_order_id = $query->row['fruugo_order_id'];
                    $quantity ='';
                    $fruugoSkuId = '';
                    $fruugoProductId = '';
                    $messageToFruugo = '';
                    $messageToCustomer = '';
                    $estimatedShippingDate = '';

                    if(isset($this->request->post['commonEstimateShippingDate']) && !empty($this->request->post['commonEstimateShippingDate']))
                        $estimatedShippingDate = $this->request->post['commonEstimateShippingDate'];
                    if(isset($this->request->post['commonMessageToCustomer']) && !empty($this->request->post['commonMessageToCustomer']))
                        $messageToCustomer = $this->request->post['commonMessageToCustomer'];
                    if(isset($this->request->post['commonMessageToFruugo']) && !empty($this->request->post['commonMessageToFruugo']))
                        $messageToFruugo = $this->request->post['commonMessageToFruugo'];

                    $result = $cedfruugo->acceptOrderByFruugoId($fruugo_order_id, $quantity, $fruugoSkuId, $fruugoProductId, $messageToFruugo, $messageToCustomer, $estimatedShippingDate);

                    if(isset($result['success']) && $result['success'] && isset($result['response']))
                    {
                        $data = $cedfruugo->xml2array($result['response']);
                        $cedfruugo->log('processBulkAcknowledge -data');
                        $cedfruugo->log($data);
                        $fruugoOrderResponse = $data['o:orders']['o:order'];

                        $orderData = $fruugoOrderResponse['o:orderLines']['o:orderLine'];

                        if(!empty($this->config->get('ced_fruugo_order_accepted'))){
                            $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". $this->config->get('ced_fruugo_order_accepted') ."' AND language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
                            $res = $sql->row['name'];
                            $orderStatus = $res;
                        } else {
                            $orderStatus = $fruugoOrderResponse['o:orderStatus'];

                            if($orderStatus == 'COMPLETE')
                                $orderStatus = 'Completed';
                            elseif($orderStatus == 'PENDING')
                                $orderStatus = 'Pending';
                            elseif($orderStatus == 'CANCELLED')
                                $orderStatus = 'Cancelled';
                            elseif($orderStatus == 'SHIPPED')
                                $orderStatus = 'Shipped';
                            elseif($orderStatus == 'PROCESSED')
                                $orderStatus = 'Processed';
                            else
                                $orderStatus = $orderStatus;
                        }

                        if(isset($fruugoOrderResponse['o:shipments']) && !empty($fruugoOrderResponse['o:shipments'])){
                            $shipmentData = $fruugoOrderResponse['o:shipments'];
                        } else {
                            $shipmentData = array();
                        }

                        $cedfruugo->updateOrderStatus($fruugo_order_id, $orderStatus);
                        $cedfruugo->updatefruugoOrderData($fruugo_order_id, $orderStatus, $orderData, $shipmentData);

                        $this->response->addHeader('Content-Type: application/json');
                        $this->response->setOutput(json_encode(array('success' => true,'message' => 'Order Accepted Successfully')));
                    } else {
                        $error_res = 'Some Error While Accepting Order.';
                        if(isset($result['message']))
                            $error_res = $result['message'];
                        $this->response->addHeader('Content-Type: application/json');
                        $this->response->setOutput(json_encode(array('success' => false,'message' => $error_res)));
                    }
                }
            } else {
                $fruugoProductId = $this->request->post['fruugoProductId'];
                $fruugoSkuId = $this->request->post['fruugoSkuId'];
                $quantity = $this->request->post['quantity'];
                $fruugo_order_id = $this->request->post['fruugo_order_id'];
                $messageToCustomer = $this->request->post['messageToCustomer'];
                $messageToFruugo = $this->request->post['messageToFruugo'];
                $estimatedShippingDate = $this->request->post['estimatedShippingDate'];

                if(isset($this->request->post['commonEstimateShippingDate']) && !empty($this->request->post['commonEstimateShippingDate']))
                    $estimatedShippingDate = $this->request->post['commonEstimateShippingDate'];
                if(isset($this->request->post['commonMessageToCustomer']) && !empty($this->request->post['commonMessageToCustomer']))
                    $messageToCustomer = $this->request->post['commonMessageToCustomer'];
                if(isset($this->request->post['commonMessageToFruugo']) && !empty($this->request->post['commonMessageToFruugo']))
                    $messageToFruugo = $this->request->post['commonMessageToFruugo'];

                $result = $cedfruugo->acceptOrderByFruugoId($fruugo_order_id, $quantity, $fruugoSkuId, $fruugoProductId,$messageToFruugo, $messageToCustomer, $estimatedShippingDate);

                if(isset($result['success']) && $result['success'] == true && isset($result['response']))
                {
                    $data = $cedfruugo->xml2array($result['response']);
                    $cedfruugo->log('processBulkAcknowledge -data');
                    $cedfruugo->log($data);
                    $fruugoOrderResponse = $data['o:orders']['o:order'];

                    $orderData = $fruugoOrderResponse['o:orderLines']['o:orderLine'];

                    if(!empty($this->config->get('ced_fruugo_order_accepted'))){
                        $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". $this->config->get('ced_fruugo_order_accepted') ."' AND language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
                        $res = $sql->row['name'];
                        $orderStatus = $res;
                    } else {
                        $orderStatus = $fruugoOrderResponse['o:orderStatus'];

                        if($orderStatus == 'COMPLETE')
                            $orderStatus = 'Completed';
                        elseif($orderStatus == 'PENDING')
                            $orderStatus = 'Pending';
                        elseif($orderStatus == 'CANCELLED')
                            $orderStatus = 'Cancelled';
                        elseif($orderStatus == 'SHIPPED')
                            $orderStatus = 'Shipped';
                        elseif($orderStatus == 'PROCESSED')
                            $orderStatus = 'Processed';
                        else
                            $orderStatus = $orderStatus;
                    }

                    if(isset($fruugoOrderResponse['o:shipments']) && !empty($fruugoOrderResponse['o:shipments'])){
                        $shipmentData = $fruugoOrderResponse['o:shipments'];
                    } else {
                        $shipmentData = array();
                    }

                    $cedfruugo->updateOrderStatus($fruugo_order_id, $orderStatus);
                    $cedfruugo->updatefruugoOrderData($fruugo_order_id, $orderStatus, $orderData, $shipmentData);
                    die(json_encode(array('success' => true,'message' => 'Order Accepted Successfully')));
                } else {
                    $error_res = 'Some Error While Accepting Order.';
                    if(isset($result['message']))
                        $error_res = $result['message'];
                    die(json_encode(array('success' => false,'message' => $error_res)));
                }

            }
        }

    }

    public function cancelOrder(){

        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);

        $this->load->language('ced_fruugo/order');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('ced_fruugo/order');

        if($this->request->server['REQUEST_METHOD'] == 'POST') {

            $fruugoProductId = $this->request->post['fruugoProductId'];
            $fruugoSkuId = $this->request->post['fruugoSkuId'];
            $quantity = $this->request->post['quantity'];
            $fruugo_order_id = $this->request->post['fruugo_order_id'];
            $messageToCustomer = $this->request->post['messageToCustomer'];
            $messageToFruugo = $this->request->post['messageToFruugo'];
            $cancellationReason = $this->request->post['cancellationReason'];

            $result = $cedfruugo->cancelOrderByFruugoId($fruugo_order_id, $quantity, $fruugoSkuId, $fruugoProductId,$messageToFruugo, $messageToCustomer, $cancellationReason);

            if(isset($result['success']) && $result['success'] && isset($result['response'])) {
                $data = $cedfruugo->xml2array($result['response']);
                $cedfruugo->log('cancelOrder -data');
                $cedfruugo->log($data);
                $fruugoOrderResponse = $data['o:orders']['o:order'];

                $orderData = $fruugoOrderResponse['o:orderLines']['o:orderLine'];

                if(!empty($this->config->get('ced_fruugo_order_rejected'))){
                    $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". $this->config->get('ced_fruugo_order_rejected') ."' AND language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
                    $res = $sql->row['name'];
                    $orderStatus = $res;
                } else {
                    $orderStatus = $fruugoOrderResponse['o:orderStatus'];

                    if($orderStatus == 'COMPLETE')
                        $orderStatus = 'Completed';
                    elseif($orderStatus == 'PENDING')
                        $orderStatus = 'Pending';
                    elseif($orderStatus == 'CANCELLED')
                        $orderStatus = 'Cancelled';
                    elseif($orderStatus == 'SHIPPED')
                        $orderStatus = 'Shipped';
                    elseif($orderStatus == 'PROCESSED')
                        $orderStatus = 'Processed';
                    else
                        $orderStatus = $orderStatus;
                }

                if(isset($fruugoOrderResponse['o:shipments']) && !empty($fruugoOrderResponse['o:shipments'])){
                    $shipmentData = $fruugoOrderResponse['o:shipments'];
                } else {
                    $shipmentData = array();
                }

                $cedfruugo->updateOrderStatus($fruugo_order_id, $orderStatus);
                $cedfruugo->updatefruugoOrderData($fruugo_order_id, $orderStatus, $orderData, $shipmentData);
                die(json_encode(array('success' => true,'message' => 'Order Cancelled Successfully')));
            } else {
                $error_res = 'Some Error While Cancelling Order.';
                if(isset($result['message']))
                    $error_res = $result['message'];
                die(json_encode(array('success' => false,'message' => $error_res)));
            }

        }
    }

    public function shipOrder(){

        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);

        $this->load->language('ced_fruugo/order');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('ced_fruugo/order');

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {

            $fruugoProductId = $this->request->post['fruugoProductId'];
            $fruugoSkuId = $this->request->post['fruugoSkuId'];
            $quantity = $this->request->post['quantity'];
            $fruugo_order_id = $this->request->post['fruugo_order_id'];
            $messageToCustomer = $this->request->post['messageToCustomer'];
            $messageToFruugo = $this->request->post['messageToFruugo'];
            $trackingCode = $this->request->post['trackingCode'];
            $trackingUrl = $this->request->post['trackingUrl'];

            $result = $cedfruugo->shipOrderByFruugoId($fruugo_order_id, $quantity, $fruugoSkuId, $fruugoProductId,$messageToFruugo, $messageToCustomer, $trackingCode ,$trackingUrl);

            if(isset($result['success']) && $result['success'] && isset($result['response'])) {
                $data = $cedfruugo->xml2array($result['response']);
                $cedfruugo->log('shipOrder -data');
                $cedfruugo->log($data);
                $fruugoOrderResponse = $data['o:orders']['o:order'];

                $orderData = $fruugoOrderResponse['o:orderLines']['o:orderLine'];

                if(!empty($this->config->get('ced_fruugo_order_shipped'))){
                    $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". $this->config->get('ced_fruugo_order_shipped') ."' AND language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
                    $res = $sql->row['name'];
                    $orderStatus = $res;
                } else {
                    $orderStatus = $fruugoOrderResponse['o:orderStatus'];

                    if($orderStatus == 'COMPLETE')
                        $orderStatus = 'Completed';
                    elseif($orderStatus == 'PENDING')
                        $orderStatus = 'Pending';
                    elseif($orderStatus == 'CANCELLED')
                        $orderStatus = 'Cancelled';
                    elseif($orderStatus == 'SHIPPED')
                        $orderStatus = 'Shipped';
                    elseif($orderStatus == 'PROCESSED')
                        $orderStatus = 'Processed';
                    else
                        $orderStatus = $orderStatus;
                }

                if(isset($fruugoOrderResponse['o:shipments']) && !empty($fruugoOrderResponse['o:shipments'])){
                    $shipmentData = $fruugoOrderResponse['o:shipments'];
                } else {
                    $shipmentData = array();
                }

                $cedfruugo->updateOrderStatus($fruugo_order_id, $orderStatus);
                $cedfruugo->updatefruugoOrderData($fruugo_order_id, $orderStatus, $orderData, $shipmentData);
                die(json_encode(array('success' => true,'message' => 'Order Shipped Successfully')));
            } else {
                $error_res = 'Some Error While Shipment.';
                if(isset($result['message']))
                    $error_res = $result['message'];
                die(json_encode(array('success' => false,'message' => $error_res)));
            }
        }
    }

    public function shipCompleteOrder(){

        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);

        $this->load->language('ced_fruugo/order');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('ced_fruugo/order');

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {

            $fruugo_order_id = $this->request->post['fruugo_order_id'];
            $messageToCustomer = $this->request->post['messageToCustomer'];
            $messageToFruugo = $this->request->post['messageToFruugo'];
            $trackingCode = $this->request->post['trackingCode'];
            $trackingUrl = $this->request->post['trackingUrl'];

            $result = $cedfruugo->shipCompleteOrder($fruugo_order_id, $messageToFruugo, $messageToCustomer, $trackingCode ,$trackingUrl);

            if(isset($result['success']) && $result['success'] && isset($result['response'])) {
                $data = $cedfruugo->xml2array($result['response']);
                $cedfruugo->log('processBulkAcknowledge -data');
                $cedfruugo->log($data);
                $fruugoOrderResponse = $data['o:orders']['o:order'];
                $orderStatus = $fruugoOrderResponse['o:orderStatus'];
                $orderData = $fruugoOrderResponse['o:orderLines']['o:orderLine'];

                if(!empty($this->config->get('ced_fruugo_order_shipped'))){
                    $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". $this->config->get('ced_fruugo_order_shipped') ."' AND language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
                    $res = $sql->row['name'];
                    $orderStatus = $res;
                } else {
                    $orderStatus = $fruugoOrderResponse['o:orderStatus'];

                    if($orderStatus == 'COMPLETE')
                        $orderStatus = 'Completed';
                    elseif($orderStatus == 'PENDING')
                        $orderStatus = 'Pending';
                    elseif($orderStatus == 'CANCELLED')
                        $orderStatus = 'Cancelled';
                    elseif($orderStatus == 'SHIPPED')
                        $orderStatus = 'Shipped';
                    elseif($orderStatus == 'PROCESSED')
                        $orderStatus = 'Processed';
                    else
                        $orderStatus = $orderStatus;
                }

                if(isset($fruugoOrderResponse['o:shipments']) && !empty($fruugoOrderResponse['o:shipments'])){
                    $shipmentData = $fruugoOrderResponse['o:shipments'];
                } else {
                    $shipmentData = array();
                }

                $cedfruugo->updateOrderStatus($fruugo_order_id, $orderStatus);
                $cedfruugo->updatefruugoOrderData($fruugo_order_id, $orderStatus, $orderData, $shipmentData);
                die(json_encode(array('success' => true,'message' => 'Order Shipped Successfully')));
            } else {
                $error_res = 'Some Error While Shipment.';
                if(isset($result['message']))
                    $error_res = $result['message'];
                die(json_encode(array('success' => false,'message' => $error_res)));
            }
        }
    }
	
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'ced_fruugo/order')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function updateReceipt() {
		$post_data = $this->request->post;

		$receipt_id = 0;
		if(isset($post_data['receipt_id'])){
			$receipt_id = (int)$post_data['receipt_id'];
			unset($post_data['receipt_id']);
		}

		if(!$receipt_id) {
			$json = array('error' =>  'receipt_id Not Valid.');
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
		}

		$shop_id = $this->config->get('ced_fruugo_shop_name');

		if(!$shop_id) {
			$json = array('error' => 'shop_id Not Valid.');
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
		}
		$this->load->library('cedfruugo');
		$cedfruugo = Cedfruugo::getInstance($this->registry); 
		$result = $cedfruugo->updateReceipt($receipt_id ,$shop_id, $post_data);
		if(isset($result['success']) && $result['success']) {
			$json = array('success' =>  'Updated Successfully.');
		} else {
			$json = array('error' => $result['message']);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function addTracking() {
		$post_data = $this->request->post;
		if(isset($post_data['send_bcc']))
			$post_data['send_bcc'] = (bool)$post_data['send_bcc'];

		$receipt_id = 0;
		if(isset($post_data['receipt_id'])){
			$receipt_id = (int)$post_data['receipt_id'];
			unset($post_data['receipt_id']);
		}

		if(!$receipt_id) {
			$json = array('error' =>  'receipt_id Not Valid.');
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
		}

		$shop_id = $this->config->get('ced_fruugo_shop_name');

		if(!$shop_id) {
			$json = array('error' => 'shop_id Not Valid.');
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
		}
		$this->load->library('cedfruugo');
		$cedfruugo = Cedfruugo::getInstance($this->registry); 
		$result = $cedfruugo->addTracking($receipt_id ,$shop_id, $post_data);
		if(isset($result['success']) && $result['success']) {
			$json = array('success' =>  'Updated Successfully.');
		} else {
			$json = array('error' => $result['message']);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function rejected()
	{
		$this->load->language('ced_fruugo/rejectedorder');
		$this->document->setTitle($this->language->get('heading_title'));
		if (isset($this->request->get['filter_order_id'])) {
			$filter_order_id = $this->request->get['filter_order_id'];
		} else {
			$filter_order_id = null;
		}

		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = null;
		}

		if (isset($this->request->get['filter_order_status'])) {
			$filter_order_status = $this->request->get['filter_order_status'];
		} else {
			$filter_order_status = null;
		}

		if (isset($this->request->get['filter_fruugo_order_status'])) {
				$filter_fruugo_order_status = $this->request->get['filter_fruugo_order_status'];
		} else {
			$filter_fruugo_order_status = null;
		}

		if (isset($this->request->get['filter_total'])) {
			$filter_total = $this->request->get['filter_total'];
		} else {
			$filter_total = null;
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = null;
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$filter_date_modified = $this->request->get['filter_date_modified'];
		} else {
			$filter_date_modified = null;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'o.order_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		}

		if (isset($this->request->get['filter_fruugo_order_status'])) {
			$url .= '&filter_fruugo_order_status=' . $this->request->get['filter_fruugo_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$this->load->model('user/api');
		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_fruugo/order/rejected', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);

		$data['invoice'] = $this->url->link('ced_fruugo/order/invoice', 'token=' . $this->session->data['token'], 'SSL');
		$data['shipping'] = $this->url->link('ced_fruugo/order/shipping', 'token=' . $this->session->data['token'], 'SSL');
		$data['add'] = $this->url->link('ced_fruugo/order/add', 'token=' . $this->session->data['token'], 'SSL');
		$data['multi'] =$this->url->link('ced_fruugo/acknowledge/multiacknowledge', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$data['orders'] = array();

		$filter_data = array(
			'filter_order_id'      => $filter_order_id,
			'filter_customer'	   => $filter_customer,
			'filter_order_status'  => $filter_order_status,
			'filter_fruugo_order_status' => $filter_fruugo_order_status,
			'filter_total'         => $filter_total,
			'filter_date_added'    => $filter_date_added,
			'filter_date_modified' => $filter_date_modified,
			'sort'                 => $sort,
			'order'                => $order,
			'start'                => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                => $this->config->get('config_limit_admin')
		);
			$this->load->model('ced_fruugo/order');
			$order_total=$this->model_ced_fruugo_order->getRejectedTotals();
			$results = $this->model_ced_fruugo_order->getrejectedOrders();
		
		if($results)
		{
				foreach ($results as $result) {
				$data['orders'][] = array(
					'id'      => $result['id'],
					'sku'      => $result['sku'],
					'reason'        => $result['error_message'],
					'view'          => $this->url->link('ced_fruugo/order/rejectview', 'token=' . $this->session->data['token'] . '&id=' . $result['id'] . $url, 'SSL')
					
				);
			}
		}
		
		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');
		$data['text_missing'] = $this->language->get('text_missing');

		$data['column_order_id'] = $this->language->get('column_order_id');
		$data['column_customer'] = $this->language->get('column_customer');
		$data['column_status'] = $this->language->get('column_status');
		$data['column_total'] = $this->language->get('column_total');
		$data['column_fruugo_order_id'] = $this->language->get('column_fruugo_order_id');
		$data['column_fruugo_status'] = $this->language->get('column_fruugo_status');
		$data['column_date_added'] = $this->language->get('column_date_added');
		$data['column_date_modified'] = $this->language->get('column_date_modified');
		$data['column_action'] = $this->language->get('column_action');

		$data['entry_return_id'] = $this->language->get('entry_return_id');
		$data['entry_order_id'] = $this->language->get('entry_order_id');
		$data['entry_customer'] = $this->language->get('entry_customer');
		$data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['entry_total'] = $this->language->get('entry_total');
		$data['entry_date_added'] = $this->language->get('entry_date_added');
		$data['entry_fruugo_order_status'] = $this->language->get('entry_fruugo_order_status');
		// $data['entry_date_modified'] = $this->language->get('entry_date_modified');

		$data['button_invoice_print'] = $this->language->get('button_invoice_print');
		$data['button_shipping_print'] = $this->language->get('button_shipping_print');
		$data['button_insert'] = $this->language->get('button_insert');
		$data['button_edit'] = $this->language->get('viewrejected');
		$data['button_delete'] = $this->language->get('button_delete');
		$data['button_filter'] = $this->language->get('button_filter');
		$data['button_view'] = $this->language->get('button_view');

		$data['token'] = $this->session->data['token'];
	     // $this->error['warning'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
	    //	die;
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		} 

		if (isset($this->request->get['filter_fruugo_order_status'])) {
			$url .= '&filter_fruugo_order_status=' . $this->request->get['filter_fruugo_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_order'] = $this->url->link('ced_fruugo/order/rejected', 'token=' . $this->session->data['token'] . '&sort=o.order_id' . $url, 'SSL');
		$data['sort_customer'] = $this->url->link('ced_fruugo/order/rejected', 'token=' . $this->session->data['token'] . '&sort=customer' . $url, 'SSL');
		$data['sort_status'] = $this->url->link('ced_fruugo/order/rejected', 'token=' . $this->session->data['token'] . '&sort=status' . $url, 'SSL');
		$data['sort_total'] = $this->url->link('ced_fruugo/order/rejected', 'token=' . $this->session->data['token'] . '&sort=o.total' . $url, 'SSL');
		$data['sort_date_added'] = $this->url->link('ced_fruugo/order/rejected', 'token=' . $this->session->data['token'] . '&sort=o.date_added' . $url, 'SSL');
		$data['sort_date_modified'] = $this->url->link('ced_fruugo/order/rejected', 'token=' . $this->session->data['token'] . '&sort=o.date_modified' . $url, 'SSL');

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		} 

		if (isset($this->request->get['filter_fruugo_order_status'])) {
			$url .= '&filter_fruugo_order_status=' . $this->request->get['filter_fruugo_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $order_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('sale/order', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));

		$data['filter_order_id'] = $filter_order_id;
		$data['filter_customer'] = $filter_customer;
		$data['filter_order_status'] = $filter_order_status;
		$data['filter_fruugo_order_status'] = $filter_fruugo_order_status;
		$data['filter_total'] = $filter_total;
		$data['filter_date_added'] = $filter_date_added;
		$data['filter_date_modified'] = $filter_date_modified;

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_fruugo/rejectedorder.tpl', $data));

	}
	public function rejectview()
	{
		if (isset($this->request->get['id']))
		{
		$this->load->language('ced_fruugo/rejectedorder');
		$this->document->setTitle($this->language->get('heading_title'));
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_fruugo/order/rejectview', 'token=' . $this->session->data['token']  . '&id=' . $this->request->get['id'], 'SSL')
		);
		$data['back'] = $this->url->link('ced_fruugo/order/rejected', 'token=' . $this->session->data['token']);
		$id= $this->request->get['id'];
		$this->load->model('ced_fruugo/order');
		$json=$this->model_ced_fruugo_order->getRejectedOrderJson($id);
		$results=json_decode($json,true);
		
		if(count($results))
		{
			$data['orders']=$results;
		}
		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');
		$data['text_missing'] = $this->language->get('text_missing');

		$data['column_order_id'] = $this->language->get('column_order_id');
		$data['column_customer'] = $this->language->get('column_customer');
		$data['column_status'] = $this->language->get('column_status');
		$data['column_total'] = $this->language->get('column_total');
		$data['column_product']=$this->language->get('column_product');
		$data['column_fruugo_order_id'] = $this->language->get('column_fruugo_order_id');
		$data['column_fruugo_status'] = $this->language->get('column_fruugo_status');
		$data['column_date_added'] = $this->language->get('column_date_added');
		$data['column_date_modified'] = $this->language->get('column_date_modified');
		$data['column_action'] = $this->language->get('column_action');

		$data['entry_return_id'] = $this->language->get('entry_return_id');
		$data['entry_order_id'] = $this->language->get('entry_order_id');
		$data['entry_customer'] = $this->language->get('entry_customer');
		$data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['entry_total'] = $this->language->get('entry_total');
		$data['entry_date_added'] = $this->language->get('entry_date_added');
		$data['entry_fruugo_order_status'] = $this->language->get('entry_fruugo_order_status');
		// $data['entry_date_modified'] = $this->language->get('entry_date_modified');

		$data['button_invoice_print'] = $this->language->get('button_invoice_print');
		$data['button_shipping_print'] = $this->language->get('button_shipping_print');
		$data['button_insert'] = $this->language->get('button_insert');
		$data['button_edit'] = $this->language->get('viewrejected');
		$data['button_delete'] = $this->language->get('button_delete');
		$data['button_filter'] = $this->language->get('button_filter');
		$data['button_view'] = $this->language->get('button_view');
		$data['Items'] = $this->language->get('Items');
		$data['order_id'] = $this->language->get('order_id');
		$data['customer_reference_order_id'] = $this->language->get('customer_reference_order_id');
		$data['fulfillment_node'] = $this->language->get('fulfillment_node');
		$data['order_placed_date'] = $this->language->get('order_placed_date');
		$data['order_transmission_date'] = $this->language->get('order_transmission_date');
		$data['phone_number'] = $this->language->get('phone_number');
		$data['recipient'] = $this->language->get('recipient');
		$data['recipient_phone_number'] = $this->language->get('recipient_phone_number');
		$data['ship_to_address1'] = $this->language->get('ship_to_address1');
		$data['ship_to_address2'] = $this->language->get('ship_to_address2');
		$data['ship_to_city'] = $this->language->get('ship_to_city');
		$data['ship_to_state'] = $this->language->get('ship_to_state');
		$data['ship_to_zip_code'] = $this->language->get('ship_to_zip_code');
		$data['ship_to_state'] = $this->language->get('ship_to_state');
		$data['rejected_merchant_sku'] = $this->language->get('rejected_merchant_sku');
		$data['button_Back']= $this->language->get('button_Back');

		$data['token'] = $this->session->data['token'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_fruugo/rejectedorderview.tpl', $data));


		}
	}

    public function packingList()
    {
        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);

        $this->load->language('ced_fruugo/order');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('ced_fruugo/order');

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            $fruugo_order_id = $this->request->post['orderId'];
            $shipment_id = $this->request->post['shipmentId'];

            $result = $cedfruugo->packingListByFruugo($fruugo_order_id, $shipment_id);

            if(isset($result['success']) && $result['success'])
            {
                $pdf_dir = DIR_IMAGE . 'cedfruugo/packing_list/';

                if (!is_dir($pdf_dir)) {
                    mkdir($pdf_dir, '0777', true);
                }

                $filename = $pdf_dir . $fruugo_order_id . '_' . $shipment_id . '.pdf';

                if(file_exists($filename)) {
                    try {
                        $file = fopen($filename, 'w');

                        file_put_contents($filename, $result);
                        fclose($file);

                    } catch (Exception $e) {
                        return $e->getMessage();
                    }

                } else {
                    $file = fopen($filename, 'w');

                    file_put_contents($filename, $result);
                    fclose($file);
                }
                $pdf_path = HTTPS_CATALOG .'image/cedfruugo/packing_list/'. $fruugo_order_id . '_' . $shipment_id . '.pdf';

                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode(array('success' => true,'message' => 'Packing Slip Generated Successfully!', 'img_path' => $pdf_path)));
            } else {
                $error_res = 'Some Error While Packing List.';
                if(isset($result['message']) && !empty($result['message']))
                    $error_res = $result['message'];
                $this->response->addHeader('Content-Type: application/json');
                $this->response->setOutput(json_encode(array('success' => false,'message' => $error_res, 'img_path' => '')));
            }
        }
    }

	
}