<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

class ControllerCedFruugoProduct extends Controller {
    private $error = array();

    public function index() {

        $this->load->language('ced_fruugo/product');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('catalog/product');
        $this->load->model('ced_fruugo/product');

        $this->getList();
    }
    protected function getList() {

        if (isset($this->request->get['filter_name'])) {
            $filter_name = $this->request->get['filter_name'];
        } else {
            $filter_name = null;
        }

        if (isset($this->request->get['filter_model'])) {
            $filter_model = $this->request->get['filter_model'];
        } else {
            $filter_model = null;
        }

        if (isset($this->request->get['filter_price'])) {
            $filter_price = $this->request->get['filter_price'];
        } else {
            $filter_price = null;
        }

        if (isset($this->request->get['filter_quantity'])) {
            $filter_quantity = $this->request->get['filter_quantity'];
        } else {
            $filter_quantity = null;
        }

        if (isset($this->request->get['filter_status'])) {
            $filter_status = $this->request->get['filter_status'];
        } else {
            $filter_status = null;
        }

        if (isset($this->request->get['filter_fruugo_status'])) {
            $filter_fruugo_status = $this->request->get['filter_fruugo_status'];
        } else {
            $filter_fruugo_status = null;
        }

        if (isset($this->request->get['filter_image'])) {
            $filter_image = $this->request->get['filter_image'];
        } else {
            $filter_image = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = ' ppm.created_on';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'DESC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_image'])) {
            $url .= '&filter_image=' . $this->request->get['filter_image'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['filter_fruugo_status'])) {
            $url .= '&filter_fruugo_status=' . $this->request->get['filter_fruugo_status'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_ced_fruugo'),
            'href' => $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . $url, true)
        );

        $data['add'] = $this->url->link('ced_fruugo/product/add', 'token=' . $this->session->data['token'] . $url, true);
        $data['copy'] = $this->url->link('ced_fruugo/product/copy', 'token=' . $this->session->data['token'] . $url, true);
        $data['delete'] = $this->url->link('ced_fruugo/product/delete', 'token=' . $this->session->data['token'] . $url, true);
        $data['clearFeed'] = $this->url->link('ced_fruugo/product/clearFeed', 'token=' . $this->session->data['token'] . $url, true);

        $data['uploadall'] = $this->url->link('ced_fruugo/product/uploadall', 'token=' . $this->session->data['token'] . $url, true);
        $data['fetchStatus'] = $this->url->link('ced_fruugo/product/fetchStatus', 'token=' . $this->session->data['token'] . $url, true);

        $data['products'] = array();

        $filter_data = array(
            'filter_name'	  => $filter_name,
            'filter_model'	  => $filter_model,
            'filter_price'	  => $filter_price,
            'filter_quantity' => $filter_quantity,
            'filter_status'   => $filter_status,
            'filter_fruugo_status' => $filter_fruugo_status,
            'filter_image'    => $filter_image,
            'sort'            => $sort,
            'order'           => $order,
            'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
            'limit'           => $this->config->get('config_limit_admin')
        );

        $this->load->model('tool/image');

        $product_total = $this->model_ced_fruugo_product->getTotalProducts($filter_data);

        $results = $this->model_ced_fruugo_product->getProducts($filter_data);

        foreach ($results as $result) {
            if (is_file(DIR_IMAGE . $result['image'])) {
                $image = $this->model_tool_image->resize($result['image'], 40, 40);
            } else {
                $image = $this->model_tool_image->resize('no_image.png', 40, 40);
            }

            $special = false;
            $this->load->model('catalog/product');
            $product_specials = $this->model_catalog_product->getProductSpecials($result['product_id']);

            foreach ($product_specials  as $product_special) {
                if (($product_special['date_start'] == '0000-00-00' || strtotime($product_special['date_start']) < time()) && ($product_special['date_end'] == '0000-00-00' || strtotime($product_special['date_end']) > time())) {
                    $special = $product_special['price'];

                    break;
                }
            }
            //echo '<pre>'; print_r($result);

            $data['products'][] = array(
                'product_id' => $result['product_id'],
                'image'      => $image,
                'name'       => $result['name'],
                'model'      => $result['model'],
                'price'      => $result['price'],
                'fruugo_SkuId' => $result['fruugo_SkuId'],
                'fruugo_status' => (isset($result['fruugo_status']) && !empty($result['fruugo_status'])) ? $result['fruugo_status']: 'Uploaded',
                'special'    => $special,
                'quantity'   => $result['quantity'],
                'status'     => $result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
                'error_message' => $result['error_message'],
                'edit'       => $this->url->link('catalog/product/edit', 'token=' . $this->session->data['token'] . '&product_id=' . $result['product_id'] . $url, true)
            );
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_list'] = $this->language->get('text_list');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_no_results'] = $this->language->get('text_no_results');
        $data['text_confirm'] = $this->language->get('text_confirm');

        $data['column_image'] = $this->language->get('column_image');
        $data['column_name'] = $this->language->get('column_name');
        $data['column_model'] = $this->language->get('column_model');
        $data['column_price'] = $this->language->get('column_price');
        $data['column_quantity'] = $this->language->get('column_quantity');
        $data['column_status'] = $this->language->get('column_status');
        $data['column_fruugo_SkuId'] = $this->language->get('column_fruugo_SkuId');
        $data['column_fruugo_status'] = $this->language->get('column_fruugo_status');
        $data['column_error_message'] = $this->language->get('column_error_message');
        $data['column_action'] = $this->language->get('column_action');

        $data['entry_name'] = $this->language->get('entry_name');
        $data['entry_model'] = $this->language->get('entry_model');
        $data['entry_price'] = $this->language->get('entry_price');
        $data['entry_quantity'] = $this->language->get('entry_quantity');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_image'] = $this->language->get('entry_image');

        $data['button_copy'] = $this->language->get('button_copy');
        $data['button_add'] = $this->language->get('button_add');
        $data['button_edit'] = $this->language->get('button_edit');
        $data['button_delete'] = $this->language->get('button_delete');
        $data['button_filter'] = $this->language->get('button_filter');

        $data['token'] = $this->session->data['token'];

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->request->post['selected'])) {
            $data['selected'] = (array)$this->request->post['selected'];
        } else {
            $data['selected'] = array();
        }

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_fruugo_status'])) {
            $url .= '&filter_fruugo_status=' . $this->request->get['filter_fruugo_status'];
        }

        if (isset($this->request->get['filter_image'])) {
            $url .= '&filter_image=' . $this->request->get['filter_image'];
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        $data['sort_name'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=pd.name' . $url, true);
        $data['sort_model'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=p.model' . $url, true);
        $data['sort_price'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=p.price' . $url, true);
        $data['sort_quantity'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=p.quantity' . $url, true);
        $data['sort_status'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=p.status' . $url, true);
        $data['sort_fruugo_SkuId'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=p.fruugo_SkuId' . $url, true);
        $data['sort_fruugo_status'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=p.fruugo_status' . $url, true);
        $data['sort_error_message'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=p.error_message' . $url, true);
        $data['sort_order'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . '&sort=p.sort_order' . $url, true);

        $url = '';

        if (isset($this->request->get['filter_name'])) {
            $url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_model'])) {
            $url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_price'])) {
            $url .= '&filter_price=' . $this->request->get['filter_price'];
        }

        if (isset($this->request->get['filter_quantity'])) {
            $url .= '&filter_quantity=' . $this->request->get['filter_quantity'];
        }

        if (isset($this->request->get['filter_status'])) {
            $url .= '&filter_status=' . $this->request->get['filter_status'];
        }

        if (isset($this->request->get['filter_fruugo_status'])) {
            $url .= '&filter_fruugo_status=' . $this->request->get['filter_fruugo_status'];
        }

        if (isset($this->request->get['filter_image'])) {
            $url .= '&filter_image=' . $this->request->get['filter_image'];
        }

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        if (isset($this->request->get['order'])) {
            $url .= '&order=' . $this->request->get['order'];
        }

        $pagination = new Pagination();
        $pagination->total = $product_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_limit_admin');
        $pagination->url = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));

        $data['filter_name'] = $filter_name;
        $data['filter_model'] = $filter_model;
        $data['filter_price'] = $filter_price;
        $data['filter_quantity'] = $filter_quantity;
        $data['filter_status'] = $filter_status;
        $data['filter_fruugo_status'] = $filter_fruugo_status;
        $data['filter_image'] = $filter_image;

        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('ced_fruugo/product_list.tpl', $data));
    }
    public function upload()
    {
        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);
        $product_ids = array();
        if (isset($this->request->post['selected'])) {
            $product_ids = (array)$this->request->post['selected'];
        }
        $response = $cedfruugo->uploadProducts($product_ids);
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($response));
    }
    public function uploadall() {

        $this->load->library('cedfruugo');
        $this->load->language('ced_fruugo/product');
        $this->document->setTitle($this->language->get('heading_title'));
        $cedfruugo = Cedfruugo::getInstance($this->registry);
        $this->load->model('ced_fruugo/product');
        // $productIds = $cedfruugo->getAllfruugoProducts();
        $productIds = $cedfruugo->getAllMappedProducts();
        if(empty($productIds))
            $productIds = $cedfruugo->getAllFruugoProducts();

        if ($productIds && count($productIds)) {
            $total_product =count($productIds);
            $array_chunk_count = ceil($total_product/10);
            $productIds = array_chunk($productIds,$array_chunk_count);
            $status = array();
            $data['product_ids'] = json_encode($productIds);

            $data['heading_title'] = $this->language->get('heading_title');

            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text'      => $this->language->get('text_home'),
                'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
            );

            $data['breadcrumbs'][] = array(
                'text'      => $this->language->get('heading_title'),
                'href'      => $this->url->link('ced_fruugo/product/uploadall', 'token=' . $this->session->data['token'], 'SSL'),
            );
            $data['uploadallProcess'] = $this->url->link('ced_fruugo/product/uploadallProcess', 'token=' . $this->session->data['token'] , 'SSL');

            if (isset($this->error['warning'])) {
                $data['error_warning'] = $this->error['warning'];
            } else {
                $data['error_warning'] = '';
            }
            if (isset($this->session->data['success'])) {
                $data['success'] = $this->session->data['success'];

                unset($this->session->data['success']);
            } else {
                $data['success'] = '';
            }

            if (isset($this->request->post['selected'])) {
                $data['selected'] = (array)$this->request->post['selected'];
            } else {
                $data['selected'] = array();
            }
            $data['cancel'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] , true);
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');

            $this->response->setOutput($this->load->view('ced_fruugo/uploadall.tpl', $data));
        } else {
            $this->error['warning'] = 'No Category Mapped yet';
            $this->getList();
        }
    }
    public function uploadallProcess() {

        $this->load->library('cedfruugo');
        $this->load->language('ced_fruugo/product');
        $this->document->setTitle($this->language->get('heading_title'));
        $productIds = $this->request->post;

        $json = array();
        if ($productIds && isset($productIds['selected']) && count($productIds['selected'])) {

            $cedfruugo = Cedfruugo::getInstance($this->registry);
            $status = array();
            $status = $cedfruugo->uploadProducts($productIds['selected']);

            if (isset($status['success']) && $status['success']) {
                if (!is_array($status['message']))
                    $json['message'] = 'Uploading Product Id(s) '.implode(',', $productIds['selected']).' : '.$status['message'];
                else
                    $json['message'] = 'Uploading Product Id(s) '.implode(',', $productIds['selected']).' : ' .implode(',',$status['message'] );
                $json['success'] = true;
            } else {
                $json['success'] = false;
                $json['message'] = ($status['message'])?$status['message']:'No response to upload see log.';
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'No Category Mapped yet';
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    public function removelisting()
    {
        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);
        $product_ids = array();
        if (isset($this->request->post['selected'])) {
            $product_ids = (array)$this->request->post['selected'];
        }
        $response = $cedfruugo->deleteProducts($product_ids);
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($response));
    }
    public function bulkenable()
    {
        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);
        $product_ids = array();
        if (isset($this->request->post['selected'])) {
            $product_ids = (array)$this->request->post['selected'];
        }
        $response = $cedfruugo->enableProducts($product_ids);
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($response));
    }
    public function bulkdisable()
    {
        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);
        $product_ids = array();
        if (isset($this->request->post['selected'])) {
            $product_ids = (array)$this->request->post['selected'];
        }
        $response = $cedfruugo->disableProducts($product_ids);
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($response));
    }
    public function syncProductData()
    {
        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);
        $product_ids = array();
        $json = array();
        if (isset($this->request->post['selected'])) {
            $product_ids = (array)$this->request->post['selected'];
            $response = $cedfruugo->updateStock($product_ids, 'syncProduct');

            if (isset($response['success']) && $response['success']) {
                if (!is_array($response['message']))
                    $json['message'] = $response['message'];
                else
                    $json['message'] = 'Product(s) Synced Successfully.';
                $json['success'] = true;
            } else {
                $json['success'] = false;
                $json['message'] = ($response['message'])?$response['message']:'No product to sync.';
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'No Category Mapped yet';
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    public function autocomplete() {
        $json = array();

        if (isset($this->request->get['filter_name']) || isset($this->request->get['filter_model'])) {
            $this->load->model('catalog/product');
            $this->load->model('catalog/option');

            if (isset($this->request->get['filter_name'])) {
                $filter_name = $this->request->get['filter_name'];
            } else {
                $filter_name = '';
            }

            if (isset($this->request->get['filter_model'])) {
                $filter_model = $this->request->get['filter_model'];
            } else {
                $filter_model = '';
            }

            if (isset($this->request->get['limit'])) {
                $limit = $this->request->get['limit'];
            } else {
                $limit = 5;
            }

            $filter_data = array(
                'filter_name'  => $filter_name,
                'filter_model' => $filter_model,
                'start'        => 0,
                'limit'        => $limit
            );

            $results = $this->model_catalog_product->getProducts($filter_data);

            foreach ($results as $result) {
                $option_data = array();

                $product_options = $this->model_catalog_product->getProductOptions($result['product_id']);

                foreach ($product_options as $product_option) {
                    $option_info = $this->model_catalog_option->getOption($product_option['option_id']);

                    if ($option_info) {
                        $product_option_value_data = array();

                        foreach ($product_option['product_option_value'] as $product_option_value) {
                            $option_value_info = $this->model_catalog_option->getOptionValue($product_option_value['option_value_id']);

                            if ($option_value_info) {
                                $product_option_value_data[] = array(
                                    'product_option_value_id' => $product_option_value['product_option_value_id'],
                                    'option_value_id'         => $product_option_value['option_value_id'],
                                    'name'                    => $option_value_info['name'],
                                    'price'                   => (float)$product_option_value['price'] ? $this->currency->format($product_option_value['price'], $this->config->get('config_currency')) : false,
                                    'price_prefix'            => $product_option_value['price_prefix']
                                );
                            }
                        }

                        $option_data[] = array(
                            'product_option_id'    => $product_option['product_option_id'],
                            'product_option_value' => $product_option_value_data,
                            'option_id'            => $product_option['option_id'],
                            'name'                 => $option_info['name'],
                            'type'                 => $option_info['type'],
                            'value'                => $product_option['value'],
                            'required'             => $product_option['required']
                        );
                    }
                }

                $json[] = array(
                    'product_id' => $result['product_id'],
                    'name'       => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
                    'model'      => $result['model'],
                    'option'     => $option_data,
                    'price'      => $result['price']
                );
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function fetchStatus() {

        $this->load->library('cedfruugo');
        $this->load->language('ced_fruugo/product');
        $this->document->setTitle($this->language->get('heading_title'));
        $cedfruugo = Cedfruugo::getInstance($this->registry);
        $this->load->model('ced_fruugo/product');

        $response_data = $cedfruugo->fetchStock(true);

        $report_array = array();
        if (isset($response_data['success']) && isset($response_data['response'])) {
            $response_data = $this->getparsedData($response_data['response'], true);
            if(isset($response_data['skus']['value']['sku']) && count($response_data['skus']['value']['sku'])){
                $report_array = $response_data['skus']['value']['sku'];
            }
        } else {
            $cedfruugo->log(json_encode($response_data),true);
        }

        $data['stock_array'] = json_encode($report_array);

        $data['heading_title'] = $this->language->get('heading_title');

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('text_home'),
            'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
        );

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('heading_title'),
            'href'      => $this->url->link('ced_fruugo/product/fetchStatus', 'token=' . $this->session->data['token'], 'SSL'),
        );
        $data['fetch_status'] = $this->url->link('ced_fruugo/product/fetchStatus', 'token=' . $this->session->data['token'] , 'SSL');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }
        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];

            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->request->post['selected'])) {
            $data['selected'] = (array)$this->request->post['selected'];
        } else {
            $data['selected'] = array();
        }
        $data['cancel'] = $this->url->link('ced_fruugo/product', 'token=' . $this->session->data['token'] , true);
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('ced_fruugo/fetch_status.tpl', $data));
        // $this->response->addHeader('Content-Type: application/json');
        // $this->response->setOutput(json_encode($data));

    }

    public function getparsedData(&$string) {
        $parser = xml_parser_create();
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parse_into_struct($parser, $string, $vals, $index);
        xml_parser_free($parser);
        $mnary=array();
        $ary=&$mnary;

        foreach ($vals as $r) {
            $t=$r['tag'];
            if ($r['type']=='open') {
                if (isset($ary[$t])) {
                    if (isset($ary[$t][0])) $ary[$t][]=array(); else $ary[$t]=array($ary[$t], array());
                    $cv=&$ary[$t][count($ary[$t])-1];
                } else $cv=&$ary[$t];
                if (isset($r['attributes'])) {
                    foreach ($r['attributes'] as $k=>$v) {
                        $cv[$k]=$v;
                    }
                }
                $cv['value']=array();
                $cv['value']['_p']=&$ary;
                $ary=&$cv['value'];
            } elseif ($r['type']=='complete') {
                if (isset($ary[$t])) {
                    if (isset($ary[$t][0])) $ary[$t][]=array(); else $ary[$t]=array($ary[$t], array());
                    $cv=&$ary[$t][count($ary[$t])-1];
                } else $cv=&$ary[$t];
                if (isset($r['attributes'])) {foreach ($r['attributes'] as $k=>$v) $cv[$k]=$v;}
                $cv=(isset($r['value']) ? $r['value'] : '');
            } elseif ($r['type']=='close') {
                $ary=&$ary['_p'];
            }
        }

        $this->_del_p($mnary);
        return $mnary;
    }

    function _del_p(&$ary) {
        foreach ($ary as $k=>$v) {
            if ($k==='_p') unset($ary[$k]);
            elseif (is_array($ary[$k])) $this->_del_p($ary[$k]);
        }
    }

    public function addNewProductsToVariants($product_id)
    {
        $query = $this->db->query("SELECT category_id FROM `". DB_PREFIX."product_to_category` WHERE product_id = '". $product_id ."' ");
        $result = $query->row;
        $categories = $this->getMappedCategoryIds();
        foreach($categories as $key => $value)
        {
            $categories[$key] = array_unique($value);
            if(in_array($result['category_id'], $value)){
                $this->db->query("INSERT INTO `". DB_PREFIX ."cedfruugo_product_variations` (`profile_id` , `product_id`) VALUES ('". $key ."', '". $product_id."') ");
            }
        }
    }

    public function getMappedCategoryIds() {
        $store_category = $this->db->query("SELECT * FROM `".DB_PREFIX."cedfruugo_mapping_details`");
        $categories = array();
        if($store_category->num_rows) {
            foreach ($store_category->rows as $key => $store_cat) {
                if(json_decode($store_cat['category'], true)) {
                    $store_category = json_decode($store_cat['category'], true);
                    $profile_id = $store_cat['id'];
                    $categories[$profile_id] = $store_category;
                }
            }
            $categories = array_filter($categories);
            foreach($categories as $key => $value){
                $categories[$key] = array_unique($value);
            }
        }
        return $categories ;
    }

    public function updateFruugoProduct($product_id)
    {
        $sql = $this->db->query("SELECT `id` FROM `". DB_PREFIX ."cedfruugo_product_variations` WHERE `product_id` = '". (int)$product_id ."' ");
        $productExist = $sql->rows;
        
        $product_ids = array();
        if(isset($productExist) && is_array($productExist)){
            $product_ids = (array)$product_id;

            $cedfruugo = Cedfruugo::getInstance($this->registry);
            $response = $cedfruugo->uploadProducts($product_ids);
        }
    }

    public function clearFeed()
    {
    	$this->db->query("DELETE FROM `". DB_PREFIX ."cedfruugo_final_products`");
        $filename = DIR_IMAGE . 'cedfruugo/product_upload/product_feed.csv';

        if(file_exists($filename)){
            file_put_contents($filename, "");
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode(array('success'=>true, 'message'=> 'Feed file cleared successfully!')));
        } else {
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode(array('success'=>false, 'message'=> 'File Not exist')));
        }

    }

}
?>