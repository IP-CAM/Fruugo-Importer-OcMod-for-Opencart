<?php

class ControllerCedFruugoCategory extends Controller
{
	private $error = array();
	
	public function index() {
	
		$this->load->language('ced_fruugo/category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_fruugo/category');

		$this->getList();
	}

	public function getList(){

		if (isset($this->request->get['filter_id'])) {
			$filter_id = $this->request->get['filter_id'];
		} else {
			$filter_id = null;
		}

		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = null;
		}

		if(isset($this->request->get['sort'])){
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if(isset($this->request->get['order'])){
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if(isset($this->request->get['page'])){
			$page = $this->request->get['page'];
		} else {
			$page = '1';
		}

		$url = '';

		if (isset($this->request->get['filter_id'])) {
			$url .= '&filter_id=' . urlencode(html_entity_decode($this->request->get['filter_id'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if(isset($this->request->get['sort'])){
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if(isset($this->request->get['order'])){
			$url .= '&order=' . $this->request->get['order'];
		}

		if(isset($this->request->get['page'])){
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_ced_fruugo'),
			'href' => $this->url->link('ced_fruugo/category', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_fruugo/category', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);

		$data['cedfruugo_category'] = array();

		$filter_array = array(
			'filter_id'	   => $filter_id,
			'filter_name'  => $filter_name,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$cedfruugo_total_category = $this->model_ced_fruugo_category->getTotalCedfruugoCategory($filter_array);

		$results = $this->model_ced_fruugo_category->getCedfruugoCategory($filter_array);

		foreach($results as $result){
			$data['cedfruugo_category'][]  =  array(
                'category_id'      => $result['category_id'],
                'name'             => $result['name']
                // 'sort_order'       => $result['sort_order']
			);
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
        
        $data['column_category_id'] = $this->language->get('column_category_id');
		$data['column_name'] = $this->language->get('column_name');

		$data['entry_id'] = $this->language->get('entry_id');
		$data['entry_name'] = $this->language->get('entry_name');
		
		$data['button_filter'] = $this->language->get('button_filter');

		$data['token'] = $this->session->data['token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if(isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if(isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_id'])) {
			$url .= '&filter_id=' . urlencode(html_entity_decode($this->request->get['filter_id'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if($order == 'ASC'){
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if(isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_category_id'] = $this->url->link('ced_fruugo/category', 'token=' . $this->session->data['token'] . '&sort=category_id' . $url, 'SSl');
		$data['sort_name'] = $this->url->link('ced_fruugo/category', 'token=' . $this->session->data['token'] . '&sort=cf.name' . $url, 'SSl');

		$url = '';

		if (isset($this->request->get['filter_id'])) {
			$url .= '&filter_id=' . urlencode(html_entity_decode($this->request->get['filter_id'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if(isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if(isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $cedfruugo_total_category;
		$pagination->page  = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url   = $this->url->link('ced_fruugo/category', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSl');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($cedfruugo_total_category) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($cedfruugo_total_category - $this->config->get('config_limit_admin'))) ? $cedfruugo_total_category : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')) , $cedfruugo_total_category, ceil($cedfruugo_total_category / $this->config->get('config_limit_admin')));
        
        $data['filter_id'] = $filter_id;
        $data['filter_name'] = $filter_name;
        
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_fruugo/category.tpl', $data));
	}


	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			$this->load->model('ced_fruugo/category');

			$filter_data = array(
				'filter_name' => $this->request->get['filter_name'],
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_ced_fruugo_category->getCedfruugoCategory($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'category_id'    => $result['category_id'],
					'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					// 'map_categories' => $result['map_categories']
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}

?>