<?php
// Heading
$_['heading_title']          = 'Fruugo Categories';

// Text
$_['text_success']           = 'Success: You have modified Ced Fruugo category!';
$_['text_list']              = 'Fruugo Category List';
$_['text_ced_fruugo']        = 'Ced Fruugo';

// Column
$_['column_name']            = 'Category Name';
$_['column_category_id']     = 'Category ID';
// $_['column_action']          = 'Action';

// Entry
$_['entry_id']               = 'Category ID';
$_['entry_name']             = 'Category Name';

// Error
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify Ced Fruugo categories!';
$_['error_name']             = 'Category Name must be between 2 and 32 characters!';

//Filter Button
$_['button_filter']          = 'Filter';
