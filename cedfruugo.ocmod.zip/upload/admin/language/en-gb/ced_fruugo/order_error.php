<?php
// Heading
$_['heading_title']              = 'Fruugo Failed Order';
$_['button_history_add']         = 'Create Shipment';
// Text
$_['text_success']               = 'Success: You have modified orders!';
$_['text_no_results']            = 'No result found !';
$_['text_ced_fruugo']            = 'Ced Fruugo';

// Failed Order
$_['text_error_list']            = 'Failed Order List';

// Column
$_['column_merchant_sku']        = 'SKU ID';
$_['column_ced_fruugo_order_id'] = 'Fruugo Order ID';
$_['column_reason']              = 'Reason';
$_['column_action']              = 'Action';

// Error
$_['error_warning']              = 'Warning: Please check the form carefully for errors!';
$_['error_permission']           = 'Warning: You do not have permission to modify orders!';
$_['error_action']               = 'Warning: Could not complete this action!';

?>