<?php
// Heading
$_['heading_title']              = 'Fruugo Orders';

// Text
$_['text_success']               = 'Success: You have modified orders!';
$_['text_ced_fruugo']            = 'Ced Fruugo';
$_['text_list']                  = 'Order List';
$_['text_order_detail']          = 'Order Details';
$_['text_no_results']            = 'No result found !';
$_['text_shipping_info']         = 'Shipping Info';
$_['text_products_info']         = 'Products Info';
$_['text_ship_whole_order']      = 'Ship Whole Order';
$_['text_missing']               = 'Missing';

// Column
$_['column_order_id']            = 'Order ID';
$_['column_customer']            = 'Customer';
$_['column_status']              = 'Status';
$_['column_total']               = 'Total';
$_['column_fruugo_order_id']     = 'Fruugo Order ID';
$_['column_fruugo_status']       = 'Fruugo Status';
$_['column_date_added']          = 'Date Added';
$_['column_action']              = 'Action';


$_['column_skuId']               = 'SKU ID';
$_['column_skuName']             = 'SKU Name';
$_['column_itemPriceInclVat']    = 'Item Price Incl VAT';
$_['column_totalNumberOfItems']  = 'Total No. Of Items';
$_['column_pendingItems']        = 'Pending Items';
$_['column_confirmedItems']      = 'Confirmed Items';
$_['column_shippedItems']        = 'Shipped Items';
$_['column_cancelledItems']      = 'Cancelled Items';
$_['column_itemsWithException']  = 'Items With Exception';

$_['column_trackingUrl']         = 'Tracking URL';
$_['column_trackingCode']        = 'Tracking Code';
$_['column_messageToCustomer']   = 'Message to Customer';
$_['column_messageToFruugo']     = 'Message to Fruugo';

// Entry
$_['entry_customer']             = 'Customer';
$_['entry_order_status']         = 'Status';
$_['entry_order_id']             = 'Order ID';
$_['entry_total']                = 'Total';
$_['entry_date_added']           = 'Date Added';
$_['entry_fruugo_order_status']  = 'Fruugo Status';

$_['entry_customer_id']          = 'Customer ID';
$_['entry_orderId']              = 'Order ID';
$_['entry_order_date']           = 'Order Date';
$_['entry_fruugo_status']        = 'Fruugo Status';
$_['entry_language_code']        = 'Language Code';
$_['entry_shipping_method']      = 'Shipping Method';
$_['entry_shippingCostInclVAT']  = 'Shipping Cost Incl VAT';
$_['entry_shippingCostVAT']      = 'Shipping Cost VAT';

$_['entry_shipping_firstname']   = 'Shipping Firstname';
$_['entry_shipping_lastname']    = 'Shipping Lastname';
$_['entry_shipping_address_1']   = 'Shipping Address';
$_['entry_shipping_city']        = 'Shipping City';
$_['entry_shipping_postcode']    = 'Shipping Postal Code';
$_['entry_shipping_iso_code_3']  = 'Shipping ISO Code';
$_['entry_telephone']            = 'Shipping Telephone No.';

// Error
$_['error_warning']              = 'Warning: Please check the form carefully for errors!';
$_['error_permission']           = 'Warning: You do not have permission to modify orders!';
$_['error_action']               = 'Warning: Could not complete this action!';
$_['error_filetype']			 = 'Invalid file type!';