<?php
// Heading
$_['heading_title']                    = 'Profile';

// Text
$_['text_success']                     = 'Success: You have modified ced fruugo profile!';
$_['text_ced_fruugo']                  = 'Ced Fruugo';
$_['text_list']                        = 'Profile List';
$_['text_add']                         = 'Add Profile';
$_['text_edit']                        = 'Edit Profile';
$_['text_default']                     = 'Default';
$_['text_option']                      = 'Options';
$_['text_attribute_variants']          = 'Attributes (variants)';
$_['text_system_default']              = 'System (Default)';

// Column
$_['column_name']                      = 'Category Name';
$_['column_mapped_categories']         = 'Mapped Category';
$_['column_action']                    = 'Action';

// Entry
$_['entry_category']                   = 'Fruugo Category';
$_['entry_stock_category']             = 'Stock Category';
$_['entry_manufacturer']               = 'Manufacturer';
$_['entry_store']                      = 'Store';
$_['entry_language']                   = 'Store Language';


// Help
$_['help_filter']                      = '(Autocomplete)';
$_['help_keyword']                     = 'Do not use spaces, instead replace spaces with - and make sure the keyword is globally unique.';
$_['help_top']                         = 'Display in the top menu bar. Only works for the top parent categories.';
$_['help_column']                      = 'Number of columns to use for the bottom 3 categories. Only works for the top parent categories.';
$_['help_category']                    = '(Autocomplete)';
$_['help_manufacturer']                = '(Autocomplete)';

// Error
$_['error_warning']                    = 'Warning: Please check the form carefully for errors!';
$_['error_permission']                 = 'Warning: You do not have permission to modify categories!';
$_['error_name']                       = 'Fruugo Category Name must be between 2 and 32 characters!';
$_['error_code']                       = 'Store Category Name must be between 2 and 32 characters!';

//
$_['tab_map_category']                 = 'Profile Info';
$_['tab_attribute']                    = 'Attribute';
$_['tab_default']                      = 'Default';
$_['tab_variant_attribute']            = 'Variant Attribute';