<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

// Heading
$_['heading_title']       = 'Fruugo Setting';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified CED Fruugo module!';
$_['text_edit']           = 'Edit Fruugo Setting';

// Entry
// $_['entry_code']          = 'CED Fruugo Code';
$_['entry_status']        = 'Status';

//Tabs
$_['tab_general']                    = 'General';
$_['tab_fruugo_product']              = 'Product Setting';
$_['tab_fruugo_order']                = 'Order Setting';
$_['tab_fruugo_cron']                 = 'Cron Setting';

// Help
$_['help_code']           = 'Goto <a href="https://developers.google.com/+/hangouts/button" target="_blank">Create a Google Hangout chatback badge</a> and copy &amp; paste the generated code into the text box.';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify CED Fruugo module!';
$_['error_code']          = 'Username Required';
$_['error_pass']          = 'Password Required';


//API URL
$_['api_url']             = 'API Url';
$_['ced_fruugo_api_url']  = 'https://www.fruugo.com/';

//Feed URL
$_['feed_url']            = 'Feed Url';
$_['ced_fruugo_feed_url'] = HTTPS_CATALOG . 'image/cedfruugo/product_upload/product_feed.csv';

//CRON SECURE KEY
$_['cron_secure_key']     = 'Cron Url';
// $_['ced_fruugo_cron_secure_key'] = 'http://yourdomain.com/modules/cedfruugo/cronfilename.php?secure_key=your';
$_['ced_fruugo_cron_secure_key_order']   = 'wget -q -O /dev/null'. HTTPS_CATALOG . 'index.php?route=ced_fruugo/order/fetchOrder' .'> /dev/null 2>&1';
$_['ced_fruugo_cron_secure_key_order_time'] = '30 min';
$_['ced_fruugo_cron_secure_key_product'] = 'wget -q -O /dev/null'. HTTPS_CATALOG . 'index.php?route=ced_fruugo/product/fetchStatus' .'> /dev/null 2>&1';
$_['ced_fruugo_cron_secure_key_product_time'] = 'Once a day';
$_['ced_fruugo_cron_secure_key_product_add'] = 'wget -q -O /dev/null'. HTTPS_CATALOG . 'index.php?route=ced_fruugo/product/addNewProduct' .'> /dev/null 2>&1';
$_['ced_fruugo_cron_secure_key_product_add_time'] = 'Twice a day';
$_['ced_fruugo_cron_secure_key_feed_update'] = 'wget -q -O /dev/null'. HTTPS_CATALOG . 'index.php?route=ced_fruugo/product/uploadAllProducts' .'> /dev/null 2>&1';
$_['ced_fruugo_cron_secure_key_feed_update_time'] = 'Once in 2 days';

//Username & Password
$_['username']  = 'Username';
$_['password']  = 'Password';

//Customer detail
$_['customer_email']  = 'Customer Order Email Id';
$_['customer_id']     = 'Customer Id';
$_['customer_group_id'] = 'Customer Group Used In Discount';
$_['is_manufacturer'] = 'Is Manufacturer';

//Order
$_['order_status']            = 'Order Status';
$_['order_status_importing']  = 'Order status while importing order';
$_['order_accepted']          = 'Order Accepted';
$_['order_after_accepted']    = 'Order status after accepted order';
$_['order_rejected']          = 'Order Rejected';
$_['order_after_rejected']    = 'Order status after rejected order';
$_['order_shipped']           = 'Order Shipped';
$_['order_after_shipped']     = 'Order status after shipped order';
$_['order_carrier']           = 'Order Carrier';
$_['order_carrier_importing'] = 'Order carrier while importing order';
$_['order_payment']           = 'Payment Method';
$_['order_payment_importing'] = 'Order payment while importing order';

//Language
$_['store_language']          = 'Store Language';

//Price
$_['price_variant_type']   = 'Price variant Type';
$_['price_variant_amount'] = 'Price Variant Amount';
$_['price_type']           = 'Price Type';

// Map category
$_['disabled_product_upload'] = 'Disabled Product Upload';

// Map category
$_['map_category']            = 'Map Category';

// Auto accept/ reject
$_['auto_accept_reject']      = 'Auto order accept/reject';
$_['auto_sync_inventory']     = 'Auto Sync Inventory and Price By Cron';
$_['update_price']            = 'Update Price on Product Edit';
$_['update_inventory']        = 'Update Inventory on Product Edit';
$_['update_product_data']     = 'Update Product Data on Product Edit';
$_['debug']                   = 'Debug';

//Help
$_['help_category']           = '(Autocomplete)';

$_['entry_country']           = 'Fruugo Country';
$_['entry_language']          = 'Fruugo Language';
$_['entry_currency']          = 'Fruugo Currency';