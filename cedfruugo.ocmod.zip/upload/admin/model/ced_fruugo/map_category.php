<?php 

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

class ModelCedFruugoMapCategory extends Model {
	
	public function getCategories() {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedfruugo_category ORDER BY name");

		return $query->rows;
	}

	public function getSystemDefault() {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedfruugo_system_default");

		return $query->rows;
	}

	public function getMappingDetails($data = array()) {

		$sql = "SELECT * FROM " . DB_PREFIX . "cedfruugo_mapping_details";

        $sort_data = array(
            'FruugoCategory'
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY FruugoCategory";
        }

        if (isset($data['order']) && ($data['order'] == 'DESC')) {
            $sql .= " DESC";
        } else {
            $sql .= " ASC";
        }

        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }

            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }

        $query = $this->db->query($sql);

		$result = $query->rows;
		
		return $result;
	}

	public function getTotalMappingDetails($data = array()) {
        $sql = "SELECT COUNT(*) AS total FROM " . DB_PREFIX . "cedfruugo_mapping_details";

        $sort_data = array(
            'FruugoCategory'
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY FruugoCategory";
        }

        if (isset($data['order']) && ($data['order'] == 'DESC')) {
            $sql .= " DESC";
        } else {
            $sql .= " ASC";
        }

        $query = $this->db->query($sql);

		return $query->row['total'];
	}

	public function getStoreCategory($store_id) {
		$query = $this->db->query("SELECT name FROM " . DB_PREFIX . "category_description WHERE `category_id` = '" . $store_id . "' ");
		$result = $query->row['name'];

		return $result;
	}

	public function getCountry() {
		$query = $this->db->query("SELECT id, country FROM " . DB_PREFIX . "cedfruugo_country_currency GROUP BY country ORDER BY country");
        // echo $query; die();
		return $query->rows;
	}

	public function getCurrency() {
		$query = $this->db->query("SELECT id, currency_code FROM " . DB_PREFIX . "cedfruugo_country_currency GROUP BY currency_code ORDER BY currency_code");

		return $query->rows;
	}

	public function getFruugoLanguage() {
		$query = $this->db->query("SELECT id, language FROM " . DB_PREFIX . "cedfruugo_country_currency GROUP BY language ORDER BY language");
		
		return $query->rows;
	}

	public function getExtensions($type) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension WHERE `type` = '" . $this->db->escape($type) . "'");

		return $query->rows;
	}

	public function addCategoryMapping($data) 
	{
        $this->event->trigger('pre.admin.cedfruugo_map_category.add', $data);

        if(!isset($data['manufacturer_id']))
            $data['manufacturer_id'] = '0';

        if(isset($data['manufacturer_id']) && !empty($data['manufacturer_id']))
            $manufacturer = implode(',', $data['manufacturer_id']);
        else
            $manufacturer = '0';

        $this->db->query("INSERT INTO `" . DB_PREFIX . "cedfruugo_mapping_details` (`FruugoCategory`, `category`, `manufacturer`, `product_store`, `storeLanguage`, `attribute`, `variant_attribute`, `default_attribute`) VALUES ('" . $this->db->escape($data['FruugoCategory']) . "', '" . $this->db->escape(json_encode(array_unique($data['product_category']))) . "', '" . $this->db->escape(json_encode($data['manufacturer_id'])) . "', '" . $this->db->escape(json_encode(array_unique($data['product_store']))) . "', '" . $this->db->escape($data['storeLanguage']) . "', '" . $this->db->escape(json_encode($data['attribute'])) . "', '" . $this->db->escape(json_encode($data['variant_attribute'])) . "', '" . $this->db->escape(json_encode($data['default_attribute'])) . "')");

        $profile_id = $this->db->getLastId();


        if(isset($data['storeLanguage']) && !empty($data['storeLanguage'])) {
            $categories = array_unique($data['product_category']);

            foreach ($categories as $key => $value) {

                $product_by_cat_query = $this->db->query("SELECT DISTINCT pd.product_id, pc.category_id FROM `" . DB_PREFIX . "product` AS p JOIN `". DB_PREFIX ."product_to_category` AS pc ON (pc.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) WHERE p.manufacturer_id IN (" . $manufacturer . ") AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND pc.category_id = '" . $value . "' ");
                $product_result = $product_by_cat_query->rows;

                foreach($product_result as $product_id) {

                    $query = $this->db->query("SELECT product_id FROM `" . DB_PREFIX . "cedfruugo_product_variations` WHERE product_id = '" . $product_id['product_id'] . "' ");

                    if ($query->num_rows < '1') {
                        $this->db->query("INSERT INTO `" . DB_PREFIX . "cedfruugo_product_variations` (`profile_id`, `product_id`) VALUES ('" . $profile_id . "', '" . $product_id['product_id'] . "') ");
                    }
                }
            }
        }
    }

    public function editCategoryMapping($profile_id, $data)
    {
        $this->event->trigger('pre.admin.cedfruugo_map_category.edit', $data);

        if(!isset($data['manufacturer_id']))
            $data['manufacturer_id'] = '0';

        if(isset($data['manufacturer_id']) && !empty($data['manufacturer_id']))
            $manufacturer = implode(',', $data['manufacturer_id']);
        else
            $manufacturer = '0';

        $this->db->query("UPDATE `" . DB_PREFIX . "cedfruugo_mapping_details` SET `FruugoCategory` = '" . $this->db->escape($data['FruugoCategory']) . "' , `category` = '" . $this->db->escape(json_encode(array_unique($data['product_category']))) . "' , `manufacturer` = '" . $this->db->escape(json_encode($data['manufacturer_id'])) . "', `product_store` = '" . $this->db->escape(json_encode(array_unique($data['product_store']))) . "', `storeLanguage` = '" . $this->db->escape($data['storeLanguage']) . "', `attribute` = '" . $this->db->escape(json_encode($data['attribute'])) . "' , `variant_attribute` = '" . $this->db->escape(json_encode($data['variant_attribute'])) . "' , `default_attribute` = '" . $this->db->escape(json_encode($data['default_attribute'])) . "' WHERE `id` = '" . (int)$profile_id . "' ");

        $this->db->query("DELETE FROM `" . DB_PREFIX . "cedfruugo_product_variations` WHERE `profile_id` = '" . $profile_id . "' ");

        if(isset($data['storeLanguage']) && !empty($data['storeLanguage'])) {
            $categories = array_unique($data['product_category']);

            foreach ($categories as $key => $value) {

                $product_by_cat_query = $this->db->query("SELECT DISTINCT pd.product_id, pc.category_id FROM `" . DB_PREFIX . "product` AS p JOIN `". DB_PREFIX ."product_to_category` AS pc ON (pc.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) WHERE p.manufacturer_id IN (" . $manufacturer . ") AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND pc.category_id = '" . $value . "' ");
                $product_result = $product_by_cat_query->rows;

                foreach($product_result as $product_id) {

                    $query = $this->db->query("SELECT product_id FROM `" . DB_PREFIX . "cedfruugo_product_variations` WHERE product_id = '" . $product_id['product_id'] . "' ");

                    if ($query->num_rows < '1') {
                        $this->db->query("INSERT INTO `" . DB_PREFIX . "cedfruugo_product_variations` (`profile_id`, `product_id`) VALUES ('" . $profile_id . "', '" . $product_id['product_id'] . "') ");
                    }
                }
            }
        }

        $this->event->trigger('post.admin.cedfruugo_map_category.edit', $profile_id);

    }

	// public function addCategoryMapping($data) {
	// 	// echo '<pre>'; print_r($data);
		
	// 	$this->event->trigger('pre.admin.cedfruugo_map_category.add', $data);

	// 	if(isset($data['manufacturer_id']) && !empty($data['manufacturer_id']))
	// 	 	$manufacturer = $data['manufacturer_id'];
 //         else 
 //            $manufacturer = '0';

	// 	$this->db->query("INSERT INTO `" . DB_PREFIX . "cedfruugo_mapping_details` (`FruugoCategory`, `category`, `manufacturer`, `product_store`, `storeLanguage`, `attribute`, `variant_attribute`, `default_attribute`) VALUES ('" . $this->db->escape($data['FruugoCategory']) . "', '" . $this->db->escape(json_encode($data['product_category'])) . "', '" . $this->db->escape(json_encode($manufacturer)) . "', '" . $this->db->escape(json_encode($data['product_store'])) . "', '" . $this->db->escape($data['storeLanguage']) . "', '" . $this->db->escape(json_encode($data['attribute'])) . "', '" . $this->db->escape(json_encode($data['variant_attribute'])) . "', '" . $this->db->escape(json_encode($data['default_attribute'])) . "')");

	// 	$profile_id = $this->db->getLastId();

	// 	if(isset($data['storeLanguage']) && !empty($data['storeLanguage'])){
	// 		$getProductID = $this->db->query("SELECT DISTINCT pd.product_id FROM `" . DB_PREFIX . "product_description` AS pd JOIN `" . DB_PREFIX . "product` AS p ON (pd.product_id = p.product_id) JOIN `" . DB_PREFIX . "product_to_category` AS pc ON (pc.product_id = p.product_id) WHERE p.manufacturer_id IN ('" . implode(',', $manufacturer) . "') AND pc.category_id IN ('" . implode(',', $data['product_category']) . "') AND pd.language_id = '".$data['storeLanguage']."' ");
	// 		$product_result = $getProductID->rows;
	// 	}

	// 	foreach($product_result as $product_id){
	// 		$query = $this->db->query("SELECT product_id FROM `" . DB_PREFIX . "cedfruugo_product_variations` WHERE product_id = '". $product_id['product_id'] ."' ");

	// 		if($query->num_rows < '1'){
	// 			$this->db->query("INSERT INTO `" . DB_PREFIX . "cedfruugo_product_variations` (`profile_id`, `product_id`) VALUES ('" .$profile_id . "', '" . $product_id['product_id'] . "') ");
	// 		}
			
	// 	}

	// 	$this->event->trigger('post.admin.cedfruugo_map_category.add', $category_id);

	// 	// return $category_id;
	// }

	// public function editCategoryMapping($profile_id, $data){
	// 	$this->event->trigger('pre.admin.cedfruugo_map_category.edit', $data);

	// 	 if(isset($data['manufacturer_id']) && !empty($data['manufacturer_id']))
	// 	 	$manufacturer = $data['manufacturer_id'];
 //         else 
 //            $manufacturer = '0';

	// 	$this->db->query("UPDATE `" . DB_PREFIX . "cedfruugo_mapping_details` SET `FruugoCategory` = '" . $this->db->escape($data['FruugoCategory']) . "' , `category` = '" . $this->db->escape(json_encode($data['product_category'])) . "' , `manufacturer` = '" . $this->db->escape(json_encode($manufacturer)) . "', `product_store` = '" . $this->db->escape(json_encode($data['product_store'])) . "', `storeLanguage` = '" . $this->db->escape($data['storeLanguage']) . "', `attribute` = '" . $this->db->escape(json_encode($data['attribute'])) . "' , `variant_attribute` = '" . $this->db->escape(json_encode($data['variant_attribute'])) . "' , `default_attribute` = '" . $this->db->escape(json_encode($data['default_attribute'])) . "' WHERE `id` = '" . (int)$profile_id . "' ");

	// 	// $profile_id = $this->db->getLastId();

	// 	$this->db->query("DELETE FROM `" . DB_PREFIX . "cedfruugo_product_variations` WHERE `profile_id` = '" . $profile_id . "' ");

	// 	if(isset($data['storeLanguage']) && !empty($data['storeLanguage'])){
	// 		$getProductID = $this->db->query("SELECT DISTINCT pd.product_id FROM `" . DB_PREFIX . "product_description` AS pd JOIN `" . DB_PREFIX . "product` AS p ON (pd.product_id = p.product_id) JOIN `" . DB_PREFIX . "product_to_category` AS pc ON (pc.product_id = p.product_id) WHERE p.manufacturer_id IN ('" . implode(',', $manufacturer) . "') AND pc.category_id IN ('" . implode(',', $data['product_category']) . "') AND pd.language_id = '".$data['storeLanguage']."' ");
	// 		$product_result = $getProductID->rows;
	// 	}

	// 		foreach($product_result as $product_id){
				
	// 			$query = $this->db->query("SELECT product_id FROM `" . DB_PREFIX . "cedfruugo_product_variations` WHERE product_id = '". $product_id['product_id'] ."' ");

	// 			if($query->num_rows < '1'){
	// 				$this->db->query("INSERT INTO `" . DB_PREFIX . "cedfruugo_product_variations` (`profile_id`, `product_id`) VALUES ('" .$profile_id . "', '" . $product_id['product_id'] . "') ");
	// 			}
	// 	    } 

	// 	$this->event->trigger('post.admin.cedfruugo_map_category.edit', $category_id);

	// }

	public function deleteCategoryMapping($profile_id){
		$this->event->trigger('pre.admin.cedfruugo_map_category.delete' , $profile_id);

		$this->db->query("DELETE FROM " . DB_PREFIX . "cedfruugo_mapping_details WHERE id = '" . (int)$profile_id . "'");

        $query = $this->db->query("SELECT product_id FROM " . DB_PREFIX . "cedfruugo_product_variations WHERE profile_id = '" . (int)$profile_id . "' ");
        $result = $query->rows;
        
        if($result){
        	foreach($result as $product_array){
        		$this->db->query("DELETE FROM " . DB_PREFIX . "cedfruugo_final_products WHERE ProductId = '" . (int)$product_array['product_id'] . "'");
        	}

        }

        $this->db->query("DELETE FROM " . DB_PREFIX . "cedfruugo_product_variations WHERE profile_id = '" . (int)$profile_id . "'");

        $this->db->query("DELETE FROM " . DB_PREFIX . "cedfruugo_product_attribute_combination WHERE profile_id = '" . (int)$profile_id . "'");


		$this->event->trigger('post.admin.cedfruugo_map_category.delete' , $profile_id);
	}

	public function getMappingDetailsByID($category_id) {

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedfruugo_mapping_details WHERE `id` = '" . (int)$category_id . "'");
		$result = $query->row;
		return $result;
	}
}


?>