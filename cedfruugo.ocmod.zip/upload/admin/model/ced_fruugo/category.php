<?php

class ModelCedFruugoCategory extends Model {

	public function getCedfruugoCategory($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "cedfruugo_category WHERE category_id > '0'";

		if (!empty($data['filter_id'])) {
			$sql .= " AND category_id = '" . (int)$data['filter_id'] . "'";
		}

		if (!empty($data['filter_name'])) {
			$sql .= " AND name LIKE '%" . html_entity_decode($data['filter_name']) . "%'";
		}

		$sql .= " GROUP BY category_id";

		$sort_data = array(
			'name',
			'category_id'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY category_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}
        
		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getTotalCedfruugoCategory($data = array()) {
		
		$sql = " SELECT COUNT(DISTINCT category_id) AS total FROM " . DB_PREFIX . "cedfruugo_category WHERE category_id > '0' ";

		if (!empty($data['filter_id'])) {
			$sql .= " AND category_id = '" . (int)$data['filter_id'] . "'";
		}

		if (!empty($data['filter_name'])) {
			$sql .= " AND name LIKE '%" . html_entity_decode($data['filter_name']) . "%'";
		}

        $query = $this->db->query($sql);
        
		return $query->row['total'];
	}
	
}