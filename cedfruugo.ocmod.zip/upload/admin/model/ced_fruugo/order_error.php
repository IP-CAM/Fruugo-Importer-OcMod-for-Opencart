<?php
class ModelCedFruugoOrderError extends Model {
	
	public function deleteErrorOrder($order_id) {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "cedfruugo_order_error` WHERE ced_fruugo_order_id = '" . (int)$order_id . "'");
	}	

	public function getErrorOrders()
	{
		$sql="SELECT * FROM `".DB_PREFIX."cedfruugo_order_error`";
		$query=$this->db->query($sql);

		return $query->rows;
	}

	public function getErrorOrdersTotals()
	{
		$sql="SELECT * FROM `".DB_PREFIX."cedfruugo_order_error`";
		$query=$this->db->query($sql);

		return $query->num_rows;
	}
	
	public function getRejectedOrderJson($id)
	{
		$sql="SELECT `order_data` FROM `".DB_PREFIX."cedfruugo_order_error` WHERE `id`='".$id."'";
		$query=$this->db->query($sql);
		if($query->num_rows)
		return $query->row['order_data'];
		return array();
	}
}