<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

class Cedfruugo {
    private $logger;
    private $api_url = 'https://openapi.fruugo.com/';
    private $api_version = 'v2';
    private static $instance;

    /**
     * @param  object  $registry  Registry Object
     */
    public static function getInstance($registry) {
        if (is_null(static::$instance)) {
            static::$instance = new static($registry);
        }

        return static::$instance;
    }

    /**
     * @param  object  $registry  Registry Object
     *
     *   $registry->get('log');
     *   $registry->get('db');
     *   $registry->get('config');
     */
    public function __construct($registry) {
        $this->logger   = $registry->get('log');
        $this->db       = $registry->get('db');
        $this->config   = $registry->get('config');
        $this->currency = $registry->get('currency');
        $this->tax      = new Tax($registry);
    }

    public function isEnabled(){

        $flag=false;

        if ($this->config->get('ced_fruugo_status')) {

            $flag=true;

            $this->_init();
        }
        return $flag;
    }

    public function _init(){

        $this->_api_url = $this->config->get('ced_fruugo_api_url');
        $this->user =  $this->config->get('ced_fruugo_username');
        $this->pass =  $this->config->get('ced_fruugo_password');
        $this->log("pass: ".$this->pass);
        $this->log("user: ".$this->user);
        $this->log("url: ".$this->_api_url);
    }

    public function deleteProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllFruugoProducts();
        }
        if(count($product_ids)) {
            foreach ($product_ids as $key => $product_id) {
                $response = array();
                try {
                    $product_data = $this->prepareFruugoProduct($product_id);

                    if($response && isset($response['count']) && ($response['count']==0)) {
                        $this->db->query("DELETE FROM `".DB_PREFIX."ced_fruugo_product` where `product_id` = '".$product_id."'");
                        return array('success' => true, 'message' => 'Product Deleted On Fruugo ');
                    } else {
                        return array('success' => false, 'message' => 'Failed To Delete Product On Fruugo');
                    }
                } catch (Exception $e) {
                    $this->log('Exception deleteProducts');
                    $this->log($e->getMessage());
                    return array('success' => false, 'message' => 'No Response From Fruugo');
                }
            }
        }
    }

    public function enableProducts($product_ids = array())
    {
        // if (is_numeric($product_ids)) {
        //     $product_ids = array($product_ids);
        // }
        // if(count($product_ids)==0){
        //     $product_ids = $this->getAllFruugoProducts();
        // }
        if(count($product_ids)) {
            //foreach ($product_ids as $key => $product_id) {
            try {
                $response = $this->EnableDisableStock($product_ids, 'enable');

                if($response && isset($response['success']) && ($response['success']==1)) {
                    // $this->db->query("UPDATE `". DB_PREFIX ."cedfruugo_product_variations` SET fruugo_status = 'INSTOCK' WHERE product_id = '". $product_id ."' ");
                    return array('success' => true, 'message' => 'Product Enabled On Fruugo ');
                } else {
                    return array('success' => false, 'message' => 'Failed To Enable Product On Fruugo');
                }
            } catch (Exception $e) {
                $this->log('Exception enableProducts');
                $this->log($e->getMessage());
                return array('success' => false, 'message' => 'No Response From Fruugo');
            }
            //}
        }
    }
    public function disableProducts($product_ids = array())
    {
        // if (is_numeric($product_ids)) {
        //     $product_ids = array($product_ids);
        // }
        // if(count($product_ids)==0){
        //     $product_ids = $this->getAllFruugoProducts();
        // }
        if(count($product_ids)) {
            //foreach ($product_ids as $key => $product_id) {
            //$product_id = (int)$product_id;
            try {
                $response = $this->EnableDisableStock($product_ids, 'disable');

                if($response && isset($response['success']) && ($response['success']==1)) {
                    // $this->db->query("UPDATE `". DB_PREFIX ."cedfruugo_product_variations` SET fruugo_status = 'OUTOFSTOCK' WHERE product_id = '". $product_id ."' ");
                    return array('success' => true, 'message' => 'Product Disabled On Fruugo ');
                } else {
                    return array('success' => false, 'message' => 'Failed To Disable Product On Fruugo');
                }
            } catch (Exception $e) {
                $this->log('Exception disableProducts');
                $this->log($e->getMessage());
                return array('success' => false, 'message' => 'No Response From Fruugo');
            }
            //}
        }
    }

    public function uploadProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0)
        {
            $product_ids = $this->getAllFruugoProducts();
        }
        if(!empty($product_ids)) {
            $data = array();
            foreach($product_ids as $key => $product_id) {
                $product_id = (int)$product_id;
                try {
                    $product_data_array = $this->prepareFruugoProduct($product_id);

                    if (!isset($product_data_array['0']))
                    {
                        $temp_product_array = $product_data_array;
                        $product_data_array = array();
                        $product_data_array['0'] = $temp_product_array;
                    }
                    foreach ($product_data_array as $product_data)
                    {
                        $validate_data = $this->validateProduct($product_data);

                        if( !empty($product_data['error_message']) && !empty($validate_data['error']) )
                        {
                            $validate_data['error'] .= '<br/>' . $product_data['error_message'];
                            $this->updateProductVariations($product_id, $validate_data, $product_data['SkuId']);
                        } else if(!empty($product_data['error_message']) && empty($validate_data['error']))
                        {
                            $validate_data['error'] = $product_data['error_message'];
                            $this->updateProductVariations($product_id, $validate_data, '');
                        } else if(empty($product_data['error_message']) && !empty($validate_data['error']) )
                        {
                            $this->updateProductVariations($product_id, $validate_data, $product_data['SkuId']);
                        } else {
                            $this->updateProductVariations($product_id, json_encode(array('error'=>'')), $product_data['SkuId']);
                            $this->insertFinalProducts($product_data);
                        }
                    }

                    if(empty($product_data['error_message']) && empty($validate_data['error'])){
                        $csv_file = $this->prepareCsvFile();
                        $data = array('success' => true, 'message' => $csv_file);
                    } else {
                        $data = array('success' => false, 'message' => $validate_data);
                    }

                    //$arr_diff = array_diff($product_ids, $product_ids_array);
                    // $data = array('success' => true, 'message' => count($product_ids) . ',' . $error . ',' . $success, 'array_differ' => $arr_diff);
                } catch (Exception $e) {
                    $this->log('Exception uploadProducts');
                    $this->log($e->getMessage());
                    $data = array('success' => false, 'message' => $e->getMessage());
                }
            }
            return $data;
        }
    }

    public function prepareCsvFile()
    {
        $query = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedfruugo_final_products` ");
        $final_product = $query->rows;

        $headers = array();
        $csv_dir = DIR_IMAGE . 'cedfruugo/product_upload/';

        if (!is_dir($csv_dir)) {
            mkdir($csv_dir, '0777', true);
        }
        try {
            $file = fopen($csv_dir . 'product_feed.csv', 'w');
            $final_product = array_chunk($final_product,1000);

            if(count($final_product) > '0')
            {
                foreach ($final_product as $key => $product_chunk)
                {
                    foreach($product_chunk as $index => $row_data)
                    {
                        $row = $this->removeNullValuesFromFinalProducts($row_data);
                        ksort($row);

                        if (count($headers) == 0) {
                            $headers = array_keys($row);
                            if(!empty($row)) {
                                fputcsv($file, $headers);
                                fputcsv($file, $row);
                            }
                        } else {
                            if(!empty($row)){
                                fputcsv($file, $row);
                            }
                        }
                    }
                }
            }
            fclose($file);
        } catch (Exception $e) {
            return $e->getMessage();
        }

        return 'Csv Generated Successfully.';
    }

    public function removeNullValuesFromFinalProducts($data = array())
    {
        if (count($data)) {
            foreach ($data as $key => $value) {
                if (($key == 'StockStatus' && $value != 'INSTOCK') || ($key == 'StockQuantity' && !(int)$value)) {
                    $data['LeadTime'] = '';
                }
                if($key=='StockQuantity')
                    continue;

                if (!$value || ((string)$value == '0000-00-00') || $value == '0' || $value == '0.00') {
                    $data[$key] = '';
                }

                if($key == 'Category' || $key == 'Description' || $key == 'Title' || $key == 'Brand'){
                    $data['Category'] = htmlspecialchars_decode($data['Category']);
                    $data['Description'] = htmlspecialchars_decode($data['Description']);
                    $data['Title'] = htmlspecialchars_decode($data['Title']);
                    $data['Brand'] = htmlspecialchars_decode($data['Brand']);
                }
                if($key == 'LeadTime' && $value == '1')
                    $data['LeadTime'] = '';
                if(in_array($key,array('id')))
                    unset($data[$key]);
            }
        }
        return $data;
    }

    public function updateProductVariations($product_id, $validate_data, $SkuId)
    {
        $updated_on = date("Y-m-d h:i:s");
        $this->db->query(" UPDATE `" . DB_PREFIX . "cedfruugo_product_variations` SET `error_message` = '" . htmlspecialchars_decode(json_encode($validate_data)) . "' , `sku` = '" .$SkuId. "', updated_on = '". $updated_on ."'  WHERE `product_id` = '" .$product_id. "' ");
        return $product_id;
    }

    public function insertFinalProducts($product_data = array())
    {
        $sql = $this->db->query("SELECT `id` FROM `" . DB_PREFIX . "cedfruugo_final_products` WHERE `ProductId` = '".$this->db->escape($product_data['ProductId'])."' AND `SkuId` = '".$this->db->escape($product_data['SkuId'])."' ");
        if($sql->num_rows){
            $this->db->query("UPDATE `" . DB_PREFIX . "cedfruugo_final_products` SET `ProductId` = '".$this->db->escape($product_data['ProductId'])."', `SkuId` = '".$this->db->escape($product_data['SkuId'])."', `EAN` = '".(int)$product_data['EAN']."', `Brand` = '".ucwords(strtolower($product_data['Brand']))."', `Category` = '".strip_tags($product_data['Category'])."', `Imageurl1` = '".$this->db->escape($product_data['Imageurl1'])."', `StockStatus` = '".$this->db->escape($product_data['StockStatus'])."', `StockQuantity` = '".(int)$product_data['StockQuantity']."', `Title` = '". $this->db->escape(ucwords(strtolower($product_data['Title']))) ."', `Description` = '". $this->db->escape(ucwords(strtolower($product_data['Description'])))."', `NormalPriceWithoutVAT` = '".(float)$product_data['NormalPriceWithoutVAT']."', `NormalPriceWithVAT` = '".(float)$product_data['NormalPriceWithVAT']."', `VATRate` = '".(float)$product_data['VATRate']."', `Imageurl2` = '".$this->db->escape($product_data['Imageurl2'])."', `Imageurl3` = '".$this->db->escape($product_data['Imageurl3'])."', `Imageurl4` = '".$this->db->escape($product_data['Imageurl4'])."', `Imageurl5` = '".$this->db->escape($product_data['Imageurl5'])."', `AttributeSize` = '".$this->db->escape($product_data['AttributeSize'])."', `AttributeColor` = '".$this->db->escape($product_data['AttributeColor'])."', `DiscountPriceWithoutVAT` = '".(float)$product_data['DiscountPriceWithoutVAT']."', `DiscountPriceWithVAT` = '".(float)$product_data['DiscountPriceWithVAT']."', `ISBN` = '". (int)$product_data['ISBN'] ."', `Manufacturer` = '".$this->db->escape($product_data['Manufacturer'])."', `RestockDate` = '".$product_data['RestockDate']."', `LeadTime` = '".(int)$product_data['LeadTime']."', `PackageWeight` = '".(float)$product_data['PackageWeight']."', `Attribute1` = '".$this->db->escape($product_data['Attribute1'])."', `Attribute2` = '".$this->db->escape($product_data['Attribute2'])."', `Attribute3` = '".$this->db->escape($product_data['Attribute3'])."', `Attribute4` = '".$this->db->escape($product_data['Attribute4'])."', `Attribute5` = '".$this->db->escape($product_data['Attribute5'])."', `Attribute6` = '".$this->db->escape($product_data['Attribute6'])."', `Attribute7` = '".$this->db->escape($product_data['Attribute7'])."', `Attribute8` = '".$this->db->escape($product_data['Attribute8'])."', `Attribute9` = '".$this->db->escape($product_data['Attribute9'])."', `Attribute10` = '".$this->db->escape($product_data['Attribute10'])."', `Country` = '".$this->db->escape($product_data['Country'])."', `Currency` = '".$this->db->escape($product_data['Currency'])."', `Language` = '".$this->db->escape($product_data['Language'])."', `DiscountPriceStartDate` = '".$product_data['DiscountPriceStartDate']."', `DiscountPriceEndDate`= '".$product_data['DiscountPriceEndDate']."' WHERE `id` = '". $sql->row['id'] ."' ");
            $final_data_id = $sql->row['id'];
        } else {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "cedfruugo_final_products` (`ProductId`, `SkuId`, `EAN`, `Brand`, `Category`, `Imageurl1`, `StockStatus`, `StockQuantity`, `Title`, `Description`, `NormalPriceWithoutVAT`, `NormalPriceWithVAT`, `VATRate`, `Imageurl2`, `Imageurl3`, `Imageurl4`, `Imageurl5`, `AttributeSize`, `AttributeColor`, `DiscountPriceWithoutVAT`, `DiscountPriceWithVAT`, `ISBN`, `Manufacturer`, `RestockDate`, `LeadTime`, `PackageWeight`, `Attribute1`, `Attribute2`, `Attribute3`, `Attribute4`, `Attribute5`, `Attribute6`, `Attribute7`, `Attribute8`, `Attribute9`, `Attribute10`, `Country`, `Currency`, `Language`, `DiscountPriceStartDate`, `DiscountPriceEndDate`) VALUES ('".$this->db->escape($product_data['ProductId'])."', '".$this->db->escape($product_data['SkuId'])."', '".(int)$product_data['EAN']."', '".ucwords(strtolower($product_data['Brand']))."', '".strip_tags($product_data['Category'])."', '".$this->db->escape($product_data['Imageurl1'])."', '".$this->db->escape($product_data['StockStatus'])."', '".(int)$product_data['StockQuantity']."', '". $this->db->escape(ucwords(strtolower($product_data['Title']))) ."', '". $this->db->escape(ucwords(strtolower($product_data['Description'])))."', '".(float)$product_data['NormalPriceWithoutVAT']."', '".(float)$product_data['NormalPriceWithVAT']."', '".(float)$product_data['VATRate']."', '".$this->db->escape($product_data['Imageurl2'])."', '".$this->db->escape($product_data['Imageurl3'])."', '".$this->db->escape($product_data['Imageurl4'])."', '".$this->db->escape($product_data['Imageurl5'])."', '".$this->db->escape($product_data['AttributeSize'])."', '".$this->db->escape($product_data['AttributeColor'])."', '".(float)$product_data['DiscountPriceWithoutVAT']."', '".(float)$product_data['DiscountPriceWithVAT']."', '". (int)$product_data['ISBN'] ."', '".$this->db->escape($product_data['Manufacturer'])."', '".$product_data['RestockDate']."', '".(int)$product_data['LeadTime']."', '".(float)$product_data['PackageWeight']."', '".$this->db->escape($product_data['Attribute1'])."', '".$this->db->escape($product_data['Attribute2'])."', '".$this->db->escape($product_data['Attribute3'])."', '".$this->db->escape($product_data['Attribute4'])."', '".$this->db->escape($product_data['Attribute5'])."', '".$this->db->escape($product_data['Attribute6'])."', '".$this->db->escape($product_data['Attribute7'])."', '".$this->db->escape($product_data['Attribute8'])."', '".$this->db->escape($product_data['Attribute9'])."', '".$this->db->escape($product_data['Attribute10'])."', '".$this->db->escape($product_data['Country'])."', '".$this->db->escape($product_data['Currency'])."', '".$this->db->escape($product_data['Language'])."', '".$product_data['DiscountPriceStartDate']."', '".$product_data['DiscountPriceEndDate']."' ) ");
            $final_data_id = $this->db->getLastId();
        }
        return $final_data_id;
    }

    public function getAllMappedProducts(){

        $query = $this->db->query("SELECT product_id FROM `" . DB_PREFIX . "cedfruugo_product_variations` ");
        $result = $query->rows;
        $product_ids = array();
        if(is_array($result) && count($result)) {
            foreach ($result as $key => $value) {
                if (isset($value['product_id']) && $value['product_id']) {
                    $product_ids[] = $value['product_id'];
                }
            }
        }
        return $product_ids;
    }

    public function getAllFruugoProducts()
    {
        $result = $this->db->query("SELECT category FROM `" . DB_PREFIX . "cedfruugo_mapping_details`");
        if ($result && $result->num_rows) {
            $product_ids = array();
            $categories_mapped =array();
            foreach ($result->rows as $key => $store_category) {
                $categories_mapped = array_merge($categories_mapped, json_decode($store_category['category'], true));
            }

            if(count($categories_mapped)){
                $categories_mapped = array_unique($categories_mapped);
                $results = $this->db->query("SELECT product_id FROM `".DB_PREFIX."product_to_category` where category_id IN (".implode(',', $categories_mapped).")");

                if ($results->num_rows) {
                    foreach ($results->rows as $key => $value) {
                        $product_ids[] =  $value['product_id'];
                    }
                }
                return $product_ids;
            }
            return array();
        } else {
            return array();
        }
    }
    public function prepareFruugoProduct($product_id)
    {
        $product_id = (int)$product_id;

        if($product_id)
        {
            $product_status_query = $this->db->query("SELECT `status` FROM `". DB_PREFIX."product` WHERE `product_id` = '". (int) $product_id  ."' ");

            if(isset($product_status_query->row['status']) && $product_status_query->row['status'] == '0' && $this->config->get('ced_fruugo_disabled_product_upload') == '1') {
                return array('error_message' => 'Product is skipped.');
            } else {
                $query = $this->db->query("SELECT profile_id FROM `". DB_PREFIX ."cedfruugo_product_variations` WHERE `product_id` = '".(int)$product_id."' ");
                $result = $query->row;

                if(isset($result) && isset($result['profile_id']))
                {
                    $profile_id = (int)$result['profile_id'];
                    $fetched_mapped_data = $this->db->query("SELECT * FROM `" . DB_PREFIX . "cedfruugo_mapping_details` WHERE `id` = '" . $profile_id . "' ");
                    $mapped_data = $fetched_mapped_data->row;

                    $fruugo_array = array();
                    if(isset($mapped_data) && $mapped_data)
                    {
                        $attribute_array = json_decode($mapped_data['attribute'], true);
                        $variant_array   = json_decode($mapped_data['variant_attribute'], true);
                        $default_array   = json_decode($mapped_data['default_attribute'], true);
                        if(!is_array($attribute_array) || empty($attribute_array))
                        {
                            $attribute_array = array();
                        }
                        if(!is_array($variant_array) || empty($variant_array))
                        {
                            $variant_array = array();
                        }
                        if(!is_array($default_array) || empty($default_array))
                        {
                            $default_array = array();
                        }

                        // Fruugo Category
                        if(isset($mapped_data['FruugoCategory']) && $mapped_data['FruugoCategory']){
                            $fruugo_array['Category'] = $mapped_data['FruugoCategory'];
                        }

                        // Attributes
                        if(isset($attribute_array) && !empty($attribute_array)){
                            foreach ($attribute_array as $key => $value) {
                                $attribute = '';
                                $attribute_id = 0;

                                $explode_res = explode('-', $value);
                                @$attribute = $explode_res[0];
                                @$attribute_id = $explode_res[1];

                                // Attributes (Variants)
                                if($attribute == "attri"){
                                    $query = $this->db->query("SELECT `text` FROM `" . DB_PREFIX . "product_attribute` WHERE product_id = '" . $product_id . "' AND attribute_id = '" . $attribute_id . "' ");
                                    $attri_result = $query->row;

                                    if(!empty($attri_result)){
                                        $fruugo_array[$key]   = $attri_result['text'];
                                    } else {
                                        $fruugo_array[$key] = '';
                                    }
                                }
                                // System Default
                                if($attribute == "system_default"){

                                    $query = $this->db->query("SELECT field_name FROM `" . DB_PREFIX ."cedfruugo_system_default` WHERE id = '" .$attribute_id. "' ");
                                    $result = $query->row;

                                    $system_result = $this->getSystemDefaultDetailFromProduct($product_id);

                                    if(!empty($system_result)){
                                        $fruugo_array[$key]   = $system_result[$result['field_name']];
                                    } else {
                                        $fruugo_array[$key] = '';
                                    }
                                }
                            }
                        }
                        //echo '<pre>'; print_r($fruugo_array); die;
                        // Variant Attributes
                        $combination_array = array();
                        if(isset($variant_array) && !empty($variant_array))
                        {
                            $combination = $this->productOptionCombination($product_id, $profile_id);

                            if(!empty($combination))
                            {
                                foreach($combination as $key1 => $val)
                                {
                                    $option_data = array();
                                    $quantity_array = array();

                                    foreach($variant_array as $key => $value)
                                    {
                                        $explode_res = explode('-', $value);
                                        $option_id = @$explode_res[1];
                                        $price = '0';
                                        //$random_no = '';
                                        foreach($val as $key2 => $key2_value)
                                        {
                                            $option_value_query = $this->db->query("SELECT pov.quantity, pov.price_prefix, pov.price, pov.option_value_id, p.tax_class_id FROM `" . DB_PREFIX . "option_value_description` AS ovd JOIN `" . DB_PREFIX . "product_option_value` AS pov ON (ovd.option_value_id = pov.option_value_id) JOIN `" . DB_PREFIX . "product` AS p ON (p.product_id = pov.product_id) WHERE ovd.option_id = '" . $key2 . "' AND ovd.name = '" . $key2_value . "' AND pov.product_id = '" . $product_id . "' ");
                                            $option_value_res = $option_value_query->row;

                                            // if(isset($option_value_res['option_value_id']) && $option_value_res['option_value_id'])
                                            //     $random_no .= $option_value_res['option_value_id'];

                                            if(isset($option_value_res['quantity']) && $option_value_res['quantity'])
                                                $quantity_array[] = $option_value_res['quantity'];

                                            if(isset($option_value_res['price']) && $option_value_res['price'])
                                            {
                                                if($option_value_res['price_prefix'] == '+')
                                                    @$price +=(float)$option_value_res['price'];
                                                elseif($option_value_res['price_prefix'] == '-')
                                                    @$price -=(float)$option_value_res['price'];

                                                // if(!empty($option_value_res['tax_class_id'])){
                                                //   $price_with_tax = $this->tax->getTax($price, $option_value_res['tax_class_id']);
                                                //   $price_with_tax += $price;
                                                // }
                                            }

                                            if(isset($val['sku']))
                                                $option_data['SkuId'] = $val['sku'];
                                            if(isset($option_value_res) && !empty($option_value_res['quantity']))
                                            {
                                                if(isset($fruugo_array['NormalPriceWithoutVAT']) && $fruugo_array['NormalPriceWithoutVAT'] > '0' && $price > '0')
                                                    $option_data['NormalPriceWithoutVAT'] = $fruugo_array['NormalPriceWithoutVAT'] + $price;
                                                if(isset($fruugo_array['NormalPriceWithVAT']) && $fruugo_array['NormalPriceWithVAT'] > '0' && $price > '0')
                                                    $option_data['NormalPriceWithVAT'] = $fruugo_array['NormalPriceWithVAT'] + $price;
                                                if(isset($fruugo_array['DiscountPriceWithoutVAT']) && $fruugo_array['DiscountPriceWithoutVAT'] > '0' && $price > '0')
                                                    $option_data['DiscountPriceWithoutVAT'] = $fruugo_array['DiscountPriceWithoutVAT'] + $price;
                                                if(isset($fruugo_array['DiscountPriceWithVAT']) && $fruugo_array['DiscountPriceWithVAT'] > '0' && $price > '0')
                                                    $option_data['DiscountPriceWithVAT'] = $fruugo_array['DiscountPriceWithVAT'] + $price;
                                            }
                                            if (isset($val[$option_id]))
                                                $option_data[$key] = $val[$option_id];
                                            else
                                                $option_data[$key] = '';
                                        }
                                        $option_data['StockQuantity'] = min($quantity_array);
                                        //$option_data['random_no'] = $random_no;
                                    }
                                    $combination_array[$key1] = $option_data;
                                }
                            } else {
                                foreach($variant_array as $key => $value)
                                {
                                    $fruugo_array[$key] = '';
                                }
                            }
                        }

                        // Default Attribute
                        if(isset($default_array) && !empty($default_array)){
                            if(!empty($default_array['Brand']) && empty($fruugo_array['Brand'])){
                                $fruugo_array['Brand']         = $default_array['Brand'];
                            }
                            if(!empty($default_array['VATRate']) && empty($fruugo_array['VATRate'])){
                                $fruugo_array['VATRate']       = $default_array['VATRate'];
                            }
                            if(!empty($default_array['Manufacturer']) && empty($fruugo_array['Manufacturer'])){
                                $fruugo_array['Manufacturer']  = $default_array['Manufacturer'];
                            }
                            if(!empty($default_array['LeadTime']) && empty($fruugo_array['LeadTime'])){
                                $fruugo_array['LeadTime']      = $default_array['LeadTime'];
                            }
                            if(!empty($default_array['PackageWeight']) && empty($fruugo_array['PackageWeight'])){
                                $fruugo_array['PackageWeight'] = $default_array['PackageWeight'];
                            }
                            // Country
                            $country_id = $this->config->get('ced_fruugo_country');
                            $country_query = $this->db->query("SELECT country_code FROM `". DB_PREFIX ."cedfruugo_country_currency` WHERE id = '". $country_id."' ");
                            if($country_query->num_rows)
                                $fruugo_array['Country'] = $country_query->row['country_code'];
                            else
                                $fruugo_array['Country'] = '';

                            // Language
                            $language_id = $this->config->get('ced_fruugo_language');
                            $language_query = $this->db->query("SELECT language FROM `". DB_PREFIX ."cedfruugo_country_currency` WHERE id = '". $language_id."' ");
                            if($language_query->num_rows)
                                $fruugo_array['Language'] = $language_query->row['language'];
                            else
                                $fruugo_array['Language'] = '';

                            // Currency
                            $currency_id = $this->config->get('ced_fruugo_currency');
                            $currency_query = $this->db->query("SELECT currency_code FROM `". DB_PREFIX ."cedfruugo_country_currency` WHERE id = '". $currency_id."' ");
                            if($currency_query->num_rows)
                                $fruugo_array['Currency'] = $currency_query->row['currency_code'];
                            else
                                $fruugo_array['Currency'] = '';

                        }

                        $query = $this->db->query("SELECT sku, quantity, price, image FROM `" . DB_PREFIX . "product` WHERE product_id = '" . $product_id . "' ");
                        $res = $query->row;

                        if(empty($fruugo_array['SkuId']))
                            $fruugo_array['SkuId'] = $res['sku'];
                        if(empty($fruugo_array['StockQuantity']))
                            $fruugo_array['StockQuantity'] = $res['quantity'];

                        if(empty($fruugo_array['StockStatus'])){
                            if(!empty($fruugo_array['StockQuantity'])){
                                $fruugo_array['StockStatus'] = 'INSTOCK';
                                if(empty($fruugo_array['LeadTime']))
                                    $fruugo_array['LeadTime'] = '5';
                            } else if($fruugo_array['StockQuantity'] == '0'){
                                $fruugo_array['StockStatus'] = 'OUTOFSTOCK';
                                $fruugo_array['LeadTime'] = '';
                            } else {
                                $fruugo_array['StockStatus'] = 'NOTAVAILABLE';
                            }
                        } elseif($fruugo_array['StockStatus'] == 'INSTOCK'){
                            if(empty($fruugo_array['LeadTime']))
                                $fruugo_array['LeadTime'] = '5';
                        }
                        elseif($fruugo_array['StockStatus'] == 'OUTOFSTOCK') {
                            $fruugo_array['LeadTime'] = '';
                        }

                        $fruugo_array['ProductId'] = $product_id;
                        $fruugo_array['Imageurl1'] = $res['image'];

                        $query = $this->db->query("SELECT image FROM `" . DB_PREFIX . "product_image` WHERE product_id = '" . $product_id . "' ");
                        $image = $query->rows;

                        $i = '2';
                        foreach($image as $img => $value){
                            if($i<=5 && $value['image']){
                                $fruugo_array['Imageurl'.$i] = $value['image'];
                                $i++;
                            } else break;
                        }

                        for($i = 1; $i<=5; $i++)
                        {
                            if(isset($fruugo_array['Imageurl'.$i]) && $fruugo_array['Imageurl'.$i]){
                                if(!defined('HTTPS_CATALOG'))
                                    $fruugo_array['Imageurl'.$i] = HTTPS_SERVER . "image/" . $fruugo_array['Imageurl'.$i];
                                else
                                    $fruugo_array['Imageurl'.$i] = HTTPS_CATALOG . "image/" . $fruugo_array['Imageurl'.$i];
                            }
                            else{
                                $fruugo_array['Imageurl'.$i] = '';
                            }
                        }

                        $sql = $this->db->query("SELECT date_start, date_end FROM " . DB_PREFIX . "product_special WHERE product_id = '". (int)$product_id ."' AND customer_group_id = '" . (int)$this->config->get('ced_fruugo_customer_group_id') . "' LIMIT 1");
                        $res = $sql->row;

                        if(isset($res) && !empty($res)){
                            $fruugo_array['DiscountPriceStartDate'] = $res['date_start'];
                            $fruugo_array['DiscountPriceEndDate'] = $res['date_end'];
                        }

                        if(isset($fruugo_array) && !empty($fruugo_array)){
                            if(empty($fruugo_array['DiscountPriceWithoutVAT']))
                                $fruugo_array['DiscountPriceWithoutVAT'] = '';
                            if(empty($fruugo_array['DiscountPriceWithVAT']))
                                $fruugo_array['DiscountPriceWithVAT'] = '';
                            if(empty($fruugo_array['ISBN']))
                                $fruugo_array['ISBN'] = '0';
                            if(empty($fruugo_array['RestockDate']))
                                $fruugo_array['RestockDate'] = '0';
                            if(empty($fruugo_array['PackageWeight']))
                                $fruugo_array['PackageWeight'] = '0';
                            if(empty($fruugo_array['DiscountPriceStartDate']) || $fruugo_array['DiscountPriceStartDate'] == '0000-00-00')
                                $fruugo_array['DiscountPriceStartDate'] = '0';
                            if(empty($fruugo_array['DiscountPriceEndDate']) || $fruugo_array['DiscountPriceEndDate'] == '0000-00-00')
                                $fruugo_array['DiscountPriceEndDate'] = '0';
                        }

                        if(isset($combination_array) && !empty($combination_array)){
                            $temp_variant_array = array();
                            foreach ($combination_array as $key => $value) {
                                $temp_variant_array[] = array_merge($fruugo_array, $value);
                            }
                            $fruugo_array = $temp_variant_array;
                        }
                    }
                    //echo '<pre>'; print_r($fruugo_array); die;

                    if(!empty($fruugo_array))
                        return $fruugo_array;
                    else
                        return array('error_message' => 'Product Id Not Found.');
                }

            }
        } else {
            return array('error_message' => 'Product Id Not Found.');
        }
    }

    public function getSystemDefaultDetailFromProduct($product_id)
    {

        $product_id = (int)$product_id;
        $query = $this->db->query("SELECT p.status, p.upc, p.ean, p.isbn, p.mpn, p.quantity, p.price, p.tax_class_id, p.weight, p.date_available, pd.name, pd.description, m.name AS manufacturer, (SELECT ss.name FROM " . DB_PREFIX . "stock_status ss WHERE ss.stock_status_id = p.stock_status_id AND ss.language_id = '" . (int)$this->config->get('ced_fruugo_store_language') . "') AS stock_status, (SELECT price FROM " . DB_PREFIX . "product_special ps WHERE ps.product_id = p.product_id AND ps.customer_group_id = '" . (int)$this->config->get('ced_fruugo_customer_group_id') . "' AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) ORDER BY ps.priority ASC, ps.price ASC LIMIT 1) AS special FROM `" . DB_PREFIX . "product` AS p JOIN `" . DB_PREFIX . "product_description` AS pd ON (pd.product_id = p.product_id) JOIN `" . DB_PREFIX . "manufacturer` AS m ON (p.manufacturer_id = m.manufacturer_id)  WHERE p.product_id = '" . $product_id . "' AND pd.language_id = '".$this->config->get('ced_fruugo_store_language') ."' ");

        $result = $query->row;

        // echo '<pre>'; print_r($result); die;

        if(isset($result['tax_class_id']) && $result['tax_class_id'] != '0'){
            $sql = $this->db->query("SELECT tra.rate AS tax_rule FROM `" . DB_PREFIX . "tax_rule` AS tru JOIN `" . DB_PREFIX . "tax_rate` AS tra ON (tru.tax_rate_id = tra.tax_rate_id) WHERE tru.tax_class_id = '" . $result['tax_class_id'] . "' ");
            $tax_result = $sql->row;

            if($tax_result['tax_rule'] != '0')
                $tax_rule = $tax_result['tax_rule'];
            else
                $tax_rule = '0';

            if(isset($result) && !empty($result['special']))
                $price_with_tax = $this->tax->getTax($result['special'], $result['tax_class_id']);
            else
                $price_with_tax = $this->tax->getTax($result['price'], $result['tax_class_id']);
        }

        // Model
        if(isset($result['model']) && !empty($result['model']))
            $model = $result['model'];
        else
            $model = '';
        // UPC
        if(isset($result['upc']) && !empty($result['upc']))
            $upc = $result['upc'];
        else
            $upc = '0';
        // EAN
        if($this->config->get('is_manufacturer') == 'yes')
            $ean = 'EXCEP';
        else {
            if (isset($result['ean']) && !empty($result['ean']))
                $ean = $result['ean'];
            else
                $ean = '0';
        }
        // ISBN
        if(isset($result['isbn']) && !empty($result['isbn']))
            $isbn = $result['isbn'];
        else
            $isbn = '0';
        // MPN
        if(isset($result['mpn']) && !empty($result['mpn']))
            $mpn = $result['mpn'];
        else
            $mpn = '0';
        // Quantity
        if(isset($result['quantity']) && !empty($result['quantity']))
            $quantity = $result['quantity'];
        else
            $quantity = '0';
        // Price w/o Tax
        if(isset($result['special']) && !empty($result['special']))
            $price_wo_tax = $this->getFruugoProductPrice($result['special']);
        elseif(isset($result['price']) && !empty($result['price']))
            $price_wo_tax = $this->getFruugoProductPrice($result['price']);
        else
            $price_wo_tax = '0.00';
        // Price With Tax
        if(isset($price_with_tax) && !empty($price_with_tax))
            $price_with_tax += $price_wo_tax;
        else
            $price_with_tax = '0.00';
        // Name
        if(isset($result['name']) && !empty($result['name']))
            $name = $result['name'];
        else
            $name = '';
        // Description
        if(isset($result['description']) && !empty($result['description']))
            $description = $result['description'];
        else
            $description = '';
        // Manufacturer
        if(isset($result['manufacturer']) && !empty($result['manufacturer']))
            $manufacturer = $result['manufacturer'];
        else
            $manufacturer = '';
        // Tax Rule
        if(isset($tax_result['tax_rule']) && !empty($tax_result['tax_rule']))
            $tax_rule = $tax_result['tax_rule'];
        else
            $tax_rule = '0';
        // Stock Status
        if(isset($result['status']) && $result['status'] == 0 && $this->config->get('ced_fruugo_disabled_product_upload') == '2'){
            $stock_status = 'OUTOFSTOCK';
        } else {
            if(isset($result['stock_status']) && !empty($result['stock_status'])){
                if($result['stock_status'] == 'In stock')
                    $stock_status = 'INSTOCK';
                elseif($result['stock_status'] == 'Out of stock')
                    $stock_status = 'OUTOFSTOCK';
                else
                    $stock_status = $result['stock_status'];
            } else
                $stock_status = '';
        }
        // Weight
        if(isset($result['weight']) && !empty($result['weight']))
            $weight = $result['weight'];
        else
            $weight = '0';
        // Date Available
        if(isset($result['date_available']) && !empty($result['date_available']))
            $date_available = $result['date_available'];
        else
            $date_available = '';

        $price_type = $this->config->get('ced_fruugo_price_type');
        if($price_type == '1')   // Normal Price without VAT
        {
            $price_wo_tax = $price_wo_tax;
            $price_with_tax = '0';
        }  else if($price_type == '2') {
            $price_wo_tax = '0';
            $price_with_tax = $price_with_tax;
        }


        return array(
            'model' => $model,
            'upc' => $upc,
            'ean' => $ean,
            'isbn' => $isbn,
            'mpn' => $mpn,
            'quantity' => $quantity,
            'price_with_tax' =>  $price_with_tax,
            'price' => $price_wo_tax,
            'name' => $name,
            'description' => $description,
            'manufacturer' => $manufacturer,
            'tax_rule' => $tax_rule,
            'stock_status' => $stock_status,
            'weight' => $weight,
            'date_available' => $date_available
        );
    }

    public function getFruugoProductPrice($price)
    {
        if($price) {
            $fruugo_price = 0;
            $price_variation_type = $this->config->get('ced_fruugo_price_variant_type');
            $price_variation_type_ampount =(float) $this->config->get('ced_fruugo_price_variant_amount');
            switch ($price_variation_type) {
                case '1':    //regular
                    $fruugo_price = $price;
                    break;

                case 'special':
                    $fruugo_price = $price;
                    break;

                case '2':    // increase_by_amount
                    $fruugo_price = $price + $price_variation_type_ampount;
                    break;

                case '3':  // decrease_by_amount
                    $fruugo_price = $price - $price_variation_type_ampount;
                    break;

                case '4':   // increase_by_percent
                    $fruugo_price = $price + ($price * $price_variation_type_ampount)/100;
                    break;

                case '5':   // decrease_by_percent
                    $fruugo_price = $price - ($price * $price_variation_type_ampount)/100;
                    break;

                default:
                    $fruugo_price = $price;
                    break;
            }
            return $fruugo_price ;
        }
        return 0;
    }

    public function productOptionCombination($product_id, $profile_id=0)
    {
        $product_id = (int)$product_id;
        $profile_id = (int)$profile_id;
        $product_variations = array();
        $product_options = $this->getProductOptionsValue($product_id, $profile_id);
        $variants = array();
        $array_combination=array();
        $op_count=0;
        if(!isset($product_options['0']))
        {
            $temp_productOptions = $product_options;
            $product_options = array();
            $product_options['0'] = $temp_productOptions;
        }
        foreach ($product_options as $key => $value)
        {
            if(isset($value['option_id']) && $value['option_id']!="")
            {
                if(isset($value['option_id']) && in_array(trim($value['option_name']),array('Select','Radio','Checkbox','Size')))
                {
                    foreach ($value['product_option_value'] as $keys => $val)
                    {
                        if(isset($val['option_value_id']) && $val['option_value_id']!=""){
                            $variants[$op_count]=$value['option_id'];
                            $array_combination[$op_count][]=$val['option_value_name'];
                        }
                    }
                    $op_count++;
                }
            }
        }

        // if(empty($array_combination)){
        //     @$option_id   = $product_options[0]['option_id'];
        //     @$option_name = $product_options[0]['option_name'];
        //     @$product_option_value = $product_options[0]['product_option_value'];

        //     if(isset($option_id) && in_array(trim($option_name),array('Select','Radio','Checkbox','Size', 'Colour')))
        //     {
        //         foreach ($product_option_value as $keys => $val)
        //         {
        //             if(isset($val['option_value_id']) && $val['option_value_id']!=""){
        //                 $variants[$op_count]=$option_id;
        //                 $array_combination[$op_count][]=$val['option_value_name'];
        //             }
        //         }
        //     }
        // }

        $matrix_options=$this->combinations($array_combination);
        $matrixarray=array();
        $matrix=array();
        $opt_val_id = '0';
        $option_array = array();
        foreach ($product_options as $key => $value)
        {
            if(isset($value['option_id']) && !empty($value['option_id']))
            {
                foreach ($value['product_option_value'] as $keys => $val)
                {
                    $opt_val = $val['option_value_id'];
                    $option_array[$opt_val]=$val['option_value_name'];
                }
                $opt_val_id++;
            }
        }

        if(count($variants)=='1'){
            $this->db->query("DELETE FROM `". DB_PREFIX."cedfruugo_product_attribute_combination` WHERE product_id = '". $product_id ."' AND profile_id = '". $profile_id ."' ");
            $this->db->query("DELETE FROM `" . DB_PREFIX . "cedfruugo_final_products` WHERE ProductId = '". $product_id."' ");

            foreach ($matrix_options as $key => $value) {

                if(!empty($option_array)){
                    $random_no = '';
                    foreach($option_array as $key2 => $val2){
                        if(in_array($val2,array($value)))
                            $random_no .= $key2;
                    }
                }
                //$random_no = substr(str_shuffle('0123456789'), 0, 4);
                $sku = $product_id . '-' . $random_no;

                $matrixarray[]=array($variants['0']=>$value, 'sku'=>$sku);

                $insert_combination = $this->db->query("INSERT INTO `". DB_PREFIX ."cedfruugo_product_attribute_combination` SET product_id = '". $product_id ."', profile_id = '" . $profile_id . "', SkuId = '". $sku ."', combination = '". json_encode($value) ."' ");
            }
        } else {
            $this->db->query("DELETE FROM `". DB_PREFIX."cedfruugo_product_attribute_combination` WHERE product_id = '". $product_id ."' AND profile_id = '". $profile_id ."' ");
            $this->db->query("DELETE FROM `" . DB_PREFIX . "cedfruugo_final_products` WHERE ProductId = '". $product_id."' ");

            foreach ($matrix_options as $key1 => $value) {
                if(is_array($value) && count($value)>0){

                    if(!empty($option_array)){
                        $random_no = '';
                        foreach($option_array as $key2 => $val2){
                            if(in_array($val2,$value))
                                $random_no .= $key2;
                        }
                    }

                    //$random_no = substr(str_shuffle('0123456789'), 0, 4);
                    $sku = $product_id . '-' . $random_no;

                    foreach ($value as $key => $val) {
                        $matrix[$variants[$key]]= $val;
                        $matrix['sku'] = $sku;
                    }

                    $insert_combination = $this->db->query("INSERT INTO `". DB_PREFIX ."cedfruugo_product_attribute_combination` SET product_id = '". $product_id ."', profile_id = '" . $profile_id . "', SkuId = '". $sku ."', combination = '". json_encode($matrix) ."' ");

                    $matrixarray[]=$matrix;

                } else {
                    $matrixarray[$variants['0']]=$matrix_options;
                }
            }
        }
        return $matrixarray;
    }

    public function combinations($arrays, $i = 0) {

        if (!isset($arrays[$i])) {
            return array();
        }
        if ($i == count($arrays) - 1) {
            return $arrays[$i];
        }
        $tmp = $this->combinations($arrays, $i + 1);

        $result = array();
        foreach ($arrays[$i] as $v) {
            foreach ($tmp as $t) {
                $result[] = is_array($t) ? array_merge(array($v), $t) : array($v, $t);
            }
        }
        return $result;
    }

    public function getProductOptionsValue($product_id, $profile_id)
    {
        $product_id = (int)$product_id;
        $profile_id = (int)$profile_id;
        $product_option_data = array();

        $profile_attributes_query = $this->db->query("SELECT variant_attribute FROM `". DB_PREFIX ."cedfruugo_mapping_details` WHERE id = '". $profile_id ."' ");
        $profile_attributes = $profile_attributes_query->row;

        $option_id_array = array();

        if(isset($profile_attributes) && !empty($profile_attributes)){
            $variant_array = json_decode($profile_attributes['variant_attribute'], true);
            if(!is_array($variant_array) || empty($variant_array))
            {
                $variant_array = array();
            }
            foreach ($variant_array as $key2 => $value) {
                $explode_res = explode('-', $value);
                $option_id = @$explode_res[1];
                $option_id_array[] = $option_id;
            }
        }

        $product_option_query = $this->db->query("SELECT po.product_option_id, od.option_id, od.name AS option_name FROM `". DB_PREFIX ."product_option` AS po JOIN `". DB_PREFIX ."option_description` AS od ON (po.option_id = od.option_id) WHERE po.product_id = '". $product_id ."' AND od.language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
        $product_option_result = $product_option_query->rows;

        foreach($product_option_result as $key => $product_option_array){
            if(isset($product_option_array) && in_array(trim($product_option_array['option_id']), $option_id_array))
            {
                $product_option_value_data = array();

                $product_option_value_query = $this->db->query("SELECT pov.product_option_value_id, pov.option_value_id, pov.quantity, pov.price, ovd.name AS option_value_name FROM `". DB_PREFIX ."product_option_value` AS pov JOIN `". DB_PREFIX ."option_value_description` AS ovd ON (pov.option_value_id = ovd.option_value_id) WHERE pov.product_id = '". $product_id ."' AND pov.product_option_id = '". $product_option_array['product_option_id'] ."' AND pov.quantity > '0' AND ovd.language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
                $product_option_value_result = $product_option_value_query->rows;

                foreach($product_option_value_result as $key => $product_option_value_array){

                    $product_option_value_data[] = array(
                        'product_option_value_id' => $product_option_value_array['product_option_value_id'],
                        'option_value_id' => $product_option_value_array['option_value_id'],
                        'option_value_name' => $product_option_value_array['option_value_name'],
                        'quantity' => $product_option_value_array['quantity'],
                        'price' => $product_option_value_array['price'],
                    );
                }

                $product_option_data[] = array(
                    'product_option_id' => $product_option_array['product_option_id'],
                    'product_option_value' => $product_option_value_data,
                    'option_id' => $product_option_array['option_id'],
                    'option_name' =>$product_option_array['option_name']

                );
            }
        }
        return $product_option_data;
    }

    public function fruugoGetRequest($url, $params = array())
    {
        $enable= $this->isEnabled();

        if($enable){
            try {
                $headers = array();
                if($url == 'orders/packinglist'){
                    $headers[] = "Content-Type: application/pdf";
                } else {
                    $headers[] = "Content-Type: application/x-www-form-urlencoded";
                }
                $url =  $this->_api_url.$url;
                $data = '';
                foreach($params as $key=>$value) {
                    $data .= $key.'='.$value.'&';
                }
                $data = trim($data, '&');

                $url = $url.'?'.$data;
                $url = rtrim($url, '?');

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_USERPWD, $this->user . ":" . $this->pass);
                $server_output = curl_exec ($ch);

                $this->log('url');
                $this->log($url);
                $this->log('Headers');
                $this->log($headers);
                $this->log('Parameters');
                $this->log($params);
                $this->log('Responses');
                $this->log($server_output);

                $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $header = substr($server_output, 0, $header_size);
                $body = substr($server_output, $header_size);
                if (!curl_errno($ch)) {
                    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if ($http_code == 200) {
                        return array('success'=>true ,'response'=> $server_output);
                    } else {
                        if($body)
                            return array('success'=>false ,'message'=> $body);
                        else
                            return array('success'=>false ,'message'=> $server_output);
                    }
                }
                curl_close($ch);
            } catch (Exception $e) {
                return array('success'=>false ,'message'=> $e->getMessage());
            }
        } else {
            return array('success'=>false ,'message'=> 'Module is not enable.');
        }
    }

    public function fetchOrders($order , $url)
    {
        $response= '';
        $params = array();
        $queryString = empty($order) ? '' : '?' . http_build_query($order);
        $this->log($order);
        $response = $this->fruugoGetRequest($url . $queryString,$params);

        $this->log($response);
        try {
            $errorMessage= '';
            if ($response) {
                if (isset($response['success']) && $response['success']) {
                    if (isset($response['response']) && $response['response']) {

                        $message = $response['response'];
                        $response = $this->xml2array($message);

                        if (!is_array($response)) {
                            return array('success' => false ,'message' => $message);
                        }
                        $errorMessage = '';
                        if (isset($response['errors'])) {
                            foreach ($response['errors'] as $key => $error)
                            {
                                foreach ($error as $key => $err) {
                                    if (isset($err['description']) && $err['  description']) {
                                        $errorMessage .= $err['description'];
                                    }
                                }
                            }
                        } else {
                            $order_ids = array();

                            if (is_array($response) && isset($response['o:orders'])){
                                $fetchedOrders = $response['o:orders'];

                                if (is_array($fetchedOrders) && isset($fetchedOrders['o:order']) && count($fetchedOrders['o:order'])) {

                                    if(!isset($response['o:orders']['o:order']['0'])){
                                        $temp_orderLine = $response['o:orders']['o:order'];
                                        $fetchedOrders['o:order'] = array();
                                        $fetchedOrders['o:order']['0'] = $temp_orderLine;
                                    }
                                    $totalOrderFetched = count($fetchedOrders['o:order']);

                                    foreach ($fetchedOrders['o:order'] as $key => $value) {

                                        if (isset($value['o:orderId']) && $value['o:orderId']) {
                                            $fruugo_order_id = $value['o:orderId'];
                                            $already_exist = $this->isFruugoOrderIdExist($value['o:orderId'], $value);

                                            if( $already_exist ) {
                                                continue;
                                            } else {

                                                $order_ids[] = $this->prepareOrderData($value);

                                                $this->log(json_encode($value),'6',true);

                                                $order_ids = array_filter($order_ids);
                                                // for auto accept and reject
                                                if ($this->config->get('ced_fruugo_auto_accept_reject') == '1') {
                                                    $this->acceptOrder($fruugo_order_id,'orders/confirm');
                                                }
                                            }
                                        }
                                    }

                                    if (count($order_ids) == $totalOrderFetched) {
                                        return array('success' => true ,'message' => $order_ids);
                                    } else if(count($order_ids) && ($totalOrderFetched > count($order_ids))) {
                                        return array('success' => true ,'message' => $order_ids,'sub_message' => 'Please see Rejected List too.');
                                    } else if(count($order_ids)==0) {
                                        return array('success' => true ,'message' => 'No new Order Found.');
                                    } else {
                                        return array('success' => false ,'message' => 'Order Send to Rejected List.');
                                    }

                                } else {
                                    return array('success' => true ,'message' => 'No new order found.');
                                }
                            }

                        }
                    }
                    if ($errorMessage) {
                        return array('success' => false ,'message' => $errorMessage);
                    }
                } else {

                    return array('success' => false ,'message' => $response['message']);
                }
            } else {
                return array('success' => false ,'message' =>$this->language->get('error_module'));
            }
        }
        catch(Exception $e) {
            $this->log('Order Error:  ' . var_export($response, true));
            $this->log('Order Error Message : ' .$e->getMessage());
            return array('success' => false ,'message' => $e->getMessage());
        }
    }

    function xml2array($contents, $get_attributes = false, $priority = 'tag')
    {
        if (!$contents) return array();
        if (is_array($contents)) return array();
        if (!function_exists('xml_parser_create')) {
            // print "'xml_parser_create()' function not found!";
            return array();
        }
        // Get the XML parser of PHP - PHP must have this module for the parser to work
        $parser = xml_parser_create('');
        xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8"); // http://minutillo.com/steve/weblog/2004/6/17/php-xml-and-character-encodings-a-tale-of-sadness-rage-and-data-loss
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
        xml_parse_into_struct($parser, trim($contents) , $xml_values);
        xml_parser_free($parser);
        if (!$xml_values) return; //Hmm...
        // Initializations
        $xml_array = array();
        $parents = array();
        $opened_tags = array();
        $arr = array();
        $current = & $xml_array; //Refference
        // Go through the tags.
        $repeated_tag_index = array(); //Multiple tags with same name will be turned into an array
        foreach($xml_values as $data) {
            unset($attributes, $value); //Remove existing values, or there will be trouble
            // This command will extract these variables into the foreach scope
            // tag(string), type(string), level(int), attributes(array).
            extract($data); //We could use the array by itself, but this cooler.
            $result = array();
            $attributes_data = array();
            if (isset($value)) {
                if ($priority == 'tag') $result = $value;
                else $result['value'] = $value; //Put the value in a assoc array if we are in the 'Attribute' mode
            }
            // Set the attributes too.
            if (isset($attributes) and $get_attributes) {
                foreach($attributes as $attr => $val) {
                    if ( $attr == 'ResStatus' ) {
                        $current[$attr][] = $val;
                    }
                    if ($priority == 'tag') $attributes_data[$attr] = $val;
                    else $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
                }
            }
            // See tag status and do the needed.
            //echo"<br/> Type:".$type;
            if ($type == "open") { //The starting of the tag '<tag>'
                $parent[$level - 1] = & $current;
                if (!is_array($current) or (!in_array($tag, array_keys($current)))) { //Insert New tag
                    $current[$tag] = $result;
                    if ($attributes_data) $current[$tag . '_attr'] = $attributes_data;
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    $current = & $current[$tag];
                }
                else { //There was another element with the same tag name
                    if (isset($current[$tag][0])) { //If there is a 0th element it is already an array
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                        $repeated_tag_index[$tag . '_' . $level]++;
                    }
                    else { //This section will make the value an array if multiple tags with the same name appear together
                        $current[$tag] = array(
                            $current[$tag],
                            $result
                        ); //This will combine the existing item and the new item together to make an array
                        $repeated_tag_index[$tag . '_' . $level] = 2;
                        if (isset($current[$tag . '_attr'])) { //The attribute of the last(0th) tag must be moved as well
                            $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                            unset($current[$tag . '_attr']);
                        }
                    }
                    $last_item_index = $repeated_tag_index[$tag . '_' . $level] - 1;
                    $current = & $current[$tag][$last_item_index];
                }
            }
            elseif ($type == "complete") { //Tags that ends in 1 line '<tag />'
                // See if the key is already taken.
                if (!isset($current[$tag])) { //New Key
                    $current[$tag] = $result;
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    if ($priority == 'tag' and $attributes_data) $current[$tag . '_attr'] = $attributes_data;
                }
                else { //If taken, put all things inside a list(array)
                    if (isset($current[$tag][0]) and is_array($current[$tag])) { //If it is already an array...
                        // ...push the new element into that array.
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                        if ($priority == 'tag' and $get_attributes and $attributes_data) {
                            $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                        }
                        $repeated_tag_index[$tag . '_' . $level]++;
                    }
                    else { //If it is not an array...
                        $current[$tag] = array(
                            $current[$tag],
                            $result
                        ); //...Make it an array using the existing value and the new value
                        $repeated_tag_index[$tag . '_' . $level] = 1;
                        if ($priority == 'tag' and $get_attributes) {
                            if (isset($current[$tag . '_attr'])) { //The attribute of the last(0th) tag must be moved as well
                                $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                                unset($current[$tag . '_attr']);
                            }
                            if ($attributes_data) {
                                $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                            }
                        }
                        $repeated_tag_index[$tag . '_' . $level]++; //0 and 1 index is already taken
                    }
                }
            }
            elseif ($type == 'close') { //End of tag '</tag>'
                $current = & $parent[$level - 1];
            }
        }
        return ($xml_array);
    }

    public function isFruugoOrderIdExist($fruugo_order_id=0, $orderData = array())
    {
        $isExist = false ;
        if ($fruugo_order_id) {
            $sql = "SELECT `id` FROM `" . DB_PREFIX . "cedfruugo_order` WHERE `fruugo_order_id` = '".$fruugo_order_id."'";

            $result = $this->db->query($sql);

            if ($result->num_rows) {
                $orderStatus = $orderData['o:orderStatus'];
                if(isset($orderData['o:orderLines']) && isset($orderData['o:orderLines']['o:orderLine']) && count($orderData['o:orderLines']['o:orderLine']))
                {
                    if(!isset($orderData['o:orderLines']['o:orderLine']['0']))
                    {
                        $temp_orderLine = $orderData['o:orderLines']['o:orderLine'];
                        $orderData['o:orderLines']['o:orderLine'] = array();
                        $orderData['o:orderLines']['o:orderLine']['0'] = $temp_orderLine;
                    }
                    $orderLine = $orderData['o:orderLines']['o:orderLine']['0'];
                    if($orderLine['o:pendingItems'] > '0')
                        $orderStatus = 'Pending';
                    elseif($orderLine['o:confirmedItems'] > '0')
                        $orderStatus = 'Processed';
                    elseif($orderLine['o:shippedItems'] > '0')
                        $orderStatus = 'Shipped';
                    elseif($orderLine['o:cancelledItems'] > '0')
                        $orderStatus = 'Canceled';
                    elseif($orderLine['o:returnedItems'] > '0')
                        $orderStatus = 'Canceled';
                    else
                        $orderStatus = $orderStatus;
                }
                $this->updateOrderStatus($fruugo_order_id, $orderStatus);
                if(isset($orderData['o:shipments']) && !empty($orderData['o:shipments']))
                {
                    $shipments = $orderData['o:shipments'];
                } else {
                    $shipments = array();
                }
                $this->updatefruugoOrderData($fruugo_order_id, $orderStatus, $orderData['o:orderLines']['o:orderLine'], $shipments);
                $isExist = true ;
            }
        }
        return $isExist;
    }

    public function prepareOrderData( $data = array()) {
        if ($data) {
            $opencart_order_id = 0;
            $fruugo_order_id = $data['o:orderId'];

            if (!$this->isFruugoOrderIdExist($fruugo_order_id, $value)) {
                $id = $this->createFruugoOrder($data);
                if($id)
                    return $id;
            }
        }
    }
    public function createFruugoOrder($data) {

        $order_data   = array();
        
        $customerOrderId      = isset($data['o:customerOrderId']) ? $data['o:customerOrderId'] : '';
        $orderId              = $data['o:orderId'];
        $orderDate            = $data['o:orderDate'];
        if(!empty($this->config->get('ced_fruugo_order_status'))){
            $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". $this->config->get('ced_fruugo_order_status') ."' AND language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
            $res = $sql->row['name'];
            $orderStatus = $res;
        } else {
            $orderStatus = $data['o:orderStatus'];

            // if($orderStatus == 'COMPLETE')
            //     $orderStatus = 'Completed';
            // elseif($orderStatus == 'PENDING')
            //     $orderStatus = 'Pending';
            // elseif($orderStatus == 'CANCELLED')
            //     $orderStatus = 'Cancelled';
            // elseif($orderStatus == 'SHIPPED')
            //     $orderStatus = 'Shipped';
            // elseif($orderStatus == 'PROCESSED')
            //     $orderStatus = 'Processed';
            // else
            //     $orderStatus = $orderStatus;
            if(isset($data['o:orderLines']) && isset($data['o:orderLines']['o:orderLine']) && count($data['o:orderLines']['o:orderLine']))
            {
                if(!isset($data['o:orderLines']['o:orderLine']['0']))
                {
                    $temp_orderLine = $data['o:orderLines']['o:orderLine'];
                    $data['o:orderLines']['o:orderLine'] = array();
                    $data['o:orderLines']['o:orderLine']['0'] = $temp_orderLine;
                }
                $orderLine = $data['o:orderLines']['o:orderLine']['0'];
                if($orderLine['o:pendingItems'] > '0')
                    $orderStatus = 'Pending';
                elseif($orderLine['o:confirmedItems'] > '0')
                    $orderStatus = 'Processed';
                elseif($orderLine['o:shippedItems'] > '0')
                    $orderStatus = 'Shipped';
                elseif($orderLine['o:cancelledItems'] > '0')
                    $orderStatus = 'Canceled';
                elseif($orderLine['o:returnedItems'] > '0')
                    $orderStatus = 'Canceled';
                else
                    $orderStatus = $orderStatus;
            }
        }

        if(!empty($this->config->get('ced_fruugo_customer_email')))
            $email = $this->config->get('ced_fruugo_customer_email');
        else
            $email = $orderId.'@cedfruugocustomer.com';

        if(isset($data['o:shippingAddress']) && count($data['o:shippingAddress']))
        {
            if(!isset($data['o:shippingAddress']['0']))
            {
                $temp_shippingAddress = $data['o:shippingAddress'];
                $data['o:shippingAddress'] = array();
                $data['o:shippingAddress']['0'] = $temp_shippingAddress;
            }
            foreach ($data['o:shippingAddress'] as $key => $shippingAddress)
            {
                $firstName    = $shippingAddress['o:firstName'];
                $lastName     = $shippingAddress['o:lastName'];
                $streetAddress= $shippingAddress['o:streetAddress'];
                $city         = $shippingAddress['o:city'];
                $postalCode   = $shippingAddress['o:postalCode'];
                $countryCode  = $shippingAddress['o:countryCode'];
                $phoneNumber  = $shippingAddress['o:phoneNumber'];
            }
        }

        if(!empty($this->config->get('ced_fruugo_order_carrier'))){
            $res = $this->getExtensions('shipping', $this->config->get('ced_fruugo_order_carrier'));
            $shippingMethod      = $res['code'];
        } else {
            $shippingMethod      = $data['o:shippingMethod'];
        }

        if(isset($data['o:orderLines']) && isset($data['o:orderLines']['o:orderLine']) && count($data['o:orderLines']['o:orderLine']))
        {
            if(!isset($data['o:orderLines']['o:orderLine']['0']))
            {
                $temp_orderLine = $data['o:orderLines']['o:orderLine'];
                $data['o:orderLines']['o:orderLine'] = array();
                $data['o:orderLines']['o:orderLine']['0'] = $temp_orderLine;
            }
            foreach($data['o:orderLines']['o:orderLine'] as $key => $orderLine)
            {
                $currencyCode       = $orderLine['o:currencyCode'];
            }
        }

        // Order Array
        $order_data['invoice_prefix']     = $this->config->get('config_invoice_prefix');
        $order_data['store_id']           = $this->config->get('config_store_id');
        $order_data['store_name']         = $this->config->get('config_name');
        $order_data['store_url']          = HTTPS_SERVER;
        $order_data['customer_id']        = $customerOrderId;
        $order_data['customer_group_id']  = '1';
        $order_data['firstname']          = $firstName;
        $order_data['lastname']           = $lastName;
        $order_data['email']              = $email;
        $order_data['telephone']          = $phoneNumber;
        $order_data['fax']                = '';
        $order_data['order_status']       = $orderStatus;
        $order_data['custom_field']       = array();

        // Payment Detail
        $order_data['payment_firstname']  = $firstName;
        $order_data['payment_lastname']   = $lastName;
        $order_data['payment_company']    = '';
        $order_data['payment_address_1']  = $streetAddress;
        $order_data['payment_address_2']  = '';
        $order_data['payment_city']       = $city;
        $order_data['payment_postcode']   = $postalCode;
        // $state_info = $this->getOpencartZoneByFruugoZoneCode($state);
        $order_data['payment_zone']       = isset($state_info['name']) ? $state_info['name'] : '';
        $order_data['payment_zone_id']    = isset($state_info['zone_id']) ? $state_info['zone_id'] : '0';
        $country_info = $this->getOpencartCountryByFruugoCountryCode($countryCode);
        $order_data['payment_country']    = isset($country_info['country']) ? $country_info['country'] : '';
        $order_data['payment_country_id'] = isset($country_info['country_id']) ? $country_info['country_id'] : '0';
        $order_data['payment_address_format'] = '';
        $order_data['payment_custom_field']   = array();
        $payment_method_id = $this->config->get('ced_fruugo_order_payment');
        $paymentInfo = $this->getExtensions('payment', $payment_method_id);
        $order_data['payment_method']         = isset($paymentInfo['code']) ? $paymentInfo['code'] : 'Fruugo Payment';
        $order_data['payment_code']           = 'FruugoPayment';
        $language_info = $this->getOpencartLanguageByFruugoLanguageCode($data['o:customerLanguageCode']);
        $order_data['payment_language']       = isset($language_info['name']) ? $language_info['name'] : '';
        $order_data['payment_language_id']    = isset($language_info['language_id']) ? $language_info['language_id'] : '0';
        $currency_info = $this->getOpencartCurrencyByFruugoCurrencyCode($currencyCode);
        $order_data['payment_currency']        = isset($currencyCode) ? $currencyCode : '';
        $order_data['payment_currency_id']     = isset($currency_info['currency_id']) ? $currency_info['currency_id'] : '0';

        // Shipping Detail
        $order_data['shipping_firstname']         = $firstName;
        $order_data['shipping_lastname']          = $lastName;
        $order_data['shipping_company']           = '';
        $order_data['shipping_address_1']         = $streetAddress;
        $order_data['shipping_address_2']         = '';
        $order_data['shipping_city']              = $city;
        $order_data['shipping_postcode']          = $postalCode;
        $order_data['shipping_zone']              = isset($state_info['name']) ? $state_info['name'] : '';
        $order_data['shipping_zone_id']           = isset($state_info['zone_id']) ? $state_info['zone_id'] : '0';
        $order_data['shipping_country']           = isset($country_info['country']) ? $country_info['country'] : '';
        $order_data['shipping_country_id']        = isset($country_info['country_id']) ? $country_info['country_id'] : '0';
        $order_data['shipping_address_format']    = '';
        $order_data['shipping_custom_field']      = array( );
        $order_data['shipping_method']            = isset($shippingMethod) ? $shippingMethod : 'Fruugo Shipping';
        $order_data['shipping_code']              = 'FruugoShipping.FruugoShipping';

        // for products
        //$total_price = isset($totalPriceInclVat) ? $totalPriceInclVat : 0;
        $total_shipping_cost = isset($data['o:shippingCostInclVAT']) ? $data['o:shippingCostInclVAT'] : 0;
        //$subtotal = isset($data['subtotal']) ? $data['subtotal'] : 0;
        //$discount_amt = isset($data['discount_amt']) ? $data['discount_amt'] : 0;
        $grandtotal = '0';

        $order_items  = $data['o:orderLines']['o:orderLine'];
        //$grand_total = '0';
        if($order_items && count($order_items))
        {
            if(!isset($order_items['0']))
            {
                $temp_results = $order_items;
                $order_items = array();
                $order_items['0'] = $temp_results;
            }

            $final_item_cost = 0;
            foreach($order_items as $key => $item)
            {
                $item_cost = isset($item['o:itemPriceInclVat']) ? (float)$item['o:itemPriceInclVat'] : 0;
                $qty = isset($item['o:totalNumberOfItems']) ? $item['o:totalNumberOfItems'] : '0';

                $ordered_products = $this->getOpencartProductBySku($item['o:productId'], $item['o:skuId'], $qty, $item, $orderId, $item['o:skuName'], $item_cost, $item['o:itemVat']);
                
                $total_cost = $item_cost * (int)$qty;
                $final_item_cost += (float)$total_cost;
                // $grand_total += $item['o:totalPriceInclVat'];
                // $grandtotal = isset($grand_total) ? $grand_total : 0;
                if($ordered_products)
                    $order_data['products'][] = $ordered_products;
            }
        }

        $grandtotal += $final_item_cost;

        if(isset($order_data['products']) && count($order_data['products'])>0)
        {
            $order_data['vouchers']=array();

            $order_data['totals'][]= array(
                'code' => 'sub_total',
                'title' => 'Sub-Total',
                'value'=>$grandtotal,
                'sort_order' => 1
            );

            $order_data['totals'][]= array(
                'code' => 'shipping',
                'title' => 'Fruugo Shipping',
                'value'=>(float) $total_shipping_cost,
                'sort_order' => 3
            );

            $order_data['totals'][]= array(
                'code' => 'total',
                'title' => 'Total',
                'value'=> (float) $grandtotal+$total_shipping_cost,
                'sort_order' => 9
            );

            $order_data['comment']='';
            $order_data['total']= (float) $grandtotal+$total_shipping_cost;
            $order_data['affiliate_id']='0';
            $order_data['commission']='0';
            $order_data['marketing_id']='0';
            $order_data['tracking']='';
            $order_data['language_id'] = $this->config->get('ced_fruugo_store_language');

            if(isset($currency_info['currency_id']) && !empty($currency_info['currency_id']) && isset($currency_info['value']) && !empty($currency_info['value']))
             {
                $order_data['currency_id'] = $currency_info['currency_id'];
                $order_data['currency_code'] = $currencyCode;
                $order_data['currency_value'] = $currency_info['value'];
            } elseif (isset($this->session->data['currency']) && $this->session->data['currency']) {
                 $order_data['currency_id'] = $this->currency->getId($this->session->data['currency']);
                 $order_data['currency_code'] = $this->session->data['currency'];
                 $order_data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
             }

            if($order_data['currency_value'] == 0)
                $order_data['currency_value'] = '1';

            $order_data['ip'] = '';
            $order_data['forwarded_ip'] = '';
            $order_data['user_agent'] = '';
            $order_data['accept_language'] = '';
            $order_data['shipment_request_data'] = json_encode($data['o:shipments']);

            $query = $this->db->query("SELECT `id` FROM " . DB_PREFIX . "cedfruugo_order WHERE fruugo_order_id='".$orderId."' ");
            if($query->num_rows){
                $this->updateOrderStatus($orderId, $orderStatus);
                $respo = $this->updatefruugoOrderData($orderId, $orderStatus, $data['o:orderLines']['o:orderLine'], $data['o:shipments']);
                //$respo = $this->db->query("UPDATE `" . DB_PREFIX . "cedfruugo_order` SET fruugo_status = '".$orderStatus."', order_data='".$this->db->escape(json_encode($data['o:orderLines']['o:orderLine']))."', `shipment_data` = '" . $this->db->escape(json_encode($data['o:shippingAddress'])) . "' WHERE fruugo_order_id='".$orderId."' ");
            } else {
                $opencart_order_id = $this->addFruugoOrder($order_data);
                $respo = $this->db->query("INSERT INTO " . DB_PREFIX . "cedfruugo_order SET opencart_order_id =  '" . (int)$opencart_order_id . "', fruugo_order_id='".$orderId."', fruugo_status = '". $this->db->escape(strtoupper($orderStatus)) ."', order_data='".$this->db->escape(json_encode($data['o:orderLines']['o:orderLine']))."', `order_place_date` = '" . $this->db->escape($orderDate) . "', `shipment_data` = '" . $this->db->escape(json_encode($data['o:shippingAddress'])) . "', `shipment_request_data` = '". $this->db->escape($order_data['shipment_request_data']) ."' ");
            }

            // $opencart_order_id = $this->addFruugoOrder($order_data);
            // $respo = $this->db->query("INSERT INTO " . DB_PREFIX . "cedfruugo_order SET opencart_order_id =  '" . (int)$opencart_order_id . "', fruugo_order_id='".$orderId."', fruugo_status = '". $orderStatus ."', order_data='".$this->db->escape(json_encode($data['o:orderLines']['o:orderLine']))."', `order_place_date` = '" . $this->db->escape($orderDate) . "', `shipment_data` = '" . $this->db->escape(json_encode($data['o:shippingAddress'])) . "' ");

            if($respo){
                $order_ids[] = $opencart_order_id;
            }
        }else{
            $this->session->data['success'] = "Fruugo Order Can not Imported see Rejected List";
            // continue;
        }

        if (!empty($opencart_order_id)) {
            return $opencart_order_id;
        }
        return false;

    }

    public function getOpencartZoneByFruugoZoneCode($state_code)
    {
        $query=$this->db->query("SELECT `zone_id`, `name` FROM " . DB_PREFIX . "zone WHERE code='".$state_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartCountryByFruugoCountryCode($fruugo_country_code)
    {
        $query=$this->db->query("SELECT c.country_id, cfc.country FROM " . DB_PREFIX . "cedfruugo_country_currency cfc JOIN " . DB_PREFIX . "country c ON (cfc.country_code = c.iso_code_2) WHERE cfc.country_code ='".$fruugo_country_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartLanguageByFruugoLanguageCode($fruugo_language_code)
    {
        $query=$this->db->query("SELECT language_id, name, code FROM " . DB_PREFIX . "language WHERE code ='".$fruugo_language_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartCurrencyByFruugoCurrencyCode($fruugo_currency_code)
    {
        $query=$this->db->query("SELECT c.currency_id, c.value FROM " . DB_PREFIX . "cedfruugo_country_currency cfc JOIN " . DB_PREFIX . "currency c ON (cfc.currency_code = c.code) WHERE cfc.currency_code ='".$fruugo_currency_code."'");
        // $query=$this->db->query("SELECT c.currency_id, cfc.currency_code FROM " . DB_PREFIX . "cedfruugo_country_currency cfc JOIN " . DB_PREFIX . "currency c ON (cfc.currency_code = c.code) WHERE cfc.currency_code ='".$fruugo_currency_code."'");
        //$query = $this->db->query("SELECT currency_id FROM `" . DB_PREFIX . "currency` WHERE code = '".$fruugo_currency_code."' ");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }

    }

    public function getExtensions($type, $payment_method_id)
    {
        $query = $this->db->query("SELECT code FROM " . DB_PREFIX . "extension WHERE `type` = '" . $this->db->escape($type) . "' AND extension_id = '". $payment_method_id ."' ");
        return $query->row;
    }

    public function acceptOrder($fruugo_order_id ,$url = 'orders/confirm', $params = array())
    {
        if($fruugo_order_id && !isset($params['orderId']))
            $params['orderId'] = $fruugo_order_id;

        $result = $this->WPostRequest($url, $params);
        try {
            if (isset($result['success']) && $result['success']) {
                $data = $this->xml2array($result['response']);
                $this->log('processBulkAcknowledge -data');
                $this->log($data);
                $fruugoOrderResponse = $data['o:orders']['o:order'];
                $orderData = $fruugoOrderResponse['o:orderLines']['o:orderLine'];

                if(!empty($this->config->get('ced_fruugo_order_accepted'))){
                    $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". $this->config->get('ced_fruugo_order_accepted') ."' AND language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
                    $res = $sql->row['name'];
                    $orderStatus = $res;
                } else {
                    $orderStatus = $fruugoOrderResponse['o:orderStatus'];

                    if($orderStatus == 'COMPLETE')
                        $orderStatus = 'Completed';
                    elseif($orderStatus == 'PENDING')
                        $orderStatus = 'Pending';
                    elseif($orderStatus == 'CANCELLED')
                        $orderStatus = 'Cancelled';
                    elseif($orderStatus == 'SHIPPED')
                        $orderStatus = 'Shipped';
                    elseif($orderStatus == 'PROCESSED')
                        $orderStatus = 'Processed';
                    else
                        $orderStatus = $orderStatus;
                }

                $this->updateOrderStatus($fruugo_order_id, $orderStatus);
                $this->updatefruugoOrderData($fruugo_order_id, $orderStatus, $orderData, $fruugoOrderResponse['o:shipments']);

                if(isset($data['error'])){
                    return array('success'=>false ,'message' => $data['error']);
                }

//                $response_m = $result['response'];
//                $response_m = json_decode($response_m,true);
//                if (isset($response_m['error'])) {
//                    return array('success'=>false ,'message' => $response_m['error']);
//                }
//                $this->updateOrderStatus($fruugo_order_id, $this->config->get('ced_fruugo_order_accepted'));
                return $result;
            } else {
                return $result;
            }
        }
        catch(Exception $e){
            $this->log('acceptOrder' . var_export($result, true));
            return false;
        }
    }

    public function cancelOrder($ced_fruugo_order_id, $url = 'orders/cancel')
    {
        $params = array();

        try {
            if($ced_fruugo_order_id)
                $params['orderId'] = $ced_fruugo_order_id;
            $sql = $this->db->query("SELECT `reason` FROM `". DB_PREFIX ."cedfruugo_order_error` WHERE `ced_fruugo_order_id` = '". (int) $ced_fruugo_order_id ."'");
            $reason = $sql->row['reason'];
            if(strpos('QUANTITY', $reason))
                $params['cancellationReason'] = 'out_of_stock';
            else
                $params['cancellationReason'] = 'other';
//            $fruugo_order_id = $data['ced_fruugo_order_id'];
//            if($data['ced_fruugo_order_id'])
//                $params['orderId'] = $data['ced_fruugo_order_id'];
//
//            if($data['cancellationReason'])
//                $params['cancellationReason'] = $data['cancellationReason'];

            $result = $this->WPostRequest($url, $params);
            //echo '<pre>'; print_r($result); die;
            if (isset($result['success']) && ($result['success'] == true))
            {
                $data = $this->xml2array($result['response']);
                $this->log('cancelOrder -data');
                $this->log($data);
                if(isset($data['error'])){
                    return array('success'=>false ,'message' => $data['error']);
                }
                $fruugoOrderResponse = $data['o:orders']['o:order'];

                $orderData = $fruugoOrderResponse['o:orderLines']['o:orderLine'];

                if(!empty($this->config->get('ced_fruugo_order_rejected'))){
                    $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". $this->config->get('ced_fruugo_order_rejected') ."' AND language_id = '". $this->config->get('ced_fruugo_store_language') ."' ");
                    $res = $sql->row['name'];
                    $orderStatus = $res;
                } else {
                    $orderStatus = $fruugoOrderResponse['o:orderStatus'];
                    $orderStatus = 'Cancelled';
                }

                if(isset($fruugoOrderResponse['o:shipments']) && !empty($fruugoOrderResponse['o:shipments'])){
                    $shipmentData = $fruugoOrderResponse['o:shipments'];
                } else {
                    $shipmentData = array();
                }

                $this->updateOrderStatus($ced_fruugo_order_id, $orderStatus);
                $this->updatefruugoOrderData($ced_fruugo_order_id, $orderStatus, $orderData, $shipmentData);

                $result['success'] = true;
                $result['message'] = 'Order '. $ced_fruugo_order_id .' Cancelled Successfully!';

                return $result;
            } else {
                return $result;
            }
        }
        catch(Exception $e){
            $this->log('cancelOrder' . var_export($result, true));
            return $e->getMessage();
        }
    }

    // public function getOrderStatusId($name)
    // {
    //     return $this->config->get($name);
    // }

    public function getOpencartProductBySku($product_id, $sku, $quantity, $order_data, $fruugo_order_id, $product_title, $fruugo_price, $totalVat)
    {
        $product=array();
        $sql = "SELECT `status`,`minimum`,`quantity`,`model`,`price`FROM `".DB_PREFIX ."product` WHERE product_id = '". (int) $product_id."' ";
        $query = $this->db->query($sql);

        if($query->num_rows)
        {
            $result = $this->db->query("SELECT `combination` FROM `" . DB_PREFIX . "cedfruugo_product_attribute_combination` WHERE `SkuId`='".$sku."' AND `product_id` = '". (int) $product_id ."' ");
            
            $combination=isset($result->row['combination'])?$result->row['combination']:'{}';

            $status     =$query->row['status'];
            $minimum    =$query->row['minimum'];
            $qty_avail  =$query->row['quantity'];
            $model      =$query->row['model'];
            $price      =$query->row['price'];

            if($status || $this->config->get('ced_fruugo_order_when_disabled'))
            {
                if(($qty_avail >= $quantity) || $this->config->get('ced_fruugo_order_when_qty_not_available'))
                {
                    $product['quantity']  = $quantity;
                    $product['product_id']= $product_id;
                    $product['model']     = $model;
                    $product['subtract']  = $quantity;
                    $product['price']     = ($fruugo_price) ? $fruugo_price : $price;
                    $product['total']     = ($fruugo_price) ? $quantity * $fruugo_price : $quantity * $price;
                    $product['tax']       = ($totalVat) ? $totalVat : '0';
                    $product['reward']    = 0;
                    $product['name']      = $product_title;
                    $product['option']    = json_decode($combination,true);
                    $product['download']  = array();
                    return $product;
                } else {
                    $this->addOrderErrorInfo($fruugo_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                    if($this->config->get('ced_fruugo_auto_accept_reject') == '1') {
                        $this->cancelOrder($fruugo_order_id, 'orders/cancel');
                    }
                    return '0';
                }
            } else {
                $this->addOrderErrorInfo($fruugo_order_id, $order_data,"PRODUCT STATUS IS DISABLED WITH ID ".$product_id, $sku);
                if($this->config->get('ced_fruugo_auto_accept_reject') == '1')
                {
                    $this->cancelOrder($fruugo_order_id, 'orders/cancel');
                }
                return '0';
            }
        } else {
            $sql = "SELECT `product_id`, `status`, `minimum`, `quantity`, `model`, `price` FROM `" . DB_PREFIX . "product` WHERE `sku` = '".$sku."'";
            $product_data = $query = $this->db->query($sql);

            if($product_data && $product_data->num_rows && isset($product_data->row['product_id']))
            {
                $product_id = $product_data->row['product_id'];
                $status     = $product_data->row['status'];
                $minimum    = $product_data->row['minimum'];
                $qty_avail  = $product_data->row['quantity'];
                $model      = $product_data->row['model'];
                $price      = $product_data->row['price'];
                if($status || $this->config->get('ced_fruugo_order_when_disabled'))
                {
                    if(($qty_avail >= $quantity) || $this->config->get('ced_fruugo_order_when_qty_not_available'))
                    {
                        $product['quantity']  = $quantity;
                        $product['product_id']= $product_id;
                        $product['model']     = $model;
                        $product['subtract']  = $quantity;
                        $product['price']     = ($fruugo_price) ? $fruugo_price : $price;
                        $product['total']     = ($fruugo_price) ? $quantity * $fruugo_price : $quantity * $price;
                        $product['tax']       = ($totalVat) ? $totalVat : '0';
                        $product['reward']    = 0;
                        $product['name']      = $product_title;
                        $product['option']    = array();
                        $product['download']  = array();
                        return $product;
                    } else {
                        $this->addOrderErrorInfo($fruugo_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                        if ($this->config->get('ced_fruugo_auto_accept_reject') == '1') {
                            $this->cancelOrder($fruugo_order_id, 'orders/cancel');
                        }
                        return '0';
                    }
                } else {
                    $this->addOrderErrorInfo($fruugo_order_id, $order_data,"PRODUCT STATUS IS DISABLED WITH ID ".$product_id, $sku);
                    if ($this->config->get('ced_fruugo_auto_accept_reject') == '1') {
                        $this->cancelOrder($fruugo_order_id, 'orders/cancel');
                    }
                    return '0';
                }
            } else {
                $this->addOrderErrorInfo($fruugo_order_id, $order_data,"MERCHANT SKU OR PRODUCT DOES NOT EXIST", $sku);
                if ($this->config->get('ced_fruugo_auto_accept_reject') == '1') {
                    $this->cancelOrder($fruugo_order_id, 'orders/cancel');
                }
                return '0';
            }
        }
    }
    public function addOrderErrorInfo($fruugo_order_id, $order_data, $error_message, $sku)
    {
        $already_exists = " SELECT * FROM `" . DB_PREFIX . "cedfruugo_order_error` WHERE `merchant_sku` = '" . $sku . "' AND ced_fruugo_order_id = '" . $fruugo_order_id . "' ";
        $already_exists=$this->db->query($already_exists);
        if(!$already_exists->num_rows)
        {
            $sql = " INSERT INTO `" . DB_PREFIX . "cedfruugo_order_error` (`merchant_sku`, `ced_fruugo_order_id`, `order_data`, `reason`)VALUES('" . $sku . "', '" . $fruugo_order_id . "', '" . $this->db->escape(json_encode($order_data)) . "', '" . $error_message . "')";
            $result=$this->db->query($sql);
            if($result){
                return $fruugo_order_id;
            }
        }
    }
    public function checkOrderIdExists($order_id)
    {
        if($order_id) {
            $results = $this->db->query("SELECT `id` FROM `".DB_PREFIX."cedfruugo_order` where `order_id`='".$order_id."'");
            if ($results && $results->num_rows) {
                return true;
            }
            return false;
        } else {
            return false;
        }
    }

    public function addFruugoOrder($data)
    {

        $this->db->query("INSERT INTO `" . DB_PREFIX . "order` SET invoice_prefix = '" . $this->db->escape($data['invoice_prefix']) . "', store_id = '" . (int)$data['store_id'] . "', store_name = '" . $this->db->escape($data['store_name']) . "', store_url = '" . $this->db->escape($data['store_url']) . "', customer_id = '" . (int)$data['customer_id'] . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', telephone = '" . $this->db->escape($data['telephone']) . "', fax = '" . $this->db->escape($data['fax']) . "', custom_field = '" . $this->db->escape(isset($data['custom_field']) ? serialize($data['custom_field']) : '') . "', payment_firstname = '" . $this->db->escape($data['payment_firstname']) . "', payment_lastname = '" . $this->db->escape($data['payment_lastname']) . "', payment_company = '" . $this->db->escape($data['payment_company']) . "', payment_address_1 = '" . $this->db->escape($data['payment_address_1']) . "', payment_address_2 = '" . $this->db->escape($data['payment_address_2']) . "', payment_city = '" . $this->db->escape($data['payment_city']) . "', payment_postcode = '" . $this->db->escape($data['payment_postcode']) . "', payment_country = '" . $this->db->escape($data['payment_country']) . "', payment_country_id = '" . (int)$data['payment_country_id'] . "', payment_zone = '" . $this->db->escape($data['payment_zone']) . "', payment_zone_id = '" . (int)$data['payment_zone_id'] . "', payment_address_format = '" . $this->db->escape($data['payment_address_format']) . "', payment_custom_field = '" . $this->db->escape(isset($data['payment_custom_field']) ? serialize($data['payment_custom_field']) : '') . "', payment_method = '" . $this->db->escape($data['payment_method']) . "', payment_code = '" . $this->db->escape($data['payment_code']) . "', shipping_firstname = '" . $this->db->escape($data['shipping_firstname']) . "', shipping_lastname = '" . $this->db->escape($data['shipping_lastname']) . "', shipping_company = '" . $this->db->escape($data['shipping_company']) . "', shipping_address_1 = '" . $this->db->escape($data['shipping_address_1']) . "', shipping_address_2 = '" . $this->db->escape($data['shipping_address_2']) . "', shipping_city = '" . $this->db->escape($data['shipping_city']) . "', shipping_postcode = '" . $this->db->escape($data['shipping_postcode']) . "', shipping_country = '" . $this->db->escape($data['shipping_country']) . "', shipping_country_id = '" . (int)$data['shipping_country_id'] . "', shipping_zone = '" . $this->db->escape($data['shipping_zone']) . "', shipping_zone_id = '" . (int)$data['shipping_zone_id'] . "', shipping_address_format = '" . $this->db->escape($data['shipping_address_format']) . "', shipping_custom_field = '" . $this->db->escape(isset($data['shipping_custom_field']) ? serialize($data['shipping_custom_field']) : '') . "', shipping_method = '" . $this->db->escape($data['shipping_method']) . "', shipping_code = '" . $this->db->escape($data['shipping_code']) . "', comment = '" . $this->db->escape($data['comment']) . "', total = '" . (float)$data['total'] . "', affiliate_id = '" . (int)$data['affiliate_id'] . "', commission = '" . (float)$data['commission'] . "', marketing_id = '" . (int)$data['marketing_id'] . "', tracking = '" . $this->db->escape($data['tracking']) . "', language_id = '" . (int)$data['language_id'] . "', currency_id = '" . (int)$data['currency_id'] . "', currency_code = '" . $this->db->escape($data['currency_code']) . "', currency_value = '" . (float)$data['currency_value'] . "', ip = '" . $this->db->escape($data['ip']) . "', forwarded_ip = '" .  $this->db->escape($data['forwarded_ip']) . "', user_agent = '" . $this->db->escape($data['user_agent']) . "', accept_language = '" . $this->db->escape($data['accept_language']) . "', date_added = NOW(), date_modified = NOW() , order_status_id='".$this->getOrderStatusIdByName($data['order_status'])."'");

        $order_id = $this->db->getLastId();

        // Products
        foreach ($data['products'] as $product) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_product SET order_id = '" . (int)$order_id . "', product_id = '" . (int)$product['product_id'] . "', name = '" . $this->db->escape($product['name']) . "', model = '" . $this->db->escape($product['model']) . "', quantity = '" . (int)$product['quantity'] . "', price = '" . (float)$product['price'] . "', total = '" . (float)$product['total'] . "', tax = '" . (float)$product['tax'] . "', reward = '" . (int)$product['reward'] . "'");

            $order_product_id = $this->db->getLastId();

            if(isset($product['option']) && count($product['option'])>0){
                foreach ($product['option'] as $option_id => $option_value) {
                $sql="SELECT pov.product_option_value_id,po.product_option_id,od.name, ovd.name as `value`,o.type FROM ".DB_PREFIX."product_option_value pov LEFT JOIN ".DB_PREFIX."product_option po ON (po.product_id=pov.product_id AND po.option_id=pov.option_id) LEFT JOIN ".DB_PREFIX."option o ON (pov.option_id =o.option_id) LEFT JOIN ".DB_PREFIX."option_description od ON (pov.option_id =od.option_id AND od.language_id = '" . (int)$data['language_id'] . "') JOIN ".DB_PREFIX."option_value_description ovd ON (pov.option_id =ovd.option_id AND pov.option_value_id=ovd.option_value_id AND ovd.language_id = '" . (int)$data['language_id'] . "') WHERE pov.option_value_id =". (int)$option_value." and pov.product_id=".(int)$product['product_id'];

                    $options_data=$this->db->query($sql);
                    if($options_data->num_rows){
                        $option=$options_data->row;
                        $this->db->query("INSERT INTO " . DB_PREFIX . "order_option SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . $this->db->escape($option['name']) . "', `value` = '" . $this->db->escape($option['value']) . "', `type` = '" . $this->db->escape($option['type']) . "'");
                    }
                }
            }
        }

        // Totals
        foreach ($data['totals'] as $total) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = '" . $this->db->escape($total['code']) . "', title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "', sort_order = '" . (int)$total['sort_order'] . "'");
        }

        $this->addOrderHistory($order_id, $this->getOrderStatusIdByName($data['order_status']));

        return $order_id;
    }

    public function acceptOrderByFruugoId($fruugo_order_id, $quantity, $fruugoSkuId, $fruugoProductId,$messageToFruugo='', $messageToCustomer='', $estimatedShippingDate='')
    {
        $params = array();
        if($fruugo_order_id)
            $params['orderId'] = $fruugo_order_id;

        if($quantity && $fruugoSkuId && $fruugoProductId)
            $params['item'] = $fruugoProductId.','.$fruugoSkuId.','.$quantity;

        if($messageToFruugo)
            $params['messageToFruugo'] = $messageToFruugo;

        if($messageToCustomer)
            $params['messageToCustomer'] = $messageToCustomer;

        if($estimatedShippingDate)
            $params['estimatedShippingDate'] = $estimatedShippingDate;

        $response = $this->WPostRequest('orders/confirm', $params);

        return $response;
    }

    public function cancelOrderByFruugoId($fruugo_order_id, $quantity, $fruugoSkuId, $fruugoProductId,$messageToFruugo='', $messageToCustomer='', $cancellationReason='')
    {
        $params = array();
        if($fruugo_order_id)
            $params['orderId'] = $fruugo_order_id;

        if($quantity && $fruugoSkuId && $fruugoProductId)
            $params['item'] = $fruugoProductId.','.$fruugoSkuId.','.$quantity;

        if($messageToFruugo)
            $params['messageToFruugo'] = $messageToFruugo;

        if($messageToCustomer)
            $params['messageToCustomer'] = $messageToCustomer;

        if($cancellationReason)
            $params['cancellationReason'] = $cancellationReason;

        $response = $this->WPostRequest('orders/cancel', $params);
        return $response;
    }

    public function shipOrderByFruugoId($fruugo_order_id, $quantity, $fruugoSkuId, $fruugoProductId,$messageToFruugo='', $messageToCustomer='', $trackingCode='' ,$trackingUrl='')
    {
        $params = array();
        if($fruugo_order_id)
            $params['orderId'] = $fruugo_order_id;

        if($quantity && $fruugoSkuId && $fruugoProductId)
            $params['item'] = $fruugoProductId.','.$fruugoSkuId.','.$quantity;

        if($messageToFruugo)
            $params['messageToFruugo'] = $messageToFruugo;

        if($messageToCustomer)
            $params['messageToCustomer'] = $messageToCustomer;

        if($trackingCode)
            $params['trackingCode'] = $trackingCode;

        if($trackingUrl)
            $params['trackingUrl'] = $trackingUrl;

        $response = $this->WPostRequest('orders/ship', $params);
        $this->log('shipOrderByFruugoId Log');
        $this->log(json_encode($response));
        return $response;
    }

    public function shipCompleteOrder($fruugo_order_id, $messageToFruugo='', $messageToCustomer='', $trackingCode='' ,$trackingUrl='')
    {
        $params = array();
        if($fruugo_order_id)
            $params['orderId'] = $fruugo_order_id;

        if($messageToFruugo)
            $params['messageToFruugo'] = $messageToFruugo;

        if($messageToCustomer)
            $params['messageToCustomer'] = $messageToCustomer;

        if($trackingCode)
            $params['trackingCode'] = $trackingCode;

        if($trackingUrl)
            $params['trackingUrl'] = $trackingUrl;

        $response = $this->WPostRequest('orders/ship', $params);
        $this->log('shipCompleteOrder Log');
        $this->log(json_encode($response));
        return $response;
    }

    public function WPostRequest($url, $params = array()) {
        $enable= $this->isEnabled();
        if($enable){
            try {
                $url = $this->_api_url.$url;
                $body = array();
                if (isset($params['file'])) {
                    if (version_compare(phpversion(), '5.5.0', '>=') === false) {
                        $body['file'] = new CurlFile($params['file'], 'application/xml',basename($params['file']));
                    } else if (function_exists('curl_file_create')) {
                        $body['file'] = curl_file_create($params['file'], 'application/xml', basename($params['file']));
                    } else {
                        $value = "@{$params['file']};filename=" . basename($params['file']).';type=application/xml';
                        $body['file'] = $value;
                    }
                } elseif (isset($params['data'])) {
                    $body = (string)$params['data'];
                } else {
                    $body = http_build_query($params);
                }

                $headers = array();

                $this->log($body);
                $this->log('posted body ');

                $headers[] = "Content-Type: application/XML";

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,$url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS,$body);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_HEADER, 1);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch, CURLOPT_USERPWD, $this->user . ":" . $this->pass);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $server_output = curl_exec($ch);
                $curlError = curl_error($ch);
                $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $header = substr($server_output, 0, $header_size);
                $body = substr($server_output, $header_size);
                $this->log('Headers send');
                $this->log($headers);
                $this->log('Parameters send');
                $this->log($params);
                $this->log('body send');
                $this->log($body);
                $this->log('Post Responses');
                $this->log($server_output);

                if($curlError) {
                    return array('success'=>false ,'message'=> $curlError);
                }
                if (!curl_errno($ch)) {
                    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if ($http_code == 200) {
                        return array('success'=>true ,'response'=> $body);
                    } else {
                        return array('success'=>false ,'message'=> $body);
                    }
                }
                curl_close($ch);

            } catch (Exception $e) {
                return array('success'=>false ,'message'=>$e->getMessage());
            }

        } else {
            return array('success'=>false ,'message'=> 'Module is not enable.');
        }
    }

    public function updateOrderStatus($fruugoOrderId,$orderStatus = '')
    {
        $result = $this->db->query("SELECT `opencart_order_id` FROM `" . DB_PREFIX . "cedfruugo_order` WHERE `fruugo_order_id` = '" . (int)$fruugoOrderId . "'");

        if($result->num_rows){
            $order_id = $result->row['opencart_order_id'];

            // if($orderStatus == 'COMPLETE')
            //     $orderStatus = 'Completed';
            // elseif($orderStatus == 'PENDING')
            //     $orderStatus = 'Pending';
            // elseif($orderStatus == 'CANCELLED')
            //     $orderStatus = 'Cancelled';
            // elseif($orderStatus == 'SHIPPED')
            //     $orderStatus = 'Shipped';
            // elseif($orderStatus == 'PROCESSED')
            //     $orderStatus = 'Processed';
            // else
            //     $orderStatus = $orderStatus;

            $order_status_id = $this->getOrderStatusIdByName($orderStatus);
            $this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = '". $order_status_id ."' WHERE order_id = '".$order_id."' ");
            $this->db->query("UPDATE `" . DB_PREFIX . "order_history` SET order_status_id = '". $order_status_id ."' WHERE order_id = '".$order_id."' ");
        }
    }

    public function updatefruugoOrderData($fruugoOrderId, $status, $data, $shipment_data)
    {
        $this->db->query(" UPDATE `" . DB_PREFIX . "cedfruugo_order` SET `fruugo_status` = '". $this->db->escape(strtoupper($status)) ."' , `order_data` = '". $this->db->escape(json_encode($data)) ."', `shipment_request_data` = '". $this->db->escape(json_encode($shipment_data)) ."' WHERE `fruugo_order_id` = '".$fruugoOrderId."' ");
    }

    public function addOrderHistory($order_id, $order_status_id, $comment ='',$notify = true)
    {
        $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', notify = '" . (int)$notify . "', comment = '" . $this->db->escape($comment) . "', date_added = NOW()");
        $data=array();
        $data['order_status_id']=(int)$order_status_id;
        $data['order_id']=(int)$order_id;
        $data['comment']='A fruugo Order Imported Successfully';
        $data['notify']=(int)$notify;

        $order_info = $this->getOrder($order_id);

        if ($order_info) {
            // Restock
            $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach($product_query->rows as $product) {
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_id = '" . (int)$product['product_id'] . "' AND subtract = '1'");

                $option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                foreach ($option_query->rows as $option) {
                    $this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
                }
            }

            // If order status is 0 then becomes greater than 0 send main html email
            if ($order_status_id) {
                // Load the language for any mails that might be required to be sent out
                $language = new Language($order_info['language_code']);
                $language->load($order_info['language_code']);
                $language->load('mail/order');

                $order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$order_status_id . "' AND language_id = '" . (int)$order_info['language_id'] . "'");

                if ($order_status_query->num_rows) {
                    $order_status = $order_status_query->row['name'];
                } else {
                    $order_status = '';
                }

                $subject = sprintf($language->get('text_new_subject'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'), $order_id);

                // HTML Mail
                $data = array();

                $data['title'] = sprintf($language->get('text_new_subject'), $order_info['store_name'], $order_id);

                $data['text_greeting'] = sprintf($language->get('text_new_greeting'), $order_info['store_name']);
                $data['text_link'] = $language->get('text_new_link');
                $data['text_download'] = $language->get('text_new_download');
                $data['text_order_detail'] = $language->get('text_new_order_detail');
                $data['text_instruction'] = $language->get('text_new_instruction');
                $data['text_order_id'] = $language->get('text_new_order_id');
                $data['text_date_added'] = $language->get('text_new_date_added');
                $data['text_payment_method'] = $language->get('text_new_payment_method');
                $data['text_shipping_method'] = $language->get('text_new_shipping_method');
                $data['text_email'] = $language->get('text_new_email');
                $data['text_telephone'] = $language->get('text_new_telephone');
                $data['text_ip'] = $language->get('text_new_ip');
                $data['text_order_status'] = $language->get('text_new_order_status');
                $data['text_payment_address'] = $language->get('text_new_payment_address');
                $data['text_shipping_address'] = $language->get('text_new_shipping_address');
                $data['text_product'] = $language->get('text_new_product');
                $data['text_model'] = $language->get('text_new_model');
                $data['text_quantity'] = $language->get('text_new_quantity');
                $data['text_price'] = $language->get('text_new_price');
                $data['text_total'] = $language->get('text_new_total');
                $data['text_footer'] = $language->get('text_new_footer');

                $data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');
                $data['store_name'] = $order_info['store_name'];
                $data['store_url'] = $order_info['store_url'];
                $data['customer_id'] = $order_info['customer_id'];
                $data['link'] = $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id;

                $data['order_id'] = $order_id;
                $data['date_added'] = date($language->get('date_format_short'), strtotime($order_info['date_added']));
                $data['payment_method'] = $order_info['payment_method'];
                $data['shipping_method'] = $order_info['shipping_method'];
                $data['email'] = $order_info['email'];
                $data['telephone'] = $order_info['telephone'];
                $data['ip'] = $order_info['ip'];
                $data['order_status'] = $order_status;

                if ($comment && $notify) {
                    $data['comment'] = nl2br($comment);
                } else {
                    $data['comment'] = '';
                }

                if ($order_info['payment_address_format']) {
                    $format = $order_info['payment_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['payment_firstname'],
                    'lastname'  => $order_info['payment_lastname'],
                    'company'   => $order_info['payment_company'],
                    'address_1' => $order_info['payment_address_1'],
                    'address_2' => $order_info['payment_address_2'],
                    'city'      => $order_info['payment_city'],
                    'postcode'  => $order_info['payment_postcode'],
                    'zone'      => $order_info['payment_zone'],
                    'zone_code' => $order_info['payment_zone_code'],
                    'country'   => $order_info['payment_country']
                );

                $data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

                if ($order_info['shipping_address_format']) {
                    $format = $order_info['shipping_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['shipping_firstname'],
                    'lastname'  => $order_info['shipping_lastname'],
                    'company'   => $order_info['shipping_company'],
                    'address_1' => $order_info['shipping_address_1'],
                    'address_2' => $order_info['shipping_address_2'],
                    'city'      => $order_info['shipping_city'],
                    'postcode'  => $order_info['shipping_postcode'],
                    'zone'      => $order_info['shipping_zone'],
                    'zone_code' => $order_info['shipping_zone_code'],
                    'country'   => $order_info['shipping_country']
                );

                $data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));


                // Products
                $data['products'] = array();
                $data['vouchers'] = array();

                foreach ($product_query->rows as $product) {
                    $option_data = array();

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $option_data[] = array(
                            'name'  => $option['name'],
                            'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
                        );
                    }

                    $data['products'][] = array(
                        'name'     => $product['name'],
                        'model'    => $product['model'],
                        'option'   => $option_data,
                        'quantity' => $product['quantity'],
                        'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                        'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value'])
                    );
                }



                // Order Totals
                $data['totals'] = array();

                $order_total_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_total` WHERE order_id = '" . (int)$order_id . "' ORDER BY sort_order ASC");

                foreach ($order_total_query->rows as $total) {
                    $data['totals'][] = array(
                        'title' => $total['title'],
                        'text'  => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
                    );
                }

                // Text Mail
                $text  = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8')) . "\n\n";
                $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";

                if ($comment && $notify) {
                    $text .= $language->get('text_new_instruction') . "\n\n";
                    $text .= $comment . "\n\n";
                }

                // Products
                $text .= $language->get('text_new_products') . "\n";

                foreach ($product_query->rows as $product) {
                    $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                    }
                }


                $text .= "\n";

                $text .= $language->get('text_new_order_total') . "\n";

                foreach ($order_total_query->rows as $total) {
                    $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                }

                $text .= "\n";

                if ($order_info['customer_id']) {
                    $text .= $language->get('text_new_link') . "\n";
                    $text .= $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id . "\n\n";
                }

                // Comment
                if ($order_info['comment']) {
                    $text .= $language->get('text_new_comment') . "\n\n";
                    $text .= $order_info['comment'] . "\n\n";
                }
                $text .= $language->get('text_new_footer') . "\n\n";

                $mail = new Mail();
                $mail->protocol = $this->config->get('config_mail_protocol');
                $mail->parameter = $this->config->get('config_mail_parameter');
                $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                $mail->setTo($order_info['email']);
                $mail->setFrom($this->config->get('config_email'));
                $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                $mail->setText($text);
                $mail->send();

                // Admin Alert Mail
                if ($this->config->get('config_order_mail')) {
                    $subject = sprintf($language->get('text_new_subject'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'), $order_id);

                    // HTML Mail
                    $data['text_greeting'] = $language->get('text_new_received');

                    if ($comment) {
                        if ($order_info['comment']) {
                            $data['comment'] = nl2br($comment) . '<br/><br/>' . $order_info['comment'];
                        } else {
                            $data['comment'] = nl2br($comment);
                        }
                    } else {
                        if ($order_info['comment']) {
                            $data['comment'] = $order_info['comment'];
                        } else {
                            $data['comment'] = '';
                        }
                    }

                    $data['text_download'] = '';

                    $data['text_footer'] = '';

                    $data['text_link'] = '';
                    $data['link'] = '';
                    $data['download'] = '';

                    // Text
                    $text  = $language->get('text_new_received') . "\n\n";
                    $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                    $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                    $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";
                    $text .= $language->get('text_new_products') . "\n";

                    foreach ($product_query->rows as $product) {
                        $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                        $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                        foreach ($order_option_query->rows as $option) {
                            if ($option['type'] != 'file') {
                                $value = $option['value'];
                            } else {
                                $value = utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.'));
                            }

                            $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                        }
                    }

                    foreach ($order_voucher_query->rows as $voucher) {
                        $text .= '1x ' . $voucher['description'] . ' ' . $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']);
                    }

                    $text .= "\n";

                    $text .= $language->get('text_new_order_total') . "\n";

                    foreach ($order_total_query->rows as $total) {
                        $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                    }

                    $text .= "\n";

                    if ($order_info['comment']) {
                        $text .= $language->get('text_new_comment') . "\n\n";
                        $text .= $order_info['comment'] . "\n\n";
                    }

                    $mail = new Mail();
                    $mail->protocol = $this->config->get('config_mail_protocol');
                    $mail->parameter = $this->config->get('config_mail_parameter');
                    $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                    $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                    $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                    $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                    $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                    $mail->setTo($this->config->get('config_email'));
                    $mail->setFrom($this->config->get('config_email'));
                    $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                    $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                    //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                    $mail->setText($text);
                    $mail->send();

                    // Send to additional alert emails
                    $emails = explode(',', $this->config->get('config_mail_alert'));
                    foreach ($emails as $email) {
                        if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $mail->setTo($email);
                            $mail->send();
                        }
                    }
                }
            }
        }
    }
    public function getOrderStatusIdByName($name)
    {
        $sql ="SELECT `order_status_id` FROM `".DB_PREFIX."order_status` WHERE `name`='".$name."'";
        $query=$this->db->query($sql);
        if($query && $query->num_rows)
            return $query->row['order_status_id'];
    }
    public function getOrder($order_id)
    {
        $order_query = $this->db->query("SELECT *, (SELECT CONCAT(c.firstname, ' ', c.lastname) FROM " . DB_PREFIX . "customer c WHERE c.customer_id = o.customer_id) AS customer FROM `" . DB_PREFIX . "order` o WHERE o.order_id = '" . (int)$order_id . "'");

        if ($order_query->num_rows) {
            $reward = 0;

            $order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach ($order_product_query->rows as $product) {
                $reward += $product['reward'];
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['payment_country_id'] . "'");

            if ($country_query->num_rows) {
                $payment_iso_code_2 = $country_query->row['iso_code_2'];
                $payment_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $payment_iso_code_2 = '';
                $payment_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['payment_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $payment_zone_code = $zone_query->row['code'];
            } else {
                $payment_zone_code = '';
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['shipping_country_id'] . "'");

            if ($country_query->num_rows) {
                $shipping_iso_code_2 = $country_query->row['iso_code_2'];
                $shipping_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $shipping_iso_code_2 = '';
                $shipping_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['shipping_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $shipping_zone_code = $zone_query->row['code'];
            } else {
                $shipping_zone_code = '';
            }

            if ($order_query->row['affiliate_id']) {
                $affiliate_id = $order_query->row['affiliate_id'];
            } else {
                $affiliate_id = 0;
            }

            $affiliate_firstname = '';
            $affiliate_lastname = '';

            $language_code = '';
            $language_filename = '';
            $language_directory = '';

            return array(
                'order_id'                => $order_query->row['order_id'],
                'invoice_no'              => $order_query->row['invoice_no'],
                'invoice_prefix'          => $order_query->row['invoice_prefix'],
                'store_id'                => $order_query->row['store_id'],
                'store_name'              => $order_query->row['store_name'],
                'store_url'               => $order_query->row['store_url'],
                'customer_id'             => $order_query->row['customer_id'],
                'customer'                => $order_query->row['customer'],
                'customer_group_id'       => $order_query->row['customer_group_id'],
                'firstname'               => $order_query->row['firstname'],
                'lastname'                => $order_query->row['lastname'],
                'email'                   => $order_query->row['email'],
                'telephone'               => $order_query->row['telephone'],
                'fax'                     => $order_query->row['fax'],
                'custom_field'            => unserialize($order_query->row['custom_field']),
                'payment_firstname'       => $order_query->row['payment_firstname'],
                'payment_lastname'        => $order_query->row['payment_lastname'],
                'payment_company'         => $order_query->row['payment_company'],
                'payment_address_1'       => $order_query->row['payment_address_1'],
                'payment_address_2'       => $order_query->row['payment_address_2'],
                'payment_postcode'        => $order_query->row['payment_postcode'],
                'payment_city'            => $order_query->row['payment_city'],
                'payment_zone_id'         => $order_query->row['payment_zone_id'],
                'payment_zone'            => $order_query->row['payment_zone'],
                'payment_zone_code'       => $payment_zone_code,
                'payment_country_id'      => $order_query->row['payment_country_id'],
                'payment_country'         => $order_query->row['payment_country'],
                'payment_iso_code_2'      => $payment_iso_code_2,
                'payment_iso_code_3'      => $payment_iso_code_3,
                'payment_address_format'  => $order_query->row['payment_address_format'],
                'payment_custom_field'    => unserialize($order_query->row['payment_custom_field']),
                'payment_method'          => $order_query->row['payment_method'],
                'payment_code'            => $order_query->row['payment_code'],
                'shipping_firstname'      => $order_query->row['shipping_firstname'],
                'shipping_lastname'       => $order_query->row['shipping_lastname'],
                'shipping_company'        => $order_query->row['shipping_company'],
                'shipping_address_1'      => $order_query->row['shipping_address_1'],
                'shipping_address_2'      => $order_query->row['shipping_address_2'],
                'shipping_postcode'       => $order_query->row['shipping_postcode'],
                'shipping_city'           => $order_query->row['shipping_city'],
                'shipping_zone_id'        => $order_query->row['shipping_zone_id'],
                'shipping_zone'           => $order_query->row['shipping_zone'],
                'shipping_zone_code'      => $shipping_zone_code,
                'shipping_country_id'     => $order_query->row['shipping_country_id'],
                'shipping_country'        => $order_query->row['shipping_country'],
                'shipping_iso_code_2'     => $shipping_iso_code_2,
                'shipping_iso_code_3'     => $shipping_iso_code_3,
                'shipping_address_format' => $order_query->row['shipping_address_format'],
                'shipping_custom_field'   => unserialize($order_query->row['shipping_custom_field']),
                'shipping_method'         => $order_query->row['shipping_method'],
                'shipping_code'           => $order_query->row['shipping_code'],
                'comment'                 => $order_query->row['comment'],
                'total'                   => $order_query->row['total'],
                'reward'                  => $reward,
                'order_status_id'         => $order_query->row['order_status_id'],
                'affiliate_id'            => $order_query->row['affiliate_id'],
                'affiliate_firstname'     => $affiliate_firstname,
                'affiliate_lastname'      => $affiliate_lastname,
                'commission'              => $order_query->row['commission'],
                'language_id'             => $order_query->row['language_id'],
                'language_code'           => $language_code,
                'language_filename'       => $language_filename,
                'language_directory'      => $language_directory,
                'currency_id'             => $order_query->row['currency_id'],
                'currency_code'           => $order_query->row['currency_code'],
                'currency_value'          => $order_query->row['currency_value'],
                'ip'                      => $order_query->row['ip'],
                'forwarded_ip'            => $order_query->row['forwarded_ip'],
                'user_agent'              => $order_query->row['user_agent'],
                'accept_language'         => $order_query->row['accept_language'],
                'date_added'              => $order_query->row['date_added'],
                'date_modified'           => $order_query->row['date_modified']
            );
        } else {
            return;
        }
    }
    public function updateReceipt($receipt_id, $shop_id, $params) {
        try {
            if($this->getRequestAuthorization()) {
                $tracking_response = $this->getRequestAuthorization()->updateReceipt(array('data' => $params, 'params' => array('receipt_id' => (int)$receipt_id,'shop_id' => $shop_id )));
                // return array('success' => true,'message' => 'Not authorize to UPDATE Receipt.');
                return $tracking_response;
            }
        } catch (Exception $e) {
            $this->log($e->getMessage());
            return array('success' => false,'message' => 'Not authorize to UPDATE Receipt.');
        } catch (Fruugo\FruugoRequestException $e) {
            $this->log($e->getMessage());
            return array('success' => false,'message' => 'Not authorize to UPDATE Receipt.');
        } catch (Fruugo\OAuthException $e) {
            $this->log($e->getMessage());
            return array('success' => false,'message' => 'Not authorize to UPDATE Receipt.');
        }
    }
    public function addTracking($receipt_id, $shop_id, $params) {
        try {
            if($this->getRequestAuthorization()) {
                $tracking_response = $this->getRequestAuthorization()->submitTracking(array('data' => $params, 'params' => array('receipt_id' => (int)$receipt_id,'shop_id' => $shop_id )));
                // return array('success' => true,'message' => 'Not authorize to UPDATE Receipt.');
                return $tracking_response;
            }
        } catch (Exception $e) {
            $this->log($e->getMessage());
            return array('success' => false,'message' => 'Not authorize to UPDATE Receipt.');
        } catch (Fruugo\FruugoRequestException $e) {
            $this->log($e->getMessage());
            return array('success' => false,'message' => 'Not authorize to UPDATE Receipt.');
        } catch (Fruugo\OAuthException $e) {
            $this->log($e->getMessage());
            return array('success' => false,'message' => 'Not authorize to UPDATE Receipt.');
        }
    }
    public function log($data, $force_log =true ) {
        if ($this->config->get('ced_fruugo_debug') || $force_log) {
            $backtrace = debug_backtrace();
            $log = new Log('ced_fruugo.log');
            $log->write('(' . $backtrace[1]['class'] . '::' . $backtrace[1]['function'] . ') - ' . print_r($data, true));
        }
    }

    public function validateProduct($data)
    {
        $result = array();
        $validation = $this->getValidationArray();
        $result['error'] = '';
        foreach ($validation as $key => $value) {
            $key = trim($key);
            if(isset($value['is_required']) && $value['is_required'] && isset($data[$key])) {
                switch ($key) {
                    case 'ProductId':
                        if (isset($data['ProductId']) && $data['ProductId']) {
                            if (strlen(trim($data['ProductId'])) > $value['length']) {
                                $result['error'] .= 'The length of Product id must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'SkuId':
                        if (isset($data['SkuId']) && $data['SkuId']) {
                            if (strlen(trim($data['SkuId'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'EAN':
                        if (isset($data['EAN']) && is_numeric(trim($data['EAN'])) && substr_count($data['EAN'],".") < 1) {
                            if (strlen(trim($data['EAN'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' should be numeric. </br>';
                        }
                        break;
                    case 'Brand':
                        if (isset($data['Brand']) && $data['Brand']) {
                            if (strlen(trim($data['Brand'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'Category':
                        if (isset($data['Category']) && $data['Category']) {
                            if (strlen(trim($data['Brand'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'Imageurl1':
                        if (isset($data['Imageurl1']) && $data['Imageurl1']) {
                            if (strlen(trim($data['Imageurl1'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'StockQuantity':
                        if (isset($data['StockQuantity']) && is_numeric(($data['StockQuantity']))) {
                            if (strlen(trim($data['StockQuantity'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' should be a valid number. </br>';
                        }
                        break;
                    case 'Title':
                        if (isset($data['Title']) && $data['Title']) {
                            if (strlen(trim($data['Title'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'Description':
                        if (isset($data['Description']) && $data['Description']) {
                            if (strlen(trim($data['Description'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'NormalPriceWithoutVAT':
                        if(empty($data['NormalPriceWithVAT'])){
                            if (isset($data['NormalPriceWithoutVAT']) && $data['NormalPriceWithoutVAT']) {
                                if ((float)(trim($data['NormalPriceWithoutVAT']))) {
                                    $data['NormalPriceWithoutVAT'] = number_format(trim($data['NormalPriceWithoutVAT']),2,'.', '');
                                    if (strlen($data['NormalPriceWithoutVAT']) > $value['length']) {
                                        $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                    }
                                } else {
                                    $result['error'] .= $key.' should be numeric. </br>';
                                }
                            } else {
                                $result['error'] .= $key.' is a required field. </br>';
                            }
                        }

                        break;
                    case 'NormalPriceWithVAT':
                        if(empty($data['NormalPriceWithoutVAT'])){
                            if (isset($data['NormalPriceWithVAT']) && $data['NormalPriceWithVAT']) {
                                if ((float)(trim($data['NormalPriceWithVAT']))) {
                                    $data['NormalPriceWithVAT'] = number_format(trim($data['NormalPriceWithVAT']),2,'.', '');
                                    if (strlen($data['NormalPriceWithVAT']) > $value['length']) {
                                        $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                    }
                                } else {
                                    $result['error'] .= $key.' should be numeric. </br>';
                                }
                            } else {
                                $result['error'] .= $key.' is a required field. </br>';
                            }
                        }
                        break;
                    case 'VATRate':
                        if (isset($data['VATRate'])) {
                            if (is_numeric((trim($data['VATRate'])))) {
                                $data['VATRate'] = (float)trim($data['VATRate']);
                                if (strlen($data['VATRate']) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            } else {
                                $result['error'] .= $key.' should be numeric. </br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                }
            } else if(isset($value['is_required']) && !$value['is_required']) {
                if(isset($data[$key]) && !$data[$key])
                    continue;
                switch ($key) {
                    case 'StockStatus':
                        if (isset($data['StockStatus'])) {
                            if (strlen(trim($data['StockStatus'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Imageurl2':
                        if (isset($data['Imageurl2'])) {
                            if (strlen(trim($data['Imageurl2'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Imageurl3':
                        if (isset($data['Imageurl3'])) {
                            if (strlen(trim($data['Imageurl3'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Imageurl4':
                        if (isset($data['Imageurl4'])) {
                            if (strlen(trim($data['Imageurl4'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Imageurl5':
                        if (isset($data['Imageurl5'])) {
                            if (strlen(trim($data['Imageurl5'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'AttributeSize':
                        if (isset($data['AttributeSize'])) {
                            if (strlen(trim($data['AttributeSize'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'AttributeColor':
                        if (isset($data['AttributeColor'])) {
                            if (strlen(trim($data['AttributeColor'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'DiscountPriceWithoutVAT':
                        if (isset($data['DiscountPriceWithoutVAT'])) {
                            if ((float)(trim($data['DiscountPriceWithoutVAT']))) {
                                $data['DiscountPriceWithoutVAT'] = number_format(trim($data['DiscountPriceWithoutVAT']),2,'.', '');
                                if (strlen($data['DiscountPriceWithoutVAT']) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            } else {
                                $result['error'] .= $key.' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'DiscountPriceWithVAT':
                        if (isset($data['DiscountPriceWithVAT'])) {
                            if ((float)(trim($data['DiscountPriceWithoutVAT']))) {
                                $data['DiscountPriceWithVAT'] = number_format(trim($data['DiscountPriceWithVAT']),2,'.', '');
                                if (strlen($data['DiscountPriceWithVAT']) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            } else {
                                $result['error'] .= $key.' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'ISBN':
                        if (isset($data['ISBN'])) {
                            if ((int)(trim($data['ISBN']))) {
                                $data['ISBN'] = (int)trim($data['ISBN']);
                                if (strlen($data['ISBN']) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            } else {
                                $result['error'] .= $key.' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'Manufacturer':
                        if (isset($data['Manufacturer'])) {
                            if (strlen(trim($data['Manufacturer'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'RestockDate':
                        if (isset($data['RestockDate'])) {
                            if(!$this->validDate($data['RestockDate'])) {
                                $result['error'] .= ' '.$key.' does not have a valid value '.$value['length'].'</br>';
                            } else {
                                if (strlen(trim($data['RestockDate'])) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            }
                        }
                        break;
                    case 'LeadTime':
                        if (isset($data['LeadTime'])) {
                            if ((int)(trim($data['LeadTime']))) {
                                $data['LeadTime'] = (int)trim($data['LeadTime']);
                                if (strlen($data['LeadTime']) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            } else {
                                $result['error'] .= $key.' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'PackageWeight':
                        if (isset($data['PackageWeight'])) {
                            if ((int)(trim($data['PackageWeight']))) {
                                $data['PackageWeight'] = (int)trim($data['PackageWeight']);
                                if (strlen($data['PackageWeight']) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            } else {
                                $result['error'] .= $key.' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'Attribute1':
                        if (isset($data['Attribute1'])) {
                            if (strlen(trim($data['Attribute1'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute2':
                        if (isset($data['Attribute2'])) {
                            if (strlen(trim($data['Attribute2'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute3':
                        if (isset($data['Attribute3'])) {
                            if (strlen(trim($data['Attribute3'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute4':
                        if (isset($data['Attribute4'])) {
                            if (strlen(trim($data['Attribute4'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute5':
                        if (isset($data['Attribute5'])) {
                            if (strlen(trim($data['Attribute5'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute6':
                        if (isset($data['Attribute6'])) {
                            if (strlen(trim($data['Attribute6'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute7':
                        if (isset($data['Attribute7'])) {
                            if (strlen(trim($data['Attribute7'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute8':
                        if (isset($data['Attribute8'])) {
                            if (strlen(trim($data['Attribute8'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute9':
                        if (isset($data['Attribute9'])) {
                            if (strlen(trim($data['Attribute9'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Attribute10':
                        if (isset($data['Attribute10'])) {
                            if (strlen(trim($data['Attribute10'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Country':
                        if (isset($data['Country'])) {
                            if (strlen(trim($data['Country'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Currency':
                        if (isset($data['Currency'])) {
                            if (strlen(trim($data['Currency'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'Language':
                        if (isset($data['Language'])) {
                            if (strlen(trim($data['Language'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'DiscountPriceStartDate':
                        if (isset($data['DiscountPriceStartDate'])) {
                            if(!$this->validDate($data['DiscountPriceStartDate'])) {
                                $result['error'] .= ' '.$key.' does not have a valid value '.$value['length'].'</br>';
                            } else {
                                if (strlen(trim($data['DiscountPriceStartDate'])) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            }
                        }
                        break;
                    case 'DiscountPriceEndDate':
                        if (isset($data['DiscountPriceEndDate'])) {
                            if(!$this->validDate($data['DiscountPriceEndDate'])) {
                                $result['error'] .= ' '.$key.' does not have a valid value '.$value['length'].'</br>';
                            } else {
                                if (strlen(trim($data['DiscountPriceEndDate'])) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            }
                        }
                        break;
                }
            } else {
                $result['error'] .= $key.' is Required Field.'.'</br>';
            }
        }
        return $result;
    }

    function getValidationArray()
    {
        return array(
            'ProductId' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'Your own product identifier code that you recognise when it is provided on order information.
                The same ProductId should be used to group together Skus where they are available with multiple options (Colours, Sizes etc.).'
            ),
            'SkuId' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'If the product has multiple options, the SkuId uniquely identifies and separates each option. If a product doesn’t have multiple options the SkuId can be the same as the ProductId.
                Each ProductId & SkuId combination must be unique and not repeated for any other Product(s).'
            ),
            'EAN' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 14,
                'description' => 'The unique GTIN for the product. GTIN stands for Global Trade Item Number - a globally unique number used to identify trade items, products, or services. GTIN is the umbrella term that refers to the entire family of data structures - UPC, EAN, UCC - 8, 12, 13 & 14 digits.
                If you are the manufacturer of the product you can mark the product to be an exception to the requirement rule by using EXCEP in the EAN field.'
            ),
            'Brand' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'The brand name of the product.
'
            ),
            'Category' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 250,
                'description' => 'The category name where the product is located on your own website or the category you wish the product to be classified in on Fruugo.
                The category value must be accurate enough to identify the nature of the product, and if relevant to the type of product it should include gender.'
            ),
            'Imageurl1' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 2150,
                'description' => 'The link to your primary image for a product which will be displayed. A minimum size of 400px x 400px (or larger). The image should be provided on a white background.
                Images will only be updated if the file name is changed, we do not check to see if your file is newer than your last scheduled import.
                Placeholder or images using watermarks are not permitted.'
            ),
            'StockStatus' => array(
                'type' => 'select',
                'is_required' => true ,
                'length' => 12,
                'values' => array(
                    'INSTOCK' => 'INSTOCK',
                    'OUTOFSTOCK' => 'OUTOFSTOCK',
                    'NOTAVAILABLE' => 'NOTAVAILABLE',
                ),
                'description' => 'The stock status of a product which indicates whether it’s available for purchase. The value of the field must be either:</br>
                INSTOCK – If you have the product currently in stock.</br>
                OUTOFSTOCK – The product is currently out of stock but may return.</br>
                NOTAVAILABLE – The product is permanently out of stock and needs to be removed.'
            ),
            'StockQuantity' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 5,
                'description' => 'The quantity of an item you have available to sell. If stock levels are not held a default number is recommended, such as 100 for in stock items and 0 for out of stock items.
                Negative values or decimal places are not supported.'
            ),
            'Title' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 150,
                'description' => 'A concise title for your product in title case (not block capitals) which identifies the nature of the product.
                It should include any brand, model or part number which is widely used to identify the product.
                It should not include any reference to price; shipping; stock; special offers; or promotional text.
                It should not include any reference to size or colour when part of a grouped product.'
            ),
            'Description' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 5000,
                'description' => 'A detailed explanation of the product and its features. Use sentence case.
                Do not include any URLs; Email Addresses; Telephone Numbers; Prices; Shipping information, or references to activity not on our site.'
            ),
            'NormalPriceWithoutVAT' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 7,
                'description' => "  
                  The normal / list price of the product excluding VAT. Must be a numeric value with a decimal separator and not include any currency symbol. For example 4.12. If included, 'NormalPriceWithVAT' must not be included."
            ),
            'NormalPriceWithVAT' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 7,
                'description' => "The normal / list price of the product including VAT. Must be a numeric value with a decimal separator and not include any currency symbol. For example 4.12. If included, 'NormalPriceWithoutVAT' must not be included."
            ),
            'VATRate' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 4,
                'description' => 'The numeric value of the correct VAT rate of the product in your VAT registered country (EU only).
                Do not include % or any other symbols. For example: 20. To be listed as 0 for non-EU based retailers where VAT is not applicable.'
            ),
            'Imageurl2' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "Used to provide additional image URLs for the product. Each URL should be in a separate field with up to 5 images being supported. The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl3' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "Used to provide additional image URLs for the product. Each URL should be in a separate field with up to 5 images being supported. The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl4' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "Used to provide additional image URLs for the product. Each URL should be in a separate field with up to 5 images being supported. The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl5' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "Used to provide additional image URLs for the product. Each URL should be in a separate field with up to 5 images being supported. The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'AttributeSize' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The specific size option of the SKU, which where a product is available in several size choices will present the size option to the retailer. Note: The field becomes mandatory if you have products which are available in multiple sizes.
                We recommend including the size for all products, however the field should not include generic terms such as one size or o/s.'
            ),
            'AttributeColor' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The specific colour option of the SKU, which where a product is available in several colours choices will present the colour option to the retailer. Note: The field becomes mandatory if you have products which are available in multiple colours.
                We recommend including the colour for all products, however the field should not include generic terms such as multi-coloured, mixed or one colour.'
            ),

            'DiscountPriceWithoutVAT' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 6,
                'description' => "The discount / sale price of the product excluding VAT. Must be a numeric value with a decimal separator and not include any currency symbol. For example 4.12.
                Must only be used if you use 'NormalPriceWithoutVAT' for your normal list price. If included 'DiscountPriceWithVAT' must not be included."
            ),
            'DiscountPriceWithVAT' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 6,
                'description' => "The discount / sale price of the product excluding VAT. Must be a numeric value with a decimal separator and not include any currency symbol. For example 4.12.
                Must only be used if you use 'NormalPriceWithVAT' for your normal list price. If included 'DiscountPriceWithoutVAT' must not be included."
            ),
            'ISBN' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 13,
                'description' => 'The unique ISBN for the product. ISBN stands for International Standard Book Number - the globally unique number used to identify publications. The data structure should be either the 10 or 13 digit number (13 preferred). Note: The field becomes mandatory for all books.'
            ),
            'Manufacturer' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 50,
                'description' => 'The name of the manufacturer of the product.'
            ),
            'RestockDate' => array(
                'type' => 'date',
                'is_required' => false ,
                'length' => 9,
                'description' => "The date when a product which is currently marked as OUTOFSTOCK in 'StockStatus' will be back in stock and available for order.
                The date must be provided in one of the following UNIX timestamp formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; DDMM-YY; DD-MM-YYYY; YY-MM-DD; YYYY-MM-DD."
            ),
            'LeadTime' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 2,
                'description' => "The 'LeadTime' has two separate purposes depending on the 'StockStatus' of the product.
              If the product is INSTOCK, the 'LeadTime' indicates the approximiate number of days delay from order to the item being dispatched from the warehouse. Note: Only to be used if the time exceeds 24 hours as 1 day is the default product value.
              If the is OUTOFSTOCK, the 'LeadTime' indicates the approximiate number of days until the product is back in stock and can be dispatched from the warehouse. Note: The product will remain on the site as 'INSTOCK' with the number of days showing as to when it is available."
            ),
            'PackageWeight' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 5,
                'description' => 'The shipping weight of the product provided in grams with no decimal places or unit of measurement. For example, 190. Note: The field becomes mandatory if your shipping rules are calculated based on the total order weight - please see Shipping > Weight Based Shipping. If you are utilising quantity based shipping all products must have a default value of 1000 - please see Shipping > Quantity Based Shipping.'
            ),
            'Attribute1' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute2' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute3' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute4' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute5' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute6' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute7' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute8' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute9' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Attribute10' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
                They should be used so each column only contains one attribute type/value. The semantics of used attribute field must be communicated to a member of the Integration team. Note: The attribute fields should not be used to list product features; only options to be selected by the customer.'
            ),
            'Country' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 150,
                'case' => 'upper',
                'values' => $this->getCountry(),
                //'onClick' => 'getFruugoLanguageCurrency(this)',
                'description' => '  
                  Two digit ISO code (Upper Case) is used to limit a product to listed countries if they have a different restriction to your default account settings. It is an “include” list and for multiple countries should be separated by spaces. For example: IE FR DE. The country codes must be those supported on Fruugo (as listed in Fruugo Countries > Countries; Languages & Currency codes).
                  Note: The field should be left blank if the product does not have a country restriction that differs from your default account settings.'
            ),
            'Currency' => array(
                'type' => 'select',
                'length' => 3,
                'is_required' => false ,
                'values' => $this->getCurrency(),
                'case' => 'upper',
                'description' => 'Three letter ISO code (Upper Case) of the currency of the price fields of the feed, such as NormalPriceWithoutVAT. The currency must be one of those supported on Fruugo (as listed in Fruugo Countries > Countries; Languages; & Currency codes).
                We strongly recommend always using the native currency of your registered country. Note: The field becomes mandatory if the language used is not the native language of your registered country.'
            ),
            'Language' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 2,
                'case' => 'lower',
                'values' => $this->getFruugoLanguage(),
                'description' => "Two digit ISO code (lower case) of the language of the text fields of the feed, such as Title, Description, AttributeColor etc. The language must be one of those supported on Fruugo (as listed in Fruugo Countries > Countries; Languages; & Currency codes).
                The text within the feed should all be in one language. Note: The field becomes mandatory if the language used is not the native language of your registered country."
            ),
            'DiscountPriceStartDate' => array(
                'type' => 'date',
                'is_required' => false ,
                'length' => 11,
                'description' => "The start date for your discount price to begin being displayed, if it is a timelimited promotion, and you have populated either 'DiscountPriceWithoutVAT' or 'DiscountPriceWithVAT'.
                The date must be provided in one of the following UNIX timestamp formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; DDMM-YY; DD-MM-YYYY; YY-MM-DD; YYYY-MM-DD."
            ),
            'DiscountPriceEndDate' => array(
                'type' => 'date',
                'is_required' => false ,
                'length' => 11 ,
                'description' => "The end date for your discount price to stop being displayed, if it is a timelimited promotion, and you have populated either 'DiscountPriceWithoutVAT' or 'DiscountPriceWithVAT'.
                                The date must be provided in one of the following UNIX timestamp formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; DDMM-YY; DD-MM-YYYY; YY-MM-DD; YYYY-MM-DD."
            ),
        );
    }

    function getCountry() {
        $query = $this->db->query("SELECT id, country FROM " . DB_PREFIX . "cedfruugo_country_currency GROUP BY country ORDER BY country");
        return $query->rows;
    }

    function getCurrency() {
        $query = $this->db->query("SELECT id, currency_code FROM " . DB_PREFIX . "cedfruugo_country_currency GROUP BY currency_code ORDER BY currency_code");

        return $query->rows;
    }

    function getFruugoLanguage() {
        $query = $this->db->query("SELECT id, language FROM " . DB_PREFIX . "cedfruugo_country_currency GROUP BY language ORDER BY language");

        return $query->rows;
    }

    function validDate($date, $format = 'Y-m-d')
    {
        $date_obj = DateTime::createFromFormat($format, $date);
        return $date_obj && $date_obj->format($format) == $date;
    }

    public function EnableDisableStock($product_ids, $keyFor)
    {
        if(is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0) {
            $allproducts = $this->config->get('ced_fruugo_map_category');
            if ($allproducts) {
                $product_ids = $this->getAllMappedProducts();
            } else {
                $product_ids = $this->getAllFruugoProducts();
            }
            $product_ids = array_unique($product_ids);
        }
        try{
            $updatestock = false;

            if(count($product_ids)){
                if(!isset($product_ids['0']) && $product_ids){
                    $temp_product_array = $product_ids;
                    $product_ids = array();
                    $product_ids['0'] = $temp_product_array;
                }
                $prod_ids = array_chunk($product_ids,'100');
                foreach ($prod_ids as $key => $prod_id) {
                    //foreach ($prod_ids as $key => $prod_id) {
                    $updatestock = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
                    $updatestock .='<skus>';
                    $upload_inventry = false;
                    $response =false;

                    $feed_array = array();

                    foreach ($prod_id as $product_id) {

                        $product_combination = $this->productOptionCombination($product_id);

                        if(!empty($product_combination)){
                            foreach($product_combination as $single_combi){

                                $SkuId = $single_combi['sku'];
                                $option_attribute = $this->getOptionAttribute($product_id, $SkuId, $single_combi);

                                if(isset($SkuId) && isset($option_attribute['quantity'])) {
                                    $sku = $SkuId;
                                    $quantity = $option_attribute['quantity'];
                                    $fruugoSkuId = $this->getFruugoSkuId($product_id, $sku);

                                    if ($fruugoSkuId) {
                                        $upload_inventry = true;
                                        $updatestock .='<sku fruugoSkuId="'.trim($fruugoSkuId).'">';
                                        if($keyFor == 'disable' && (!empty($quantity) || $quantity == '0'))
                                            $updatestock .='<availability>NOTAVAILABLE</availability>';
                                        elseif($keyFor == 'enable' && (!empty($quantity) || $quantity == '0'))
                                            $updatestock .='<availability>INSTOCK</availability>';
                                        elseif($quantity)
                                            $updatestock .='<availability>INSTOCK</availability>';
                                        else
                                            $updatestock .='<availability>OUTOFSTOCK</availability>';
                                        if($keyFor == 'disable')
                                            $updatestock .='<availability>NOTAVAILABLE</availability>';
                                        $updatestock .='<itemsInStock>'.(int)$quantity.'</itemsInStock>';
                                        $updatestock .='</sku>';
                                        $feed_array[] = array(
                                            'SkuId' => $sku,
                                            'StockQuantity' => $quantity,
                                            'StockStatus' => $quantity > 0 ? 'INSTOCK': 'OUTOFSTOCK'
                                        );
                                    }
                                }
                            }
                        } else {

                            $sql = $this->db->query("SELECT `sku`, `quantity` FROM " . DB_PREFIX . "product WHERE `product_id` ='".$product_id."'");
                            $query = $sql->rows;

                            $quantity = 0;
                            if(isset($query['0']['quantity']))
                                $quantity = $query['0']['quantity'];
                            $sku = $query['0']['sku'];

                            $fruugoSkuId = $this->getFruugoSkuId($product_id, $sku);

                            if($fruugoSkuId) {
                                $upload_inventry = true;
                                $updatestock .='<sku fruugoSkuId="'.trim($fruugoSkuId).'">';
                                if($keyFor == 'disable' && (!empty($quantity) || $quantity == '0'))
                                    $updatestock .='<availability>NOTAVAILABLE</availability>';
                                elseif($keyFor == 'enable' && (!empty($quantity) || $quantity == '0'))
                                    $updatestock .='<availability>INSTOCK</availability>';
                                elseif($quantity)
                                    $updatestock .='<availability>INSTOCK</availability>';
                                else
                                    $updatestock .='<availability>OUTOFSTOCK</availability>';
                                $updatestock .='<itemsInStock>'.(int)$quantity.'</itemsInStock>';
                                $updatestock .='</sku>';
                                $feed_array[] = array(
                                    'SkuId' => $sku,
                                    'StockQuantity' => $quantity,
                                    'StockStatus' => $quantity > 0 ? 'INSTOCK': 'OUTOFSTOCK'
                                );
                            }
                        }
                    }
                    //}
                    $updatestock .='</skus>';
                    $this->log('Inventory Update');
                    $this->log($updatestock);
                    if($updatestock && $upload_inventry){
                        $params = array('data' => $updatestock);
                        $response = $this->WPostRequest('stockstatus-api', $params);
                        $this->log('Inventory Update Response');
                        $this->log(json_encode($response));
                    }
                }
                if(isset($response) && $response['success'] == 1) {

                    if($keyFor == 'disable')
                        $this->db->query("UPDATE `". DB_PREFIX ."cedfruugo_product_variations` SET fruugo_status = 'OUTOFSTOCK' WHERE product_id = '". $product_id ."' ");
                    else if($keyFor == 'enable')
                        $this->db->query("UPDATE `". DB_PREFIX ."cedfruugo_product_variations` SET fruugo_status = 'INSTOCK' WHERE product_id = '". $product_id ."' ");

                    $csv_file = $this->prepareCsvFile();

                    return array('success' => true, 'message' => $response);
                }
                return array('success'=> false, 'message' => 'Failed to Disable/Enable product on Fruugo');
            }
        } catch(Exception $e){
            $this->log($e->getMessage());
        }
    }

    public function updateStock($product_ids=array(), $keyFor)
    {
        if(is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0) {
            $allproducts = $this->config->get('ced_fruugo_map_category');
            if ($allproducts) {
                $product_ids = $this->getAllMappedProducts();
            } else {
                $product_ids = $this->getAllFruugoProducts();
            }
            $product_ids = array_unique($product_ids);
        }
        try{
            $updatestock = false;

            if(count($product_ids)){
                $default_lang = ((int) $this->config->get('ced_fruugo_store_language'))?(int) $this->config->get('ced_fruugo_store_language'):(int) $this->config->get('ced_fruugo_language');
                $productids_chunk = array_chunk($product_ids,'999');
                $inventory_chunk = array();

                $sql = $this->db->query("SELECT `inventory_chunk` FROM `" . DB_PREFIX . "cedfruugo_products_cron` WHERE `type` = 'updatestock'");
                $result = $sql->rows;
                if (count($result) && isset($result[0]['inventory_chunk']) && count($result[0]['inventory_chunk'])) {
                    $inventory_chunk = json_decode($result[0]['inventory_chunk'], true);
                }
                $finalInventoryChunk = array();
                if (!count($inventory_chunk)) {
                    $this->db->query("INSERT INTO `". DB_PREFIX ."cedfruugo_products_cron` (`inventory_chunk`, `type`) VALUES ('". $this->db->escape(json_encode($productids_chunk)) ."', 'updatestock') ");

                    $inventory_chunk = $productids_chunk;
                } else {
                    foreach ($inventory_chunk as $chunk) {
                        if (is_array($chunk)) {
                            foreach ($chunk as $id) {
                                $finalInventoryChunk[] = $id;
                            }
                        }
                    }
                    foreach ($productids_chunk as $chunk) {
                        if (is_array($chunk)) {
                            foreach ($chunk as $id) {
                                $finalInventoryChunk[] = $id;
                            }
                        }
                    }
                    $inventory_chunk = array_unique($finalInventoryChunk);
                    $inventory_chunk = array_chunk($inventory_chunk, 999);
                }
                foreach ($inventory_chunk as $chk => $product_ids) {
                    $updatestock = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
                    $updatestock .='<skus>';
                    $upload_inventry = false;
                    $response =false;
                    $prod_ids = array_chunk($product_ids,'100');

                    $feed_array = array();
                    foreach ($prod_ids as $key => $prod_id) {

                        foreach ($prod_id as $product_id) {

                            $product_combination = $this->productOptionCombination($product_id);

                            if(!empty($product_combination)){
                                foreach($product_combination as $single_combi){

                                    $SkuId = $single_combi['sku'];
                                    $option_attribute = $this->getOptionAttribute($product_id, $SkuId, $single_combi);

                                    if(isset($SkuId) && isset($option_attribute['quantity'])) {
                                        $sku = $SkuId;
                                        $quantity = $option_attribute['quantity'];
                                        $fruugoSkuId = $this->getFruugoSkuId($product_id, $sku);

                                        if ($fruugoSkuId) {
                                            $upload_inventry = true;
                                            $updatestock .='<sku fruugoSkuId="'.trim($fruugoSkuId).'">';
                                            if($keyFor == 'disable' && (!empty($quantity) || $quantity == '0'))
                                                $updatestock .='<availability>NOTAVAILABLE</availability>';
                                            elseif($keyFor == 'enable' && (!empty($quantity) || $quantity == '0'))
                                                $updatestock .='<availability>INSTOCK</availability>';
                                            elseif($quantity)
                                                $updatestock .='<availability>INSTOCK</availability>';
                                            else
                                                $updatestock .='<availability>OUTOFSTOCK</availability>';
                                            if($keyFor == 'disable')
                                                $updatestock .='<availability>NOTAVAILABLE</availability>';
                                            $updatestock .='<itemsInStock>'.(int)$quantity.'</itemsInStock>';
                                            $updatestock .='</sku>';
                                            $feed_array[] = array(
                                                'SkuId' => $sku,
                                                'StockQuantity' => $quantity,
                                                'StockStatus' => $quantity > 0 ? 'INSTOCK': 'OUTOFSTOCK'
                                            );
                                        }
                                    }
                                }
                            } else {

                                $sql = $this->db->query("SELECT `sku`, `quantity` FROM " . DB_PREFIX . "product WHERE `product_id` ='".$product_id."'");
                                $query = $sql->rows;

                                $quantity = 0;
                                if(isset($query['0']['quantity']))
                                    $quantity = $query['0']['quantity'];
                                $sku = $query['0']['sku'];

                                $fruugoSkuId = $this->getFruugoSkuId($product_id, $sku);

                                if($fruugoSkuId) {
                                    $upload_inventry = true;
                                    $updatestock .='<sku fruugoSkuId="'.trim($fruugoSkuId).'">';
                                    if($keyFor == 'disable' && (!empty($quantity) || $quantity == '0'))
                                        $updatestock .='<availability>NOTAVAILABLE</availability>';
                                    elseif($keyFor == 'enable' && (!empty($quantity) || $quantity == '0'))
                                        $updatestock .='<availability>INSTOCK</availability>';
                                    elseif($quantity)
                                        $updatestock .='<availability>INSTOCK</availability>';
                                    else
                                        $updatestock .='<availability>OUTOFSTOCK</availability>';
                                    $updatestock .='<itemsInStock>'.(int)$quantity.'</itemsInStock>';
                                    $updatestock .='</sku>';
                                    $feed_array[] = array(
                                        'SkuId' => $sku,
                                        'StockQuantity' => $quantity,
                                        'StockStatus' => $quantity > 0 ? 'INSTOCK': 'OUTOFSTOCK'
                                    );
                                }
                            }
                        }
                    }
                    $updatestock .='</skus>';
                    $this->log('Inventory Update');
                    $this->log($updatestock);
                    if($updatestock && $upload_inventry){
                        $params = array('data' => $updatestock);
                        $response = $this->WPostRequest('stockstatus-api', $params);
                        $this->log('Inventory Update Response');
                        $this->log(json_encode($response));

                    }
                    if ($response) {
                        $this->db->query("DELETE FROM `". DB_PREFIX ."cedfruugo_products_cron` WHERE `type` = 'updatestock' ");

                        unset($inventory_chunk[$chk]);
                        $inventory_chunk = array_values($inventory_chunk);

                        $this->db->query("INSERT INTO `". DB_PREFIX ."cedfruugo_products_cron` (`inventory_chunk`, `type`) VALUES ('". $this->db->escape(json_encode($inventory_chunk)) ."', 'updatestock') ");

                        foreach ($feed_array as $feed) {
                            $this->db->query("UPDATE `". DB_PREFIX ."cedfruugo_final_products` SET `StockQuantity` = '". $feed['StockQuantity']."', `StockStatus` = '". $feed['StockStatus'] ."' WHERE SkuId = '".$feed['SkuId']."' ");
                        }
                    }
                }
                if($response) {

                    $csv_file = $this->prepareCsvFile();

                    return array('success' => true, 'message' => $response);
                }
                return array('success'=> false, 'message' => 'No Stock To Sync');
            }
        } catch(Exception $e){
            $this->log($e->getMessage());
        }
    }

    public function getFruugoSkuId($product_id, $sku)
    {
        $sql = $this->db->query("SELECT `fruugo_SkuId` FROM `" . DB_PREFIX . "cedfruugo_product_variations` WHERE  `product_id` = '". $product_id ."' AND `sku` = '".$sku."' ");
        $query = $sql->row;

        if(isset($query['0']['fruugo_SkuId']))
            return $query['0']['fruugo_SkuId'];
        elseif(isset($query['fruugo_SkuId']))
            return $query['fruugo_SkuId'];
        else
            return $sku;

        if ($query['fruugo_SkuId'] == '') {

            $sql = $this->db->query("SELECT `SkuId` FROM `" . DB_PREFIX . "cedfruugo_final_products` WHERE  `ProductId` = '". $product_id ."' ");
            $query = $sql->row;

            if(isset($query['0']['SkuId']))
                return $query['0']['SkuId'];
            elseif(isset($query['SkuId']))
                return $query['SkuId'];
            else
                return $sku;
        }
    }

    public function getOptionAttribute($product_id, $sku, $combi_array = array())
    {
        $option_attributes = array();
        $query = $this->db->query("SELECT combination FROM `". DB_PREFIX ."cedfruugo_product_attribute_combination` WHERE product_id = '". $product_id ."' AND SkuId = '". $sku ."' ");
        $result = $query->rows;
        $combination = array();
        if(isset($result) && !empty($result)){
            foreach($result as $key){
                $combination = json_decode($key['combination'], true);
                $quantity_array = array();
                // $quantity = '0';
                foreach($combination as $option_id => $name){
                    if($option_id != 'sku'){
                        $option_value_query = $this->db->query("SELECT pov.quantity FROM `". DB_PREFIX ."option_value_description` AS ovd JOIN `". DB_PREFIX ."product_option_value` AS pov ON (ovd.option_value_id = pov.option_value_id) WHERE ovd.option_id = '". $option_id ."' AND ovd.name = '". $name ."' AND pov.product_id = '". $product_id ."' ");
                        $option_value_res = $option_value_query->row;
                        if(isset($option_value_res['quantity']) && $option_value_res['quantity'])
                            $quantity_array[] = $option_value_res['quantity'];
                        // if(!empty($option_value_res['quantity']))
                        //     $quantity+=$option_value_res['quantity'];
                        // else
                        //     $quantity = '0';
                    }
                }
                $option_attributes = array('quantity' => min($quantity_array));
                return $option_attributes;
            }
        } else {
            if(!isset($combi_array['0'])){
                $temp_combi_array = $combi_array;
                $combi_array = array();
                $combi_array['0'] = $temp_combi_array;
            }
            foreach($combi_array as $key){
                // $quantity = '0';
                $quantity_array = array();
                foreach($key as $option_id => $name){
                    if($option_id != 'sku'){
                        $option_value_query = $this->db->query("SELECT pov.quantity FROM `". DB_PREFIX ."option_value_description` AS ovd JOIN `". DB_PREFIX ."product_option_value` AS pov ON (ovd.option_value_id = pov.option_value_id) WHERE ovd.option_id = '". $option_id ."' AND ovd.name = '". $name ."' AND pov.product_id = '". $product_id ."' ");
                        $option_value_res = $option_value_query->row;
                        if(isset($option_value_res['quantity']) && $option_value_res['quantity'])
                            $quantity_array[] = $option_value_res['quantity'];
                        // if(!empty($option_value_res['quantity']))
                        //     $quantity+=$option_value_res['quantity'];
                        // else
                        //     $quantity = '0';
                    }
                }
                $option_attributes = array('quantity' => min($quantity_array));
                return $option_attributes;
            }
        }
    }

    public function fetchStock($json='true')
    {
        $params = array();
        $response = $this->fruugoGetRequest('stockstatus-api', $params);
        return $response;
    }

    public function packingListByFruugo($fruugo_order_id, $shipment_id)
    {
        $params = array();
        if($fruugo_order_id)
            $params['orderId'] = $fruugo_order_id;

        if($shipment_id)
            $params['shipmentId'] = $shipment_id;

        $response = $this->fruugoGetRequest('orders/packinglist', $params);

        return $response;
    }

}