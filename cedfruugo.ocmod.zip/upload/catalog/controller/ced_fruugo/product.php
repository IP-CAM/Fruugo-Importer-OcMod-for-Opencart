<?php
class ControllerCedFruugoProduct extends Controller {
	private $error = array();

	
    public function fetchStatus()
    {
        $json = array();
        $this->load->library('cedfruugo');
        $this->load->language('ced_fruugo/product');
        $this->document->setTitle($this->language->get('heading_title'));
        $cedfruugo = Cedfruugo::getInstance($this->registry);
        //$this->load->model('ced_fruugo/product');

        $response_data = $cedfruugo->fetchStock(true);

        $report_array = array();
        if (isset($response_data['success']) && isset($response_data['response'])) {
            $response_data = $this->getparsedData($response_data['response'], true);
            if(isset($response_data['skus']['value']['sku']) && count($response_data['skus']['value']['sku'])){
                $report_array = $response_data['skus']['value']['sku'];
            }
        } else {
            $cedfruugo->log(json_encode($response_data),true);
        }

        if(!empty($report_array))
            $json = array('success' => true, 'message' => 'Status fetched successfully!');
        else
            $json = array('success' => false, 'message' => 'No update(s) available!');
        
        $this->response->setOutput(json_encode($json));
    }

    public function getparsedData(&$string) {
	    $parser = xml_parser_create();
	    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
	    xml_parse_into_struct($parser, $string, $vals, $index);
	    xml_parser_free($parser);
	    $mnary=array();
	    $ary=&$mnary;

	    foreach ($vals as $r) {
	        $t=$r['tag'];
	        if ($r['type']=='open') {
	            if (isset($ary[$t])) {
	                if (isset($ary[$t][0])) $ary[$t][]=array(); else $ary[$t]=array($ary[$t], array());
	                $cv=&$ary[$t][count($ary[$t])-1];
	            } else $cv=&$ary[$t];
	            if (isset($r['attributes'])) {
	            	foreach ($r['attributes'] as $k=>$v) {
	            		$cv[$k]=$v;
	            	}
	            }
	            $cv['value']=array();
	            $cv['value']['_p']=&$ary;
	            $ary=&$cv['value'];
	        } elseif ($r['type']=='complete') {
	            if (isset($ary[$t])) { 
	                if (isset($ary[$t][0])) $ary[$t][]=array(); else $ary[$t]=array($ary[$t], array());
	                $cv=&$ary[$t][count($ary[$t])-1];
	            } else $cv=&$ary[$t];
	            if (isset($r['attributes'])) {foreach ($r['attributes'] as $k=>$v) $cv[$k]=$v;}
	            $cv=(isset($r['value']) ? $r['value'] : '');
	        } elseif ($r['type']=='close') {
	            $ary=&$ary['_p'];
	        }
	    }    
	    
	    $this->_del_p($mnary);
	    return $mnary;
	}

	function _del_p(&$ary) {
	    foreach ($ary as $k=>$v) {
	        if ($k==='_p') unset($ary[$k]);
	        elseif (is_array($ary[$k])) $this->_del_p($ary[$k]);
	    }
	}

	 public function uploadAllProducts()
    {
        $json = array();
        $this->load->library('cedfruugo');
        $cedfruugo = Cedfruugo::getInstance($this->registry);

        $productIds = $cedfruugo->getAllMappedProducts();
        if(empty($productIds))
            $productIds = $cedfruugo->getAllFruugoProducts();

        try{
            if ($productIds && count($productIds))
            {
//                $total_product = count($productIds);
//                $array_chunk_count = ceil($total_product/10);
                $productIds = array_chunk($productIds,100);

                if(count($productIds) > 0){
                    foreach($productIds as $key => $product_ids)
                    {
                        $response = $cedfruugo->uploadProducts($product_ids);

                        if (isset($response['success']) && $response['success']) {
                            if (!is_array($response['message']))
                                $json['message'][] = 'Uploading Product Id(s) '.implode(',', $product_ids).' : '.$response['message'];
                            else
                                $json['message'][] = 'Uploading Product Id(s) '.implode(',', $product_ids).' : ' .implode(',',$response['message'] );
                            $json['success'] = true;
                        } else {
                            $json['success'] = false;
                            $json['message'][] = ($response['message'])?$response['message']:'No response to upload see log.';
                        }
                    }
                    echo '<pre>'; print_r(json_encode($json)); die;
                }
            } else {
                $json['success'] = false;
                $json['message'] = 'No Category Mapped yet';
                echo '<pre>'; print_r(json_encode($json)); die;
            }
        } catch(Exception $e){
            $json['success'] = false;
            $json['message'] = $e->getMessage();
            echo '<pre>'; print_r(json_encode($json)); die;
        }

        $this->response->setOutput(json_encode($json));
    }

	public function addNewProduct() 
	{
		$json = array();

        $this->load->language('ced_fruugo/product');
        $this->load->model('ced_fruugo/product');

        $response = $this->model_ced_fruugo_product->addNewProduct();

        if(isset($response['success']) && !empty($response['message']))
            $json = array('success' => true, 'message' => $response['message']);
        elseif(empty($response))
        	$json = array('success' => false, 'message' => 'No new Product(s) to add');
        else
        	$json = array('success' => false, 'message' => 'Error Updating Products');

        $this->response->setOutput(json_encode($json));

    }

}
?>