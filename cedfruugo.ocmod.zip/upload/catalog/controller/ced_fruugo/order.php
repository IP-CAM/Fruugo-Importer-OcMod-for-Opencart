<?php
class ControllerCedFruugoOrder extends Controller {
	private $error = array();

	public function fetchOrder()
    {
        $json = array();
		$this->load->library('cedfruugo');
		$this->load->language('ced_fruugo/order');
		// $this->load->model('ced_fruugo/order');
		$cedfruugo = Cedfruugo::getInstance($this->registry); 
        $createdStartDate = date('Y-m-d',strtotime("-1 days"));
        $order = array('from' => $createdStartDate);
		$response = $cedfruugo->fetchOrders($order, 'orders/download');
  
		if(isset($response['success']) && $response['success']) {
		    $json = array('success' => true, 'message' => isset($response['message']) ? $response['message'] : 'Order Imported Successfully.');
		} else {
            $json = array('success' => false, 'message' => $response['message']);
		}
        $this->response->setOutput(json_encode($json));
	}

}