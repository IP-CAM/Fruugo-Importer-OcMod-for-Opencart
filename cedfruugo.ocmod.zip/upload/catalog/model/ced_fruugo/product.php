<?php
class ModelCedFruugoProduct extends Model {

    public function addNewProduct() 
    {
        $response = array();
        $mapped_details = $this->db->query("SELECT id, category FROM `".DB_PREFIX."cedfruugo_mapping_details`");
        if($mapped_details->num_rows)
        {
            foreach ($mapped_details->rows as $key => $mapped_detail)
            {
                $profile_id = $mapped_detail['id'];
                $existingProducts = $this->db->query("SELECT DISTINCT product_id FROM `". DB_PREFIX ."cedfruugo_product_variations` WHERE profile_id = '". $profile_id ."' ");
                $productExist = array();
                foreach($existingProducts->rows as $key1 => $val)
                {
                    $productExist[] = $val['product_id'];
                }

                $store_category = json_decode($mapped_detail['category'], true);

                foreach($store_category as $category_id)
                {
                    //$newProducts = $this->db->query("SELECT DISTINCT pd.product_id FROM `" . DB_PREFIX . "product` AS p JOIN `". DB_PREFIX ."product_to_category` AS pc ON (pc.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND pc.category_id = '" . $category_id . "' ");
                    $newProducts = $this->db->query("SELECT DISTINCT product_id FROM `" . DB_PREFIX . "product_to_category` WHERE category_id = '" . $category_id . "' ");

                    foreach ($newProducts->rows as  $product_array)
                    {
                        if(!in_array($product_array['product_id'], $productExist))
                        {
                            $product_already_exist = $this->db->query("SELECT id FROM `" . DB_PREFIX . "cedfruugo_product_variations` WHERE product_id = '" . $product_array['product_id'] . "' ");
                            if($product_already_exist->num_rows < '1')
                            {
                                $this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "cedfruugo_product_variations` (`profile_id` , `product_id`) VALUES ('" . $profile_id . "', '" . $product_array['product_id'] . "')");
                                $response = ['success' => true, 'message' => 'Updated New Products'];
                            } else {
                                $response = ['success' => false, 'message' => 'No New Product to update'];
                            }
                        }
                    }
                }
            }
            return $response;
        } else {
            return ['success' => false, 'message' => 'No category mapped.'];
        }

    }

}
?>